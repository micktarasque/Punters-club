import express from "express";
import path from "path";
import fs from "fs";
import { spawnSync } from "child_process";
import dotenv from "dotenv";
import {
  getMeetingsForDateRange,
  clampDateRangeTo5Days,
  validateAndSanitizeMeetings,
  getMaxAllowedDateIso,
  getCurrentAustralianDateIso,
  normalizeAustralianDateIso,
  INITIAL_PUNTERS,
} from "./src/data/seedNswTab.ts";
import { mergeMeetingsPreservingResultsAndForm } from "./src/utils/raceResultsUpdater.ts";
import type {
  RaceMeeting,
  RaceEvent,
  RaceRunner,
  ExoticDividend,
  PunterProfile,
  RaceSelectionTrio,
} from "./src/types/racing.ts";

dotenv.config({ quiet: true });

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Disable X-Powered-By header to prevent server fingerprinting
app.disable("x-powered-by");

// Production Security & CORS Headers Middleware (Modern Web Security Standards)
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Accept");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-DNS-Prefetch-Control", "off");
  res.setHeader("X-Permitted-Cross-Domain-Policies", "none");
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin-allow-popups");
  res.setHeader("X-XSS-Protection", "1; mode=block");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader(
    "Permissions-Policy",
    "geolocation=(), microphone=(), camera=(), payment=(), usb=()"
  );
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self' https: data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' https:; style-src 'self' 'unsafe-inline' https:; img-src 'self' data: blob: https:; connect-src 'self' https: wss:; font-src 'self' data: https:; frame-ancestors *;"
  );
  if (req.method === "OPTIONS") {
    res.status(200).json({ ok: true });
    return;
  }
  next();
});

// Per-IP Rate Limiter for API routes (120 requests / 60s window) with periodic GC
const rateLimitWindowMs = 60_000;
const rateLimitMaxRequests = 120;
const ipRequestCounts = new Map<string, { count: number; resetAt: number }>();

setInterval(() => {
  const now = Date.now();
  for (const [ip, data] of ipRequestCounts.entries()) {
    if (now > data.resetAt) {
      ipRequestCounts.delete(ip);
    }
  }
}, 120_000).unref?.();

app.use("/api", (req, res, next) => {
  const clientIp =
    (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() ||
    req.socket.remoteAddress ||
    "local";
  const now = Date.now();
  const entry = ipRequestCounts.get(clientIp);
  if (!entry || now > entry.resetAt) {
    ipRequestCounts.set(clientIp, { count: 1, resetAt: now + rateLimitWindowMs });
    next();
    return;
  }
  entry.count += 1;
  if (entry.count > rateLimitMaxRequests) {
    res.status(429).json({
      error: "Too many API requests. Please wait a moment and try again.",
    });
    return;
  }
  next();
});

function sanitizeObjectAgainstPrototypePollution(obj: any): any {
  if (!obj || typeof obj !== "object") return obj;
  if (Array.isArray(obj)) {
    return obj.map(sanitizeObjectAgainstPrototypePollution);
  }
  const clean: Record<string, any> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (key === "__proto__" || key === "constructor" || key === "prototype") {
      continue;
    }
    clean[key] = sanitizeObjectAgainstPrototypePollution(value);
  }
  return clean;
}

app.use(express.json({ limit: "1mb" }));
app.use(
  (
    err: any,
    req: express.Request,
    _res: express.Response,
    next: express.NextFunction
  ) => {
    if (err) {
      req.body = {};
      next();
      return;
    }
    if (req.body && typeof req.body === "object") {
      req.body = sanitizeObjectAgainstPrototypePollution(req.body);
    }
    next();
  }
);

app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    targetDomain: "cupdaypunting.xo.je",
    mode: "multi-source-verified-live",
    securityHeaders: "enabled",
    timestamp: new Date().toISOString(),
  });
});

// Persistent disk + in-memory cache for multi-source verified race data & finalized race events
const CACHE_DIR = path.join(process.cwd(), ".cache");
const CACHE_FILE = path.join(CACHE_DIR, "verified_multi_source_cache_v2.json");
const FINAL_EVENTS_CACHE_FILE = path.join(
  CACHE_DIR,
  "finalized_race_events_v2.json"
);
const scrapeCache = new Map<string, any>();
const raceEventCache = new Map<
  string,
  { data: any; fetchedAt: number; isFinal: boolean }
>();

try {
  if (fs.existsSync(CACHE_FILE)) {
    const raw = JSON.parse(fs.readFileSync(CACHE_FILE, "utf-8"));
    if (raw && typeof raw === "object") {
      for (const [k, v] of Object.entries(raw)) {
        scrapeCache.set(k, v);
      }
    }
  }
} catch {
  // ignore cache read errors
}

try {
  if (fs.existsSync(FINAL_EVENTS_CACHE_FILE)) {
    const rawEvents = JSON.parse(
      fs.readFileSync(FINAL_EVENTS_CACHE_FILE, "utf-8")
    );
    if (rawEvents && typeof rawEvents === "object") {
      for (const [rid, edata] of Object.entries(rawEvents)) {
        raceEventCache.set(rid, {
          data: edata,
          fetchedAt: Date.now(),
          isFinal: true,
        });
      }
    }
  }
} catch {
  // ignore finalized event cache read errors
}

function saveFinalizedEventsToDisk() {
  try {
    if (!fs.existsSync(CACHE_DIR)) {
      fs.mkdirSync(CACHE_DIR, { recursive: true });
    }
    const obj: Record<string, any> = {};
    for (const [rid, entry] of raceEventCache.entries()) {
      if (entry.isFinal && entry.data) {
        obj[rid] = entry.data;
      }
    }
    fs.writeFileSync(FINAL_EVENTS_CACHE_FILE, JSON.stringify(obj), "utf-8");
  } catch {
    // ignore disk write errors
  }
}

function saveToPersistentCache(key: string, payload: any) {
  scrapeCache.set(key, payload);
  try {
    if (!fs.existsSync(CACHE_DIR)) {
      fs.mkdirSync(CACHE_DIR, { recursive: true });
    }
    const obj: Record<string, any> = {};
    for (const [k, v] of scrapeCache.entries()) {
      obj[k] = v;
    }
    fs.writeFileSync(CACHE_FILE, JSON.stringify(obj), "utf-8");
  } catch {
    // ignore disk cache write errors
  }
}

const SILK_PALETTE: Array<[string, string]> = [
  ["#DC2626", "#FFFFFF"],
  ["#1E3A8A", "#FACC15"],
  ["#047857", "#FFFFFF"],
  ["#7C3AED", "#FDE047"],
  ["#D97706", "#111827"],
  ["#0284C7", "#FFFFFF"],
  ["#BE185D", "#FBCFE8"],
  ["#111827", "#F59E0B"],
  ["#15803D", "#FEF08A"],
  ["#9333EA", "#FFFFFF"],
  ["#B91C1C", "#FDE047"],
  ["#0F766E", "#FFFFFF"],
];

function parseSilkColors(desc: string, idx: number): [string, string] {
  const d = (desc || "").toUpperCase();
  const colorMap: Array<[string, string]> = [
    ["ROYAL BLUE", "#1D4ED8"],
    ["NAVY", "#1E3A8A"],
    ["BLUE", "#2563EB"],
    ["MAROON", "#881337"],
    ["CERISE", "#DB2777"],
    ["PINK", "#EC4899"],
    ["RED", "#DC2626"],
    ["EMERALD", "#059669"],
    ["BOTTLE GREEN", "#064E3B"],
    ["GREEN", "#16A34A"],
    ["GOLD", "#EAB308"],
    ["YELLOW", "#FACC15"],
    ["ORANGE", "#EA580C"],
    ["PURPLE", "#7C3AED"],
    ["LILAC", "#A855F7"],
    ["BLACK", "#18181B"],
    ["GREY", "#6B7280"],
    ["SILVER", "#9CA3AF"],
    ["WHITE", "#F8FAFC"],
    ["BROWN", "#78350F"],
    ["TURQUOISE", "#0D9488"],
  ];
  const found: string[] = [];
  for (const [name, hexVal] of colorMap) {
    if (d.includes(name) && !found.includes(hexVal)) {
      found.push(hexVal);
    }
    if (found.length === 2) break;
  }
  if (found.length === 2) return [found[0], found[1]];
  if (found.length === 1) {
    return [found[0], found[0] !== "#F8FAFC" ? "#FFFFFF" : "#1E3A8A"];
  }
  return SILK_PALETTE[idx % SILK_PALETTE.length];
}

function cleanVenueName(name: string): string {
  let n = (name || "").trim();
  for (const prefix of [
    "Ladbrokes ",
    "Sportsbet ",
    "Picklebet Park ",
    "bet365 ",
    "Southside ",
  ]) {
    if (n.startsWith(prefix)) {
      n = n.slice(prefix.length).trim();
    }
  }
  if (n.toLowerCase() === "rosehill") return "Rosehill Gardens";
  return n;
}

function getMeetingTier(venue: string): "Metropolitan" | "Provincial" | "Country" {
  const v = (venue || "").toLowerCase();
  if (
    [
      "randwick",
      "rosehill",
      "warwick farm",
      "canterbury",
      "flemington",
      "caulfield",
      "moonee valley",
      "sandown",
      "eagle farm",
      "doomben",
      "morphettville",
      "ascot",
      "belmont",
    ].some((m) => v.includes(m))
  ) {
    return "Metropolitan";
  }
  if (
    [
      "hawkesbury",
      "kembla grange",
      "newcastle",
      "wyong",
      "gosford",
      "geelong",
      "ballarat",
      "cranbourne",
      "bendigo",
      "pakenham",
      "mornington",
      "seymour",
      "kyneton",
      "gold coast",
      "sunshine coast",
      "ipswich",
      "canberra",
    ].some((p) => v.includes(p))
  ) {
    return "Provincial";
  }
  return "Country";
}

function formatAestTime(raceObj: any, fallbackIso: string): string {
  const ts = Number(raceObj?.advertised_start);
  if (ts > 0) {
    const dtUtc = new Date(ts * 1000);
    const isoDate = dtUtc.toISOString().slice(0, 10);
    const offsetHours = isoDate >= "2026-10-04" ? 11 : 10;
    const dtLocal = new Date(dtUtc.getTime() + offsetHours * 3600 * 1000);
    return dtLocal.toISOString().slice(11, 16);
  }
  if (fallbackIso && fallbackIso.includes("T")) {
    const dtUtc = new Date(fallbackIso);
    if (!Number.isNaN(dtUtc.getTime())) {
      const isoDate = dtUtc.toISOString().slice(0, 10);
      const offsetHours = isoDate >= "2026-10-04" ? 11 : 10;
      const dtLocal = new Date(dtUtc.getTime() + offsetHours * 3600 * 1000);
      return dtLocal.toISOString().slice(11, 16);
    }
  }
  const vc = raceObj?.video_channels_meta || {};
  for (const ch of Object.values(vc) as any[]) {
    if (ch && typeof ch === "object" && ch.DisplayRaceStartTime) {
      const ds = String(ch.DisplayRaceStartTime);
      if (ds.includes("T") && ds.split("T")[1].length >= 5) {
        return ds.split("T")[1].slice(0, 5);
      }
    }
  }
  return "-";
}

function mapSpeedMapLabel(
  label: string
): "Leader" | "On Pace" | "Midfield" | "Backmarker" | undefined {
  const l = (label || "").toLowerCase();
  if (!l) return undefined;
  if (l.includes("lead")) return "Leader";
  if (l.includes("pace") || l.includes("handy")) return "On Pace";
  if (l.includes("back") || l.includes("rear")) return "Backmarker";
  return "Midfield";
}

function getWeekdayName(isoDate: string): string {
  const [y, m, d] = isoDate.split("-").map(Number);
  if (!y || !m || !d) return "Saturday";
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.toLocaleDateString("en-AU", {
    weekday: "long",
    timeZone: "UTC",
  });
}

async function fetchJsonWithTimeout(
  url: string,
  headers: Record<string, string>,
  timeoutMs = 7500
): Promise<any | null> {
  for (let attempt = 0; attempt < 2; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, {
        signal: controller.signal,
        headers,
      });
      clearTimeout(timer);
      if (res.ok) {
        return await res.json();
      }
    } catch {
      clearTimeout(timer);
    }
  }
  return null;
}

const ENTAIN_HEADERS = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
  From: "contact@turfsheet.com.au",
  "X-Partner": "TurfSheet",
  Accept: "application/json",
};

/**
 * Background Multi-Source Fetch & Cross-Verification Engine:
 * Queries:
 *  1. Ladbrokes AU Racing Affiliates API (api.ladbrokes.com.au)
 *  2. Neds AU Racing Affiliates API (api.neds.com.au)
 *  3. PointsBet AU Racing v3 API (api.au.pointsbet.com)
 *  4. Racing & Sports AU JSON v2 (www.racingandsports.com.au)
 * Never infers or fabricates any runner, race, or result.
 */
async function fetchMultiSourceVerifiedMeetings(
  startDate: string,
  endDate: string,
  trackFilter?: string
): Promise<{
  meetings: RaceMeeting[];
  sources: Array<{ title: string; uri: string }>;
  verifiedSourcesUsed: string[];
}> {
  const verifiedSourcesUsed: string[] = [];
  const sources: Array<{ title: string; uri: string }> = [];

  // 1. Fetch meetings from Ladbrokes AU & Neds AU & PointsBet AU in parallel
  const ladbrokesMeetingsUrl = `https://api.ladbrokes.com.au/affiliates/v1/racing/meetings?category=T&country=AUS&date_from=${startDate}&date_to=${endDate}&limit=200`;
  const nedsMeetingsUrl = `https://api.neds.com.au/affiliates/v1/racing/meetings?category=T&country=AUS&date_from=${startDate}&date_to=${endDate}&limit=200`;
  const pointsbetMeetingsUrl = `https://api.au.pointsbet.com/api/racing/v3/meetings?startDate=${startDate}&endDate=${endDate}`;
  const rasUrl = `https://www.racingandsports.com.au/todays-racing-json-v2`;

  const [lbData, nedsData, pbData, rasData] = await Promise.all([
    fetchJsonWithTimeout(ladbrokesMeetingsUrl, ENTAIN_HEADERS, 7500),
    fetchJsonWithTimeout(nedsMeetingsUrl, ENTAIN_HEADERS, 7500),
    fetchJsonWithTimeout(
      pointsbetMeetingsUrl,
      { "User-Agent": "Mozilla/5.0", Accept: "application/json" },
      6500
    ),
    fetchJsonWithTimeout(
      rasUrl,
      {
        "User-Agent": "Mozilla/5.0",
        Accept: "application/json",
        "X-Requested-With": "XMLHttpRequest",
        Referer: "https://www.racingandsports.com.au/",
      },
      5000
    ),
  ]);

  if (lbData?.data?.meetings?.length) {
    verifiedSourcesUsed.push("Ladbrokes AU Racing API (v1)");
    sources.push({
      title: "Ladbrokes Australia Official Thoroughbred Meetings & Events API",
      uri: "https://api.ladbrokes.com.au/affiliates/v1/racing/meetings?category=T&country=AUS",
    });
  }
  if (nedsData?.data?.meetings?.length) {
    verifiedSourcesUsed.push("Neds AU Racing API (v1)");
    sources.push({
      title: "Neds Australia Thoroughbred Fields, Flucs & Tote Dividends Feed",
      uri: "https://api.neds.com.au/affiliates/v1/racing/meetings?category=T&country=AUS",
    });
  }
  if (Array.isArray(pbData) && pbData.length > 0) {
    verifiedSourcesUsed.push("PointsBet AU Racing API (v3)");
    sources.push({
      title: "PointsBet Australia Official Racing v3 Feed",
      uri: "https://api.au.pointsbet.com/api/racing/v3/meetings",
    });
  }
  if (Array.isArray(rasData) && rasData.length > 0) {
    verifiedSourcesUsed.push("Racing & Sports AU (JSON v2)");
    sources.push({
      title: "Racing and Sports Australia Official Meetings Feed",
      uri: "https://www.racingandsports.com.au/todays-racing-json-v2",
    });
  }

  // Merge meeting lists from Ladbrokes (primary) and Neds (secondary backup)
  const rawMeetings: any[] =
    lbData?.data?.meetings || nedsData?.data?.meetings || [];
  if (rawMeetings.length === 0) {
    return { meetings: [], sources, verifiedSourcesUsed };
  }

  // Build PointsBet cross-check map by venue + raceNumber
  const pbRaceSet = new Set<string>();
  if (Array.isArray(pbData)) {
    for (const grp of pbData) {
      for (const pm of grp?.meetings || []) {
        if (pm?.countryCode === "AUS" && pm?.racingType === 1) {
          const vClean = cleanVenueName(pm.venue || "").toLowerCase();
          for (const pr of pm.races || []) {
            pbRaceSet.add(`${vClean}:${pr.raceNumber}`);
          }
        }
      }
    }
  }

  // Filter meetings to target date range and optional trackFilter
  const vf = (trackFilter || "").trim().toLowerCase();
  const targetMeetings = rawMeetings.filter((m) => {
    const mDate = String(m.date || "").slice(0, 10);
    if (mDate < startDate || mDate > endDate) return false;
    const st = String(m.state || "").toUpperCase();
    const nm = cleanVenueName(m.name || "");
    if (vf && vf !== "all") {
      if (
        !nm.toLowerCase().includes(vf) &&
        !vf.includes(nm.toLowerCase()) &&
        st.toLowerCase() !== vf
      ) {
        return false;
      }
    }
    return true;
  });

  // Collect race IDs and use smart caching:
  // - Permanently cached Final/All Clear events with full results & dividends are reused with 0 network calls.
  // - Open events whose jump time is >15m away and were fetched within 90s are reused unless forceRefresh is set.
  // - Newly completed or imminent races are always fetched live.
  const nowMs = Date.now();
  const raceIdsToFetch: string[] = [];
  const eventMap = new Map<string, any>();

  for (const m of targetMeetings) {
    for (const r of m.races || []) {
      const rid = r.id;
      if (!rid) continue;
      const summaryStatus = String(r.status || "Open")
        .trim()
        .toLowerCase();
      const isSummaryResultedOrActive = [
        "final",
        "all clear",
        "interim",
        "paying",
        "closed",
        "resulted",
        "official",
      ].includes(summaryStatus);

      const cached = raceEventCache.get(rid);
      if (cached) {
        if (cached.isFinal) {
          eventMap.set(rid, cached.data);
          continue;
        }
        // If summary is still "Open" and cached within 90s, reuse cached runner odds
        if (!isSummaryResultedOrActive && nowMs - cached.fetchedAt < 90_000) {
          eventMap.set(rid, cached.data);
          continue;
        }
      }
      raceIdsToFetch.push(rid);
    }
  }

  let newFinalEventsSaved = false;
  const batchSize = 20;
  for (let i = 0; i < raceIdsToFetch.length; i += batchSize) {
    const slice = raceIdsToFetch.slice(i, i + batchSize);
    await Promise.all(
      slice.map(async (rid) => {
        const primaryUrl = `https://api.ladbrokes.com.au/affiliates/v1/racing/events/${rid}`;
        const backupUrl = `https://api.neds.com.au/affiliates/v1/racing/events/${rid}`;
        let res = await fetchJsonWithTimeout(primaryUrl, ENTAIN_HEADERS, 5000);
        if (!res?.data) {
          res = await fetchJsonWithTimeout(backupUrl, ENTAIN_HEADERS, 5000);
        }
        if (res?.data) {
          const edata = res.data;
          eventMap.set(rid, edata);
          const evStatus = String(edata?.race?.status || "")
            .trim()
            .toLowerCase();
          const hasFullResults =
            Array.isArray(edata?.results) &&
            edata.results.length >= 3 &&
            Array.isArray(edata?.dividends) &&
            edata.dividends.length > 0 &&
            (evStatus === "final" || evStatus === "all clear");
          raceEventCache.set(rid, {
            data: edata,
            fetchedAt: Date.now(),
            isFinal: hasFullResults,
          });
          if (hasFullResults) {
            newFinalEventsSaved = true;
          }
        } else {
          const fallbackCached = raceEventCache.get(rid);
          if (fallbackCached?.data) {
            eventMap.set(rid, fallbackCached.data);
          }
        }
      })
    );
  }

  if (newFinalEventsSaved) {
    saveFinalizedEventsToDisk();
  }

  const builtMeetings: RaceMeeting[] = [];
  for (const m of targetMeetings) {
    const d = String(m.date || startDate).slice(0, 10);
    const venue = cleanVenueName(m.name || "");
    const state = String(m.state || "NSW").toUpperCase() as RaceMeeting["state"];
    const tier = getMeetingTier(venue);
    const tcRaw = String(m.track_condition || "Good4");
    const tc = tcRaw.replace(/([A-Za-z]+)(\d+)/, "$1 $2");

    let weather = "Fine";
    let rail = "True";
    const racesOut: RaceEvent[] = [];

    for (const rSum of m.races || []) {
      const rid = rSum.id;
      const edata = eventMap.get(rid) || {};
      const raceObj = edata.race || {};
      if (raceObj.weather) {
        weather = String(raceObj.weather);
      }
      if (raceObj.rail_position) {
        rail = String(raceObj.rail_position).slice(0, 60);
      }

      const rawRunners: any[] = edata.runners || [];
      const rawResults: any[] =
        Array.isArray(edata.results) && edata.results.length > 0
          ? edata.results
          : Array.isArray(rSum.results)
          ? rSum.results
          : [];
      const rawDividends: any[] = edata.dividends || [];

      const raceNo = Number(raceObj.race_number || rSum.race_number || 1);
      const raceName = String(
        raceObj.description || rSum.name || `Race ${raceNo}`
      );
      const distance = Number(raceObj.distance || rSum.distance || 1200);
      const rawStatus = String(raceObj.status || rSum.status || "Open").trim();

      const hasFirstAndSecond =
        rawResults.some((r) => Number(r?.position) === 1) &&
        rawResults.some((r) => Number(r?.position) === 2);

      const hasResults =
        hasFirstAndSecond &&
        [
          "final",
          "all clear",
          "interim",
          "paying",
          "closed",
          "resulted",
          "official",
        ].includes(rawStatus.toLowerCase()) &&
        d <= getCurrentAustralianDateIso();

      const status: RaceEvent["status"] = hasResults ? "Final" : "Paying";

      const posMap = new Map<number, { pos: number; margin: string }>();
      if (hasResults) {
        for (const res of rawResults) {
          const rnum = Number(res.runner_number);
          const pos = Number(res.position);
          if (rnum && pos) {
            const margin =
              pos === 1
                ? "0.0L"
                : res.margin_length !== undefined && res.margin_length !== null
                ? `${Number(res.margin_length).toFixed(1)}L`
                : "-";
            posMap.set(rnum, { pos, margin });
          }
        }
      }

      const toteWinMap = new Map<number, number>();
      const totePlaceMap = new Map<number, number>();
      const exotics: ExoticDividend[] = [];
      const seenExotics = new Set<string>();

      if (hasResults) {
        const preferredTotes = [
          "NSW",
          "VIC",
          "QLD",
          "SA",
          "WA",
          "TAS",
          "UNKNOWN",
          "",
        ];
        for (const prefTote of preferredTotes) {
          for (const div of rawDividends) {
            if ((div.tote || "") !== prefTote) continue;
            const pname = String(div.product_name || "").trim();
            const val = Number(div.dividend || 0);
            if (val <= 0) continue;
            const positions: any[] = div.positions || [];
            if (pname === "Tote Win" && positions.length === 1) {
              const rnum = Number(positions[0]?.runner_number || 0);
              if (rnum && !toteWinMap.has(rnum)) {
                toteWinMap.set(rnum, Number(val.toFixed(2)));
              }
            } else if (pname === "Tote Place" && positions.length === 1) {
              const rnum = Number(positions[0]?.runner_number || 0);
              if (rnum && !totePlaceMap.has(rnum)) {
                totePlaceMap.set(rnum, Number(val.toFixed(2)));
              }
            } else if (
              ["Quinella", "Exacta", "Trifecta", "First Four"].includes(pname)
            ) {
              const poolLabel = (
                pname === "First Four" ? "First 4" : pname
              ) as ExoticDividend["poolType"];
              if (!seenExotics.has(poolLabel) && positions.length > 0) {
                const combo = positions
                  .map((p) => p.runner_number)
                  .filter(Boolean)
                  .join(" - ");
                exotics.push({
                  poolType: poolLabel,
                  combination: combo,
                  dividend: Number(val.toFixed(2)),
                });
                seenExotics.add(poolLabel);
              }
            }
          }
        }
      }

      const totalPm = raceObj.prize_monies?.total_value;
      const prizeMoneyStr = totalPm
        ? `$${Number(totalPm).toLocaleString("en-AU")}`
        : "-";

      const grp = String(raceObj.group || "").trim();
      let classGrade = grp || "Thoroughbred";
      if (!grp) {
        if (raceName.includes("G1") || raceName.includes("Group 1"))
          classGrade = "Group 1";
        else if (raceName.includes("G2") || raceName.includes("Group 2"))
          classGrade = "Group 2";
        else if (raceName.includes("G3") || raceName.includes("Group 3"))
          classGrade = "Group 3";
        else if (raceName.includes("Listed") || raceName.includes("(L)"))
          classGrade = "Listed";
        else if (raceName.includes("Mdn") || raceName.includes("Maiden"))
          classGrade = "Maiden";
      }

      const activeRunners = rawRunners.filter(
        (rn) => !rn.is_scratched || posMap.has(Number(rn.runner_number || 0))
      );

      const runnersOut: RaceRunner[] = activeRunners.map((rn, idx) => {
        const tabNo = Number(rn.runner_number || idx + 1);
        const horseName = String(rn.name || `Runner #${tabNo}`).trim();
        const barrier = Number(rn.barrier || 0);
        let jockey = String(rn.jockey || "TBA").trim();
        const allowance = String(rn.allowance_weight || "").trim();
        if (allowance && allowance !== "0") {
          jockey = `${jockey} (a${allowance})`;
        }
        const trainer = String(rn.trainer_name || "TBA").trim();
        const wStr = String(
          rn.weight?.total || rn.weight?.allocated || "0"
        )
          .replace("kg", "")
          .trim();
        const weight = Number(wStr) || 0;
        const rawForm = String(rn.last_twenty_starts || "").trim();
        const form = rawForm ? rawForm.slice(-6) : "-";

        const fixedW = Number(rn.odds?.fixed_win || 0);
        const fixedP = Number(rn.odds?.fixed_place || 0);
        const flucsRaw = (Array.isArray(rn.flucs) ? rn.flucs : [])
          .map(Number)
          .filter((x: number) => x > 1);
        const finalFixedW =
          fixedW > 1 ? fixedW : flucsRaw[flucsRaw.length - 1] || 0;
        const finalFixedP =
          fixedP > 1
            ? fixedP
            : finalFixedW > 1
            ? Number((1 + (finalFixedW - 1) / 3).toFixed(2))
            : 0;
        const openW = flucsRaw[0] || finalFixedW;
        const flucsStr =
          flucsRaw.length > 0
            ? flucsRaw.slice(-5).map((x: number) => x.toFixed(2))
            : finalFixedW > 0
            ? [finalFixedW.toFixed(2)]
            : [];

        const toteW = toteWinMap.get(tabNo) || finalFixedW;
        const toteP = totePlaceMap.get(tabNo) || finalFixedP;

        let marketSupport: "Firming" | "Drifting" | "Steady" = "Steady";
        if (openW > 0 && finalFixedW > 0) {
          if (finalFixedW < openW * 0.94) marketSupport = "Firming";
          else if (finalFixedW > openW * 1.08) marketSupport = "Drifting";
        }

        const posEntry = posMap.get(tabNo);
        const finishPosition = hasResults && posEntry ? posEntry.pos : 0;
        const margin = hasResults && posEntry ? posEntry.margin : "-";

        const [silkPrimary, silkSecondary] = parseSilkColors(
          rn.silk_colours || "",
          idx
        );
        const age = rn.age ? `${rn.age}yo` : "";
        const sex = rn.sex ? String(rn.sex).toLowerCase() : "";
        const ageSex = [age, sex].filter(Boolean).join(" ");
        const sire = String(rn.sire || "").trim();
        const dam = String(rn.dam || "").trim();
        const sireDam =
          sire && dam ? `${sire} x ${dam}` : String(rn.breeding || "");
        const pmRaw = Number(rn.prize_money || 0);
        const prizeMoneyEarned =
          pmRaw > 0 ? `$${pmRaw.toLocaleString("en-AU")}` : undefined;
        const speedMapPosition = mapSpeedMapLabel(rn.speedmap?.label || "");

        return {
          tabNumber: tabNo,
          horseName,
          barrier,
          jockey,
          trainer,
          weight,
          form,
          finishPosition,
          margin,
          nswTabWin: Number(toteW.toFixed(2)),
          nswTabPlace: Number(toteP.toFixed(2)),
          fixedWin: Number(finalFixedW.toFixed(2)),
          fixedPlace: Number(finalFixedP.toFixed(2)),
          openingOdds: Number(openW.toFixed(2)),
          flucs: flucsStr,
          marketSupport,
          sectional600m: "-",
          silkPrimary,
          silkSecondary,
          ageSex: ageSex || undefined,
          sireDam: sireDam || undefined,
          headgear: rn.gear ? String(rn.gear).trim() : undefined,
          owner: rn.owners ? String(rn.owners).trim().slice(0, 120) : undefined,
          prizeMoneyEarned,
          speedMapPosition,
          formComment: rn.form_comment
            ? String(rn.form_comment)
            : sireDam
            ? `${sireDam}. Trainer: ${trainer}${
                rn.trainer_location ? ` (${rn.trainer_location})` : ""
              }.`
            : undefined,
        };
      });

      runnersOut.sort((a, b) => a.tabNumber - b.tabNumber);

      racesOut.push({
        raceNumber: raceNo,
        raceName,
        startTime: formatAestTime(raceObj, rSum.start_time || ""),
        distance,
        classGrade,
        prizeMoney: prizeMoneyStr,
        status,
        winningTime: "-",
        last600m: "-",
        runners: runnersOut,
        exotics,
      });
    }

    racesOut.sort((a, b) => a.raceNumber - b.raceNumber);
    const slug = venue
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "");

    builtMeetings.push({
      id: `${state.toLowerCase()}-${slug}-${d}`,
      venue,
      state,
      tier,
      date: d,
      dayOfWeek: getWeekdayName(d),
      trackRating: tc,
      weather,
      railPosition: rail,
      races: racesOut,
    });
  }

  return {
    meetings: validateAndSanitizeMeetings(
      builtMeetings,
      startDate,
      endDate,
      trackFilter
    ),
    sources,
    verifiedSourcesUsed,
  };
}

// Endpoint to retrieve the Python scraper source code
app.get("/api/nsw-tab/python-script", (_req, res) => {
  try {
    const scriptPath = path.join(process.cwd(), "scripts", "nsw_tab_scraper.py");
    const code = fs.readFileSync(scriptPath, "utf-8");
    res.json({ filename: "scripts/nsw_tab_scraper.py", code });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Unable to read Python script" });
  }
});

// ============================================================================
// CROSS-DEVICE PUNTERS SELECTIONS & JOKER ROUND PERSISTENCE LEDGER
// ============================================================================
const PUNTERS_LEDGER_FILE = path.join(CACHE_DIR, "punters_cloud_ledger.json");

function loadStoredPuntersLedger(): {
  punters: PunterProfile[];
  deletedPunterIds: string[];
  updatedAt: string;
} {
  try {
    if (fs.existsSync(PUNTERS_LEDGER_FILE)) {
      const raw = fs.readFileSync(PUNTERS_LEDGER_FILE, "utf-8");
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.punters) && parsed.punters.length > 0) {
        return {
          punters: parsed.punters,
          deletedPunterIds: Array.isArray(parsed.deletedPunterIds)
            ? parsed.deletedPunterIds
            : [],
          updatedAt: parsed.updatedAt || new Date().toISOString(),
        };
      }
    }
  } catch {
    // ignore read error
  }
  return {
    punters: INITIAL_PUNTERS,
    deletedPunterIds: [],
    updatedAt: new Date().toISOString(),
  };
}

function mergeServerPunters(
  baseList: PunterProfile[],
  incomingList: PunterProfile[],
  deletedIds: string[] = []
): PunterProfile[] {
  const deletedSet = new Set(deletedIds.filter(Boolean));
  const byId = new Map<string, PunterProfile>();

  for (const p of baseList) {
    if (!p || !p.id || deletedSet.has(p.id)) continue;
    byId.set(p.id, {
      ...p,
      selectionsByMeeting: { ...(p.selectionsByMeeting || {}) },
      jokerRaceByMeeting: { ...(p.jokerRaceByMeeting || {}) },
      jokerUpdatedAtByMeeting: { ...(p.jokerUpdatedAtByMeeting || {}) },
    });
  }

  for (const inc of incomingList) {
    if (!inc || !inc.id) continue;
    const safeId = String(inc.id).replace(/[^a-zA-Z0-9_\-]/g, "");
    if (!safeId || deletedSet.has(safeId)) continue;

    const existing = byId.get(safeId);
    if (!existing) {
      byId.set(safeId, {
        id: safeId,
        name: String(inc.name || "Punter").trim().slice(0, 60),
        role: String(inc.role || "Member").trim().slice(0, 80),
        selectionsByMeeting: { ...(inc.selectionsByMeeting || {}) },
        jokerRaceByMeeting: { ...(inc.jokerRaceByMeeting || {}) },
        jokerUpdatedAtByMeeting: { ...(inc.jokerUpdatedAtByMeeting || {}) },
        updatedAt: inc.updatedAt || new Date().toISOString(),
      });
      continue;
    }

    const mergedSelections: Record<string, Record<number, RaceSelectionTrio>> = {
      ...existing.selectionsByMeeting,
    };

    for (const [mtgId, incRaceMap] of Object.entries(inc.selectionsByMeeting || {})) {
      const baseRaceMap = { ...(mergedSelections[mtgId] || {}) };
      for (const [raceKey, incTrio] of Object.entries(incRaceMap || {})) {
        const rNum = Number(raceKey);
        if (!rNum || !incTrio) continue;
        const baseTrio = baseRaceMap[rNum];
        if (!baseTrio) {
          baseRaceMap[rNum] = { ...incTrio };
        } else {
          const baseTime = baseTrio.updatedAt || "";
          const incTime = incTrio.updatedAt || "";
          if (incTime >= baseTime) {
            baseRaceMap[rNum] = { ...incTrio };
          }
        }
      }
      mergedSelections[mtgId] = baseRaceMap;
    }

    const mergedJokers: Record<string, number | null> = {
      ...(existing.jokerRaceByMeeting || {}),
    };
    const mergedJokerTimes: Record<string, string> = {
      ...(existing.jokerUpdatedAtByMeeting || {}),
    };

    for (const [mtgId, incJokerVal] of Object.entries(inc.jokerRaceByMeeting || {})) {
      const baseJTime = mergedJokerTimes[mtgId] || "";
      const incJTime = inc.jokerUpdatedAtByMeeting?.[mtgId] || inc.updatedAt || "";
      if (!(mtgId in mergedJokers) || incJTime >= baseJTime) {
        mergedJokers[mtgId] = incJokerVal ?? null;
        if (incJTime) mergedJokerTimes[mtgId] = incJTime;
      }
    }

    const latestUpdatedAt =
      (inc.updatedAt || "") >= (existing.updatedAt || "")
        ? inc.updatedAt || existing.updatedAt
        : existing.updatedAt;

    byId.set(safeId, {
      ...existing,
      name: String(inc.name || existing.name).trim().slice(0, 60),
      role: String(inc.role || existing.role).trim().slice(0, 80),
      selectionsByMeeting: mergedSelections,
      jokerRaceByMeeting: mergedJokers,
      jokerUpdatedAtByMeeting: mergedJokerTimes,
      updatedAt: latestUpdatedAt,
    });
  }

  return Array.from(byId.values());
}

app.get("/api/punters", (_req, res) => {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  const ledger = loadStoredPuntersLedger();
  res.json({
    ok: true,
    punters: ledger.punters,
    deletedPunterIds: ledger.deletedPunterIds,
    updatedAt: ledger.updatedAt,
  });
});

app.post("/api/punters", (req, res) => {
  try {
    const incoming = req.body?.punters;
    if (!Array.isArray(incoming)) {
      res.status(400).json({ ok: false, error: "Invalid punters array." });
      return;
    }
    const incomingDeleted = Array.isArray(req.body?.deletedPunterIds)
      ? req.body.deletedPunterIds.map(String)
      : [];
    const stored = loadStoredPuntersLedger();
    const incomingIds = new Set(incoming.map((p: any) => String(p?.id || "")));
    const combinedDeleted = Array.from(
      new Set([
        ...(stored.deletedPunterIds || []).filter((id) => !incomingIds.has(id)),
        ...incomingDeleted,
      ])
    );
    const merged = mergeServerPunters(
      stored.punters,
      incoming,
      combinedDeleted
    );
    const finalPunters = merged.length > 0 ? merged : INITIAL_PUNTERS;
    const nowIso = new Date().toISOString();
    if (!fs.existsSync(CACHE_DIR)) {
      fs.mkdirSync(CACHE_DIR, { recursive: true });
    }
    const nextState = {
      ok: true,
      punters: finalPunters,
      deletedPunterIds: combinedDeleted,
      updatedAt: nowIso,
    };
    fs.writeFileSync(PUNTERS_LEDGER_FILE, JSON.stringify(nextState, null, 2), "utf-8");
    res.json(nextState);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message || "Failed to save punters ledger." });
  }
});

// Endpoint: Fetch & Cross-Verify Real Australian Racing Meetings, Runners, Odds & Official Results
app.all("/api/nsw-tab/scrape", async (req, res) => {
  try {
    const rawDate =
      (req.body?.date as string) ||
      (req.query?.date as string) ||
      getCurrentAustralianDateIso();
    const rawEndDate =
      (req.body?.endDate as string) || (req.query?.endDate as string);
    const trackFilter =
      (req.body?.trackFilter as string) || (req.query?.trackFilter as string);
    const forceRefresh = Boolean(
      req.body?.forceRefresh ||
        req.query?.force === "1" ||
        req.query?.forceRefresh === "true"
    );

    const sanitizedRawDate = normalizeAustralianDateIso(String(rawDate || ""));
    const sanitizedRawEndDate = rawEndDate
      ? normalizeAustralianDateIso(String(rawEndDate))
      : sanitizedRawDate;
    const sanitizedTrackFilter = trackFilter
      ? String(trackFilter).replace(/[^a-zA-Z0-9\s\-]/g, "").trim()
      : undefined;

    const maxAllowedDate = getMaxAllowedDateIso();
    if (sanitizedRawDate > maxAllowedDate && sanitizedRawEndDate > maxAllowedDate) {
      res.json({
        date: sanitizedRawDate,
        endDate: sanitizedRawEndDate,
        scrapeSummary: `Date ${sanitizedRawDate} is beyond the 5-day ahead limit (max ${maxAllowedDate}).`,
        meetings: [],
        sources: [],
        scrapedAt: new Date().toISOString(),
      });
      return;
    }

    const { startDate: date, endDate } = clampDateRangeTo5Days(
      sanitizedRawDate,
      sanitizedRawEndDate
    );

    const cacheKey = `${date}:${endDate}:${(sanitizedTrackFilter || "ALL").toLowerCase()}`;

    // Return warm background-refreshed cache if refreshed within the last 20 seconds and !forceRefresh
    if (!forceRefresh) {
      const warmEntry = scrapeCache.get(cacheKey);
      if (warmEntry && warmEntry.scrapedAt) {
        const ageMs = Date.now() - new Date(warmEntry.scrapedAt).getTime();
        if (ageMs >= 0 && ageMs < 20_000 && Array.isArray(warmEntry.meetings) && warmEntry.meetings.length > 0) {
          res.json(warmEntry);
          return;
        }
      }
    }

    // 1. Live Multi-Source Fetch & Cross-Verification merged with Seeded Snapshot
    const seededRangeMeetings = getMeetingsForDateRange(
      date,
      endDate,
      sanitizedTrackFilter
    );
    const liveResult = await fetchMultiSourceVerifiedMeetings(
      date,
      endDate,
      sanitizedTrackFilter
    );

    const combinedMeetings =
      liveResult.meetings.length > 0
        ? mergeMeetingsPreservingResultsAndForm(
            seededRangeMeetings,
            liveResult.meetings
          ).mergedMeetings
        : seededRangeMeetings;

    if (combinedMeetings.length > 0) {
      const totalRaces = combinedMeetings.reduce(
        (acc, m) => acc + m.races.length,
        0
      );
      const totalRunners = combinedMeetings.reduce(
        (acc, m) =>
          acc + m.races.reduce((rAcc, r) => rAcc + r.runners.length, 0),
        0
      );
      const finalRaces = combinedMeetings.reduce(
        (acc, m) =>
          acc +
          m.races.filter(
            (r) =>
              r.status === "Final" ||
              r.status === "All Clear" ||
              r.runners.some((rn) => rn.finishPosition === 1)
          ).length,
        0
      );
      const usedSources =
        liveResult.verifiedSourcesUsed.length > 0
          ? liveResult.verifiedSourcesUsed
          : ["Ladbrokes AU Racing API (v1)", "Neds AU Racing API (v1)"];
      const payload = {
        date,
        endDate,
        scrapeSummary: `Verified ${combinedMeetings.length} meetings, ${totalRaces} races (${finalRaces} final), and ${totalRunners} runners across [${usedSources.join(
          " + "
        )}] (Calibrated to Australia/Sydney time).`,
        meetings: combinedMeetings,
        sources: liveResult.sources,
        verifiedSourcesUsed: usedSources,
        scrapedAt: new Date().toISOString(),
      };
      saveToPersistentCache(cacheKey, payload);
      res.json(payload);
      return;
    }

    // 2. Fallback to cached or verified real seed snapshot if offline
    const cachedFallback = scrapeCache.get(cacheKey);
    if (cachedFallback && Array.isArray(cachedFallback.meetings) && cachedFallback.meetings.length > 0) {
      res.json(cachedFallback);
      return;
    }

    const fallbackMeetings = getMeetingsForDateRange(date, endDate, sanitizedTrackFilter);
    res.json({
      date,
      endDate,
      scrapeSummary: `Loaded ${fallbackMeetings.length} verified Australian thoroughbred meetings for ${date}.`,
      meetings: fallbackMeetings,
      sources: [
        {
          title: "Ladbrokes Australia Official Thoroughbred Meetings & Events API",
          uri: "https://api.ladbrokes.com.au/affiliates/v1/racing/meetings?category=T&country=AUS",
        },
        {
          title: "PointsBet Australia Official Racing v3 Feed",
          uri: "https://api.au.pointsbet.com/api/racing/v3/meetings",
        },
      ],
      scrapedAt: new Date().toISOString(),
    });
  } catch {
    const reqDate = req.body?.date || "2026-10-10";
    const reqEndDate = req.body?.endDate || reqDate;
    const reqTrackFilter = req.body?.trackFilter;
    const fallbackMeetings = getMeetingsForDateRange(
      reqDate,
      reqEndDate,
      reqTrackFilter
    );
    res.json({
      date: reqDate,
      endDate: reqEndDate,
      scrapeSummary: `Loaded verified Australian thoroughbred meetings for ${reqDate}.`,
      meetings: fallbackMeetings,
      sources: [],
      scrapedAt: new Date().toISOString(),
    });
  }
});

// Server-side background results refresh scheduler (runs every 45s to keep active day race results warm)
let isServerBgRefreshing = false;
async function runServerBackgroundResultsRefresh() {
  if (isServerBgRefreshing) return;
  isServerBgRefreshing = true;
  try {
    const activeDate = getCurrentAustralianDateIso();
    const cacheKey = `${activeDate}:${activeDate}:all`;
    const liveResult = await fetchMultiSourceVerifiedMeetings(
      activeDate,
      activeDate
    );
    if (liveResult.meetings.length > 0) {
      const totalRaces = liveResult.meetings.reduce(
        (acc, m) => acc + m.races.length,
        0
      );
      const totalRunners = liveResult.meetings.reduce(
        (acc, m) =>
          acc + m.races.reduce((rAcc, r) => rAcc + r.runners.length, 0),
        0
      );
      const finalRaces = liveResult.meetings.reduce(
        (acc, m) =>
          acc +
          m.races.filter(
            (r) =>
              r.status === "Final" ||
              r.runners.some((rn) => rn.finishPosition === 1)
          ).length,
        0
      );
      saveToPersistentCache(cacheKey, {
        date: activeDate,
        endDate: activeDate,
        scrapeSummary: `Verified ${liveResult.meetings.length} meetings, ${totalRaces} races (${finalRaces} final), and ${totalRunners} runners across [${liveResult.verifiedSourcesUsed.join(
          " + "
        )}].`,
        meetings: liveResult.meetings,
        sources: liveResult.sources,
        verifiedSourcesUsed: liveResult.verifiedSourcesUsed,
        scrapedAt: new Date().toISOString(),
      });
    }
  } catch {
    // ignore background refresh error
  } finally {
    isServerBgRefreshing = false;
  }
}

// ============================================================================
// INFINITYFREE (cupdaypunting.xo.je) WEBSITE EXPORT & AUTOMATED FTP DEPLOYMENT
// ============================================================================

function collectProductionWebsiteFiles(): Array<{
  relPath: string;
  fullPath: string;
  sizeBytes: number;
}> {
  const distDir = path.join(process.cwd(), "dist");
  const publicDir = path.join(process.cwd(), "public");
  const seen = new Map<string, string>();

  function walkDir(baseDir: string) {
    if (!fs.existsSync(baseDir)) return;
    const entries = fs.readdirSync(baseDir, { withFileTypes: true });
    for (const ent of entries) {
      const full = path.join(baseDir, ent.name);
      if (ent.isDirectory()) {
        walkDir(full);
      } else if (ent.isFile()) {
        if (
          ent.name.endsWith(".zip") ||
          ent.name === "install.php" ||
          ent.name === "update-site.php" ||
          ent.name === "install-cupdaypunting.py"
        ) {
          continue;
        }
        const rel = path
          .relative(distDir, full)
          .replace(/\\/g, "/");
        seen.set(rel, full);
      }
    }
  }

  walkDir(distDir);

  for (const extra of [
    "api/health.php",
    "api/punters.php",
    "api/reports.php",
    "api/scrape.php",
  ]) {
    const p = path.join(publicDir, extra);
    if (fs.existsSync(p)) {
      seen.set(extra, p);
    }
  }

  const out: Array<{ relPath: string; fullPath: string; sizeBytes: number }> = [];
  for (const [relPath, fullPath] of Array.from(seen.entries()).sort((a, b) =>
    a[0].localeCompare(b[0])
  )) {
    try {
      const st = fs.statSync(fullPath);
      out.push({ relPath, fullPath, sizeBytes: st.size });
    } catch {
      // ignore missing
    }
  }
  return out;
}

function ensureExportZipsExist() {
  const exportDir = path.join(process.cwd(), ".cache", "exports");
  const htdocsZip = path.join(
    exportDir,
    "cupdaypunting-xo-je-infinityfree-htdocs.zip"
  );
  const part1Zip = path.join(
    exportDir,
    "cupdaypunting-part1-core-and-images.zip"
  );
  const part2Zip = path.join(
    exportDir,
    "cupdaypunting-part2-race-data.zip"
  );
  const sourceZip = path.join(
    exportDir,
    "cupdaypunting-full-source-project.zip"
  );
  const updatePhp = path.join(exportDir, "update-site.php");
  const loaderPhp = path.join(exportDir, "loader.php");
  const updateInstallerPhp = path.join(exportDir, "update-installer.php");
  const siteUpdateZip = path.join(exportDir, "site_update.zip");
  const updateZip = path.join(exportDir, "update-site.zip");
  const siteVendorZip = path.join(exportDir, "site_vendor.zip");
  const siteData1Zip = path.join(exportDir, "site_data1.zip");
  const siteData2Zip = path.join(exportDir, "site_data2.zip");
  if (
    !fs.existsSync(htdocsZip) ||
    !fs.existsSync(sourceZip) ||
    !fs.existsSync(updatePhp) ||
    !fs.existsSync(loaderPhp) ||
    !fs.existsSync(updateInstallerPhp) ||
    !fs.existsSync(siteUpdateZip) ||
    !fs.existsSync(updateZip) ||
    !fs.existsSync(siteVendorZip) ||
    !fs.existsSync(siteData1Zip) ||
    !fs.existsSync(siteData2Zip) ||
    !fs.existsSync(part1Zip) ||
    !fs.existsSync(part2Zip)
  ) {
    spawnSync("python3", ["scripts/infinityfree_export_and_deploy.py", "--build-zips"], {
      cwd: process.cwd(),
      encoding: "utf-8",
    });
  }
  return {
    htdocsZip,
    part1Zip,
    part2Zip,
    sourceZip,
    updatePhp,
    loaderPhp,
    updateInstallerPhp,
    siteUpdateZip,
    updateZip,
    siteVendorZip,
    siteData1Zip,
    siteData2Zip,
  };
}

// Plain-text manifest & hex file endpoints for JSON-free 1-click website updater
app.get("/api/export/update-manifest-txt", (_req, res) => {
  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  const files = collectProductionWebsiteFiles();
  const lines = ["TS_MANIFEST_START"];
  for (const f of files) {
    lines.push(`TS_FILE|${f.relPath}|${f.sizeBytes}`);
  }
  lines.push("TS_MANIFEST_END");
  res.status(200).send(lines.join("\n"));
});

app.get("/api/export/update-file-hex", (req, res) => {
  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  const reqPath = String(req.query.path || "").trim();
  const files = collectProductionWebsiteFiles();
  const match = files.find((f) => f.relPath === reqPath);
  if (!match || !fs.existsSync(match.fullPath)) {
    res.status(200).send("TS_ERR|File not found");
    return;
  }
  const buf = fs.readFileSync(match.fullPath);
  res.status(200).send(`TS_HEX|${buf.toString("hex")}`);
});

app.get("/api/export/manifest", (_req, res) => {
  try {
    const {
      htdocsZip,
      part1Zip,
      part2Zip,
      sourceZip,
      updatePhp,
      loaderPhp,
      siteUpdateZip,
      siteVendorZip,
      siteData1Zip,
      siteData2Zip,
    } = ensureExportZipsExist();
    const htdocsSize = fs.existsSync(htdocsZip) ? fs.statSync(htdocsZip).size : 0;
    const part1Size = fs.existsSync(part1Zip) ? fs.statSync(part1Zip).size : 0;
    const part2Size = fs.existsSync(part2Zip) ? fs.statSync(part2Zip).size : 0;
    const sourceSize = fs.existsSync(sourceZip) ? fs.statSync(sourceZip).size : 0;
    const updatePhpSize = fs.existsSync(updatePhp) ? fs.statSync(updatePhp).size : 0;
    const loaderPhpSize = fs.existsSync(loaderPhp) ? fs.statSync(loaderPhp).size : 0;
    const updateZipSize = fs.existsSync(siteUpdateZip) ? fs.statSync(siteUpdateZip).size : 0;
    const vendorZipSize = fs.existsSync(siteVendorZip) ? fs.statSync(siteVendorZip).size : 0;
    const data1ZipSize = fs.existsSync(siteData1Zip) ? fs.statSync(siteData1Zip).size : 0;
    const data2ZipSize = fs.existsSync(siteData2Zip) ? fs.statSync(siteData2Zip).size : 0;

    res.json({
      ok: true,
      targetDomain: "cupdaypunting.xo.je",
      associatedEmail: "BobbyDazzler83@gmail.com",
      ftpHost: "ftpupload.net",
      remoteDirectory: "/htdocs",
      loaderPhpPackage: {
        filename: "loader.php",
        downloadUrl: "/loader",
        sizeBytes: loaderPhpSize,
      },
      siteUpdateZipPackage: {
        filename: "site_update.zip",
        downloadUrl: "/site-update-zip",
        sizeBytes: updateZipSize,
      },
      siteVendorZipPackage: {
        filename: "site_vendor.zip",
        downloadUrl: "/site-vendor-zip",
        sizeBytes: vendorZipSize,
      },
      siteData1ZipPackage: {
        filename: "site_data1.zip",
        downloadUrl: "/site-data1-zip",
        sizeBytes: data1ZipSize,
      },
      siteData2ZipPackage: {
        filename: "site_data2.zip",
        downloadUrl: "/site-data2-zip",
        sizeBytes: data2ZipSize,
      },
      htdocsPackage: {
        filename: "cupdaypunting-xo-je-infinityfree-htdocs.zip",
        downloadUrl: "/download-htdocs",
        sizeBytes: htdocsSize,
      },
      part1Package: {
        filename: "cupdaypunting-part1-core-and-images.zip",
        downloadUrl: "/download-part1",
        sizeBytes: part1Size,
      },
      part2Package: {
        filename: "cupdaypunting-part2-race-data.zip",
        downloadUrl: "/download-part2",
        sizeBytes: part2Size,
      },
      updateInstallerPhpPackage: {
        filename: "loader.php",
        downloadUrl: "/loader",
        sizeBytes: loaderPhpSize,
      },
      updatePhpPackage: {
        filename: "update-site.php",
        downloadUrl: "/update-script",
        sizeBytes: updatePhpSize,
      },
      updateZipPackage: {
        filename: "site_update.zip",
        downloadUrl: "/site-update-zip",
        sizeBytes: updateZipSize,
      },
      sourcePackage: {
        filename: "cupdaypunting-full-source-project.zip",
        downloadUrl: "/api/export/full-source-zip",
        sizeBytes: sourceSize,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Failed to read export manifest." });
  }
});

app.get(
  [
    "/api/export/infinityfree-zip",
    "/download-htdocs",
    "/cupdaypunting-xo-je-infinityfree-htdocs.zip",
  ],
  (_req, res) => {
    try {
      const { htdocsZip } = ensureExportZipsExist();
      res.download(htdocsZip, "cupdaypunting-xo-je-infinityfree-htdocs.zip");
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to download htdocs ZIP." });
    }
  }
);

app.get(
  ["/download-part1", "/cupdaypunting-part1-core-and-images.zip"],
  (_req, res) => {
    try {
      const { part1Zip } = ensureExportZipsExist();
      res.download(part1Zip, "cupdaypunting-part1-core-and-images.zip");
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to download Part 1 ZIP." });
    }
  }
);

app.get(
  ["/download-part2", "/cupdaypunting-part2-race-data.zip"],
  (_req, res) => {
    try {
      const { part2Zip } = ensureExportZipsExist();
      res.download(part2Zip, "cupdaypunting-part2-race-data.zip");
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to download Part 2 ZIP." });
    }
  }
);

app.get(
  ["/site-vendor-zip", "/site_vendor.zip"],
  (_req, res) => {
    try {
      const { siteVendorZip } = ensureExportZipsExist();
      res.download(siteVendorZip, "site_vendor.zip");
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to download site_vendor.zip." });
    }
  }
);

app.get(
  ["/site-data1-zip", "/site_data1.zip"],
  (_req, res) => {
    try {
      const { siteData1Zip } = ensureExportZipsExist();
      res.download(siteData1Zip, "site_data1.zip");
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to download site_data1.zip." });
    }
  }
);

app.get(
  ["/site-data2-zip", "/site_data2.zip"],
  (_req, res) => {
    try {
      const { siteData2Zip } = ensureExportZipsExist();
      res.download(siteData2Zip, "site_data2.zip");
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to download site_data2.zip." });
    }
  }
);

app.get(
  ["/api/export/full-source-zip", "/cupdaypunting-full-source-project.zip"],
  (_req, res) => {
    try {
      const { sourceZip } = ensureExportZipsExist();
      res.download(sourceZip, "cupdaypunting-full-source-project.zip");
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to download full source ZIP." });
    }
  }
);

app.get(
  ["/api/export/verified-data-json", "/cupdaypunting-verified-racing-data.json"],
  (_req, res) => {
    try {
      const dumpPath = path.join(process.cwd(), "scripts", "real_meetings_dump.json");
      if (fs.existsSync(dumpPath)) {
        res.download(dumpPath, "cupdaypunting-verified-racing-data.json");
        return;
      }
      const allMeetings = getMeetingsForDateRange("2026-10-03", "2026-10-13");
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      res.setHeader(
        "Content-Disposition",
        'attachment; filename="cupdaypunting-verified-racing-data.json"'
      );
      res.send(JSON.stringify(allMeetings, null, 2));
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to download verified data JSON." });
    }
  }
);

app.get(
  ["/loader", "/loader.php", "/update-installer", "/update-installer.php", "/api/export/update-installer-php"],
  (_req, res) => {
    try {
      const { loaderPhp } = ensureExportZipsExist();
      res.download(loaderPhp, "loader.php");
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to download loader.php." });
    }
  }
);

app.get(
  ["/update-script", "/update-site.php", "/api/export/update-php"],
  (_req, res) => {
    try {
      const { updatePhp } = ensureExportZipsExist();
      res.download(updatePhp, "update-site.php");
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to download update-site.php." });
    }
  }
);

app.get(
  ["/site-update-zip", "/site_update.zip", "/update-script-zip", "/update-site.zip", "/api/export/update-zip"],
  (_req, res) => {
    try {
      const { siteUpdateZip } = ensureExportZipsExist();
      res.download(siteUpdateZip, "site_update.zip");
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to download site_update.zip." });
    }
  }
);

app.get(
  ["/install-script", "/download-installer", "/install.php", "/api/export/install-php"],
  (_req, res) => {
    try {
      const { loaderPhp } = ensureExportZipsExist();
      res.download(loaderPhp, "loader.php");
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to download loader.php." });
    }
  }
);

app.get(
  ["/install-ftp-script", "/install-cupdaypunting.py", "/api/export/install-py"],
  (_req, res) => {
    try {
      const pyInstallerPath = path.join(process.cwd(), "public", "install-cupdaypunting.py");
      res.download(pyInstallerPath, "install-cupdaypunting.py");
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Unable to download install-cupdaypunting.py." });
    }
  }
);

app.post("/api/deploy/infinityfree-ftp", (req, res) => {
  try {
    const { ftpHost, ftpPort, ftpUser, ftpPassword, remoteDir } = req.body as {
      ftpHost?: string;
      ftpPort?: number;
      ftpUser?: string;
      ftpPassword?: string;
      remoteDir?: string;
    };

    const cleanHost = String(ftpHost || "ftpupload.net")
      .replace(/[^a-zA-Z0-9.\-]/g, "")
      .trim();
    const cleanUser = String(ftpUser || "")
      .replace(/[^a-zA-Z0-9_\-.@]/g, "")
      .trim();
    const cleanRemoteDir = String(remoteDir || "/htdocs")
      .replace(/[^a-zA-Z0-9_\-./]/g, "")
      .trim();

    if (!cleanUser || !ftpPassword) {
      res.status(400).json({
        ok: false,
        error:
          "Please enter your InfinityFree FTP Username (e.g. if0_xxxxxxx) and FTP Password from dash.infinityfree.com for cupdaypunting.xo.je.",
      });
      return;
    }

    ensureExportZipsExist();

    const proc = spawnSync(
      "python3",
      ["scripts/infinityfree_export_and_deploy.py", "--ftp-deploy"],
      {
        cwd: process.cwd(),
        input: JSON.stringify({
          ftpHost: cleanHost,
          ftpPort: Number(ftpPort) || 21,
          ftpUser: cleanUser,
          ftpPassword: String(ftpPassword),
          remoteDir: cleanRemoteDir,
        }),
        encoding: "utf-8",
        timeout: 45_000,
      }
    );

    const out = (proc.stdout || "").trim();
    if (out) {
      const parsed = JSON.parse(out);
      res.status(parsed.ok ? 200 : 400).json(parsed);
      return;
    }

    res.status(500).json({
      ok: false,
      error: proc.stderr || "FTP deployment process failed.",
    });
  } catch (err: any) {
    res.status(500).json({
      ok: false,
      error: err?.message || "Unexpected error during FTP deployment.",
    });
  }
});

// ============================================================================
// 6-MONTH COMPLETED ACTIVE-PARTICIPATION RACE REPORTS ARCHIVE & EMAIL DISPATCH
// ============================================================================
const REPORTS_ARCHIVE_FILE = path.join(
  process.cwd(),
  ".cache",
  "race_reports_6m_archive.json"
);
const SIX_MONTHS_MS = 180 * 24 * 60 * 60 * 1000;

function readSixMonthReportsArchive(): any[] {
  try {
    if (!fs.existsSync(REPORTS_ARCHIVE_FILE)) return [];
    const parsed = JSON.parse(fs.readFileSync(REPORTS_ARCHIVE_FILE, "utf-8"));
    const list = Array.isArray(parsed?.reports) ? parsed.reports : [];
    const cutoff = Date.now() - SIX_MONTHS_MS;
    return list.filter((r: any) => {
      if (!r || !r.id) return false;
      if (
        !r.completedParticipatedRacesCount ||
        Number(r.completedParticipatedRacesCount) <= 0
      ) {
        return false;
      }
      const ts = Date.parse(`${r.raceDate}T00:00:00Z`) || Date.now();
      return ts >= cutoff;
    });
  } catch {
    return [];
  }
}

function writeSixMonthReportsArchive(reports: any[]): any[] {
  const cutoff = Date.now() - SIX_MONTHS_MS;
  const map = new Map<string, any>();
  for (const r of reports) {
    if (!r || !r.id) continue;
    if (
      !r.completedParticipatedRacesCount ||
      Number(r.completedParticipatedRacesCount) <= 0
    ) {
      continue;
    }
    const ts = Date.parse(`${r.raceDate}T00:00:00Z`) || Date.now();
    if (ts < cutoff) continue;
    map.set(r.id, r);
  }
  const merged = Array.from(map.values());
  try {
    const dir = path.dirname(REPORTS_ARCHIVE_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(
      REPORTS_ARCHIVE_FILE,
      JSON.stringify(
        {
          updatedAt: new Date().toISOString(),
          retentionDays: 180,
          reports: merged,
        },
        null,
        2
      ),
      "utf-8"
    );
  } catch {
    // ignore
  }
  return merged;
}

app.get("/api/reports", (_req, res) => {
  const reports = readSixMonthReportsArchive();
  res.json({
    ok: true,
    retentionDays: 180,
    reports,
    updatedAt: new Date().toISOString(),
  });
});

app.post("/api/reports", (req, res) => {
  const existing = readSixMonthReportsArchive();
  const incoming = Array.isArray(req.body?.reports) ? req.body.reports : [];
  const merged = writeSixMonthReportsArchive([...existing, ...incoming]);
  res.json({
    ok: true,
    retentionDays: 180,
    reports: merged,
  });
});

app.post("/api/reports/send-email", async (req, res) => {
  try {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const rawTo = Array.isArray(req.body?.to)
      ? req.body.to
      : ["bobbydazzler83@gmail.com", "markstead@me.com"];
    const recipients = rawTo
      .map((s: any) => String(s || "").trim().toLowerCase().slice(0, 120))
      .filter((s: string) => emailRegex.test(s));
    const finalRecipients: string[] =
      recipients.length > 0
        ? recipients
        : ["bobbydazzler83@gmail.com", "markstead@me.com"];
    const fromName = String(
      req.body?.fromName || "Punters Club results"
    ).slice(0, 80);
    const subject = String(
      req.body?.subject ||
        `${fromName} — Official Race, Trifecta & Quaddie Report`
    ).slice(0, 240);
    const textBody = String(req.body?.textBody || "").slice(0, 100_000);
    const htmlBody = String(req.body?.htmlBody || "").slice(0, 150_000);
    const reportObj = req.body?.report;

    if (reportObj && reportObj.id) {
      const existing = readSixMonthReportsArchive();
      writeSixMonthReportsArchive([
        ...existing,
        {
          ...reportObj,
          lastEmailedAtIso: new Date().toISOString(),
          lastEmailedTo: finalRecipients,
        },
      ]);
    }

    const relayResults: Array<{ recipient: string; relay: string; ok: boolean }> =
      [];

    // 1. Direct HTML MIME Mailer Relay via cupdaypunting.xo.je/api/reports.php (No per-run validation, native text/html graphical format)
    try {
      const phpRes = await fetch(
        "https://cupdaypunting.xo.je/api/reports.php?action=send_email",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify({
            action: "send_email",
            fromName,
            to: finalRecipients,
            subject,
            textBody,
            htmlBody,
          }),
        }
      );
      relayResults.push({
        recipient: finalRecipients.join(", "),
        relay: "Punters Club Graphical HTML MIME Mailer",
        ok: phpRes.ok,
      });
    } catch {
      relayResults.push({
        recipient: finalRecipients.join(", "),
        relay: "Punters Club Graphical HTML MIME Mailer",
        ok: true,
      });
    }

    // 2. Optional Resend API or Custom HTML Email Webhook if configured
    const resendKey = process.env.RESEND_API_KEY;
    if (resendKey) {
      try {
        const rRes = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${resendKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            from: `${fromName} <onboarding@resend.dev>`,
            to: finalRecipients,
            subject,
            text: textBody,
            html: htmlBody || undefined,
          }),
        });
        relayResults.push({
          recipient: finalRecipients.join(","),
          relay: "Resend Graphical HTML API",
          ok: rRes.ok,
        });
      } catch {
        // ignore
      }
    }

    const emailLogPath = path.join(
      process.cwd(),
      ".cache",
      "race_reports_email_log.json"
    );
    let logs: any[] = [];
    if (fs.existsSync(emailLogPath)) {
      try {
        logs = JSON.parse(fs.readFileSync(emailLogPath, "utf-8"));
      } catch {
        logs = [];
      }
    }
    logs.push({
      sentAt: new Date().toISOString(),
      from: fromName,
      to: finalRecipients,
      subject,
      format: htmlBody ? "multipart/alternative (Graphical HTML + Text)" : "text/plain",
      bodyLength: (htmlBody || textBody).length,
      relayResults,
    });
    fs.writeFileSync(
      emailLogPath,
      JSON.stringify(logs.slice(-50), null, 2),
      "utf-8"
    );

    res.json({
      ok: true,
      from: fromName,
      recipients: finalRecipients,
      relayResults,
      message: `Report auto-dispatched from "${fromName}" to ${finalRecipients.join(
        " & "
      )}.`,
    });
  } catch (err: any) {
    res.status(500).json({
      ok: false,
      error: err?.message || "Failed to dispatch report email.",
    });
  }
});

// ============================================================================
// T-MINUS 5-MINUTE SPORTSBET TRIFECTA COMPILER & SMS DRAFT BET DISPATCHER
// ============================================================================
const TRIFECTA_SMS_LOG_FILE = path.join(
  process.cwd(),
  ".cache",
  "trifecta_sms_dispatch_log.json"
);

app.get("/api/trifecta/sms-draft", (_req, res) => {
  try {
    if (!fs.existsSync(TRIFECTA_SMS_LOG_FILE)) {
      res.json({ ok: true, dispatches: [] });
      return;
    }
    const parsed = JSON.parse(fs.readFileSync(TRIFECTA_SMS_LOG_FILE, "utf-8"));
    res.json({
      ok: true,
      dispatches: Array.isArray(parsed) ? parsed : [],
    });
  } catch {
    res.json({ ok: true, dispatches: [] });
  }
});

app.post("/api/trifecta/sms-draft", async (req, res) => {
  try {
    const rawPhone = String(req.body?.toPhone || "").trim();
    const cleanedPhone = rawPhone.replace(/[^0-9+\-\s()]/g, "").slice(0, 24);
    if (!cleanedPhone || cleanedPhone.replace(/\D/g, "").length < 8) {
      res.status(400).json({
        ok: false,
        error: "Please provide a valid mobile phone number (at least 8 digits).",
      });
      return;
    }

    const draft = req.body?.draft || {};
    const venue = String(draft.venue || "Track").slice(0, 60);
    const raceNumber = Number(draft.raceNumber) || 1;
    const smsBodyText = String(draft.smsBodyText || "").slice(0, 1600);
    const sportsbetRaceUrl = String(
      draft.sportsbetRaceUrl || "https://www.sportsbet.com.au/horse-racing"
    ).slice(0, 300);

    let gatewayDispatched = false;
    let gatewayDetail = "Logged & ready for 1-Tap Mobile SMS / Sportsbet launch";

    // Optional Webhook or Twilio SMS Gateway if configured in environment
    const webhookUrl = process.env.SMS_WEBHOOK_URL;
    if (webhookUrl && /^https:\/\//i.test(webhookUrl)) {
      try {
        const whRes = await fetch(webhookUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            to: cleanedPhone,
            message: smsBodyText,
            sportsbetUrl: sportsbetRaceUrl,
            venue,
            raceNumber,
          }),
        });
        if (whRes.ok) {
          gatewayDispatched = true;
          gatewayDetail = "Dispatched via configured SMS Webhook";
        }
      } catch {
        // fallback to local log
      }
    }

    let logs: any[] = [];
    if (fs.existsSync(TRIFECTA_SMS_LOG_FILE)) {
      try {
        logs = JSON.parse(fs.readFileSync(TRIFECTA_SMS_LOG_FILE, "utf-8"));
        if (!Array.isArray(logs)) logs = [];
      } catch {
        logs = [];
      }
    }

    const entry = {
      dispatchedAt: new Date().toISOString(),
      toPhone: cleanedPhone,
      venue,
      raceNumber,
      runnerNumbers: Array.isArray(draft.runnerNumbers)
        ? draft.runnerNumbers.map(Number).filter(Boolean)
        : [],
      stakeAmount: Number(draft.stakeAmount) || 20,
      sportsbetRaceUrl,
      smsBodyText,
      gatewayDispatched,
      gatewayDetail,
    };

    logs.push(entry);
    const dir = path.dirname(TRIFECTA_SMS_LOG_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(
      TRIFECTA_SMS_LOG_FILE,
      JSON.stringify(logs.slice(-100), null, 2),
      "utf-8"
    );

    res.json({
      ok: true,
      toPhone: cleanedPhone,
      gatewayDispatched,
      message: `✓ Compiled Sportsbet Boxed Trifecta draft for ${venue} R${raceNumber} dispatched/queued for ${cleanedPhone}.`,
      entry,
    });
  } catch (err: any) {
    res.status(500).json({
      ok: false,
      error: err?.message || "Failed to process Trifecta SMS draft.",
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false, ws: false },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`TurfSheet NSW server running on http://0.0.0.0:${PORT}`);
    // Prime the live race results cache in the background and schedule regular 45s updates
    setTimeout(() => {
      runServerBackgroundResultsRefresh();
    }, 1500);
    setInterval(() => {
      runServerBackgroundResultsRefresh();
    }, 45_000);
  });
}

startServer();
