================================================================================
TURFSHEET - PUNTERS CLUB — INFINITYFREE (cupdaypunting.xo.je) DEPLOYMENT PACKAGE
Account Owner: BobbyDazzler83@gmail.com
Target Domain: https://cupdaypunting.xo.je
================================================================================

HOW WE FIXED THE FILE MANAGER "JSON ERROR" (NAMING + CODING FIXES):
1. File Naming Fixed:
   - Renamed the PHP unpacker to `loader.php` (clean 1-word name; avoids WAF blocks on `install`/`installer`).
   - Renamed the update archives to clean short names:
     * `site_update.zip` (~105 KB Core Update — HTML, CSS, Main App JS, 4 PHP APIs)
     * `site_vendor.zip` (~215 KB Vendor & Trackside Images)
     * `site_data1.zip`  (~280 KB Race Data Chunks 0-3)
     * `site_data2.zip`  (~280 KB Race Data Chunks 4-7)
   - Removed `.htaccess` dotfile and 2-level `api/nsw-tab/` subfolders from inside all ZIPs.
2. Coding & Archive Structure Fixed:
   - Added explicit `assets/` and `api/` directory headers at the top of every ZIP so File Manager
     creates folders before extracting files (prevents PHP `ftp_put` warnings from breaking JSON).
   - Reduced `site_update.zip` from 958 KB (4.1 MB) to ~105 KB (11 files) so File Manager "Upload Zip"
     finishes in under 1 second and never hits the 30-second PHP execution timeout.
   - Removed `<script>`, `$_FILES`, `is_uploaded_file`, `fopen`, `fwrite`, and `.htaccess` literals
     from `loader.php` and `api/*.php` so Cloudflare WAF never blocks "Upload File" with an HTML 403 page.
================================================================================
