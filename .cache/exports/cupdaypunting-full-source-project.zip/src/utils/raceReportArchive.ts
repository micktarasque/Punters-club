import type { PunterProfile, RaceMeeting } from "../types/racing.ts";
import { isRaceOfficialOrCompleted } from "../data/seedNswTab.ts";
import {
  DEFAULT_QUADDIE_BUY_IN_PER_USER,
  evaluateCombinedQuaddieForMeeting,
  evaluateCombinedTrifectaForRace,
  evaluateRaceTrio,
  formatDollarReturn,
  getFeatureRaceNumberForMeeting,
  getPunterJokerForMeeting,
  getPunterSelectionsForMeeting,
} from "./scoring.ts";
import { safeJsonParse } from "./safeFetchJson.ts";

export const SIX_MONTHS_RETENTION_MS = 180 * 24 * 60 * 60 * 1000; // 180 days (6 months)
export const STORAGE_KEY_RACE_REPORTS_ARCHIVE =
  "turfsheet_completed_participated_reports_6m_v6";
export const REPORT_SENDER_NAME = "Punters Club results";
export const DEFAULT_REPORT_EMAIL_RECIPIENTS = [
  "bobbydazzler83@gmail.com",
  "markstead@me.com",
];

export interface ReportUserStandingRow {
  punterId: string;
  punterName: string;
  role: string;
  rank: number;
  racesParticipated: number;
  winnersPicked: number;
  podiumsPicked: number;
  firstPrefHits: number;
  secondPrefHits: number;
  thirdPrefHits: number;
  jokerRaceNumber: number | null;
  jokerTriggered: boolean;
  jokerBonusPoints: number;
  totalPoints: number;
  totalDollarReturn: number;
  strikeRatePct: number;
  winStrikeRatePct?: number;
  avgPtsPerRace?: number;
}

export interface ReportRaceRow {
  raceNumber: number;
  raceName: string;
  startTime: string;
  distance: number;
  classGrade: string;
  podium: {
    first: string;
    second: string;
    third: string;
    firstWinOdds: number;
  };
  userCells: Array<{
    punterId: string;
    punterName: string;
    hasParticipated: boolean;
    picksSummary: string;
    hitSummary: string;
    isJokerRace: boolean;
    jokerTriggered: boolean;
    points: number;
    dollarReturn: number;
  }>;
  trifecta: {
    poolRunnersText: string;
    poolCount: number;
    boxedCombinations: number;
    officialCombination: string;
    officialDividend: number;
    isHit: boolean;
    hitCount: number; // 0, 1, 2, or 3
    betAmount: number;
    flexiReturnOnBet: number;
  };
}

export interface ReportQuaddieLegSummary {
  legIndex: number;
  raceNumber: number;
  raceName: string;
  isResulted: boolean;
  winnerText: string;
  winnerOdds: number;
  runnerCount: number;
  runnersText: string;
  fieldSize: number;
  fieldCoveragePct: number;
  isHit: boolean;
  winningSource: "user" | "extra" | "both" | "missed" | "pending";
}

export interface ReportQuaddieSummary {
  buyInPerUser: number;
  participatingUsersCount: number;
  betAmount: number;
  totalCombinations: number;
  flexiPercentage: number;
  completedLegsCount: number;
  hitLegsCount: number;
  isAlive: boolean;
  isWon: boolean;
  combinationString: string;
  officialOrEstimatedDividend: number;
  isOfficialDividend: boolean;
  flexiPayout: number;
  flexiPayoutPerUser: number;
  netProfit: number;
  netProfitPerUser: number;
  legs: ReportQuaddieLegSummary[];
}

export interface ReportAnalyticsMetrics {
  syndicateTotalPoints: number;
  syndicateTotalCashReturn: number;
  syndicateWinPlaceOutlay: number;
  syndicateStrikeRatePct: number;
  syndicateWinRatePct: number;
  avgWinningRunnerOdds: number;
  highestSingleRaceCollect: {
    raceNumber: number;
    punterName: string;
    dollarReturn: number;
    points: number;
  };
  bestTrifectaRace: {
    raceNumber: number;
    isHit: boolean;
    hitCount: number;
    dividend: number;
    flexiCollect: number;
  } | null;
  combinedExoticsOutlay: number;
  combinedExoticsReturn: number;
  combinedExoticsNetProfit: number;
  combinedExoticsRoiPct: number;
}

export interface NextMajorMeetPreview {
  headline: string;
  introHook: string;
  sydneyNextMeet: {
    venue: string;
    dateLabel: string;
    carnivalTitle: string;
    featureRaces: string[];
    stakesHighlight: string;
    hypePitch: string;
  };
  melbourneNextMeet: {
    venue: string;
    dateLabel: string;
    carnivalTitle: string;
    featureRaces: string[];
    stakesHighlight: string;
    hypePitch: string;
  };
  closingRallyCry: string;
}

export interface TechnicalFunnyAssessment {
  headline: string;
  upfrontParagraphs: string[];
  executiveSummary: string;
  punterRoastsAndPraises: Array<{
    punterName: string;
    badge: string;
    commentary: string;
  }>;
  trifectaVerdict: string;
  quaddieVerdict?: string;
  stewardsFunnyConclusion: string;
  nextMajorMeetsPreview: NextMajorMeetPreview;
}

export interface SavedRaceReport {
  id: string;
  meetingId: string;
  venue: string;
  state: string;
  raceDate: string; // YYYY-MM-DD
  createdAtIso: string;
  updatedAtIso: string;
  expiresAtIso: string; // +6 months (180 days)
  isRetroactive: boolean;
  trifectaBetAmount: number;
  participatingUsers: string[];
  completedParticipatedRacesCount: number;
  totalCardRacesCount: number;
  standings: ReportUserStandingRow[];
  raceRows: ReportRaceRow[];
  trifectaSummary: {
    racesEvaluated: number;
    trifectaHits: number;
    nearMisses2Of3: number;
    totalOutlay: number;
    totalFlexiReturn: number;
    netProfit: number;
    totalCapturedUnitDividends: number;
  };
  quaddieSummary?: ReportQuaddieSummary;
  analytics?: ReportAnalyticsMetrics;
  assessment: TechnicalFunnyAssessment;
  lastEmailedAtIso?: string;
  lastEmailedTo?: string[];
}

/**
 * Concise upcoming Sydney & Melbourne major race meets preview based on report date.
 */
export function buildNextMajorMeetsPreview(raceDate: string): NextMajorMeetPreview {
  if (raceDate <= "2026-09-26") {
    return {
      headline: "Next Major Feature Cards: Epsom Handicap (Sydney) & Turnbull Stakes (Melbourne)",
      introHook:
        "Group 1 mile and middle-distance contenders step out across Royal Randwick and Flemington next Saturday.",
      sydneyNextMeet: {
        venue: "Royal Randwick (NSW)",
        dateLabel: "Epsom & Metropolitan Group 1 Day",
        carnivalTitle: "Sydney Everest Carnival — Group 1 Mile & Staying Showdown",
        featureRaces: [
          "G1 TAB Epsom Handicap (1600m · $1.5M)",
          "G1 The Metropolitan (2400m · $750K)",
          "G1 Flight Stakes (1600m · $750K)",
          "G2 Premiere Stakes (1200m · Everest Lead-Up)",
        ],
        stakesHighlight: "$5.2M+ Randwick Stakes",
        hypePitch:
          "High-tempo Randwick mile handicaps historically produce strong Trifecta and Quaddie value.",
      },
      melbourneNextMeet: {
        venue: "Flemington (VIC)",
        dateLabel: "Turnbull Stakes Day",
        carnivalTitle: "Melbourne Spring Carnival — WFA & Cup Qualifiers",
        featureRaces: [
          "G1 Turnbull Stakes (2000m · $750K)",
          "G2 Gilgai Stakes (1200m · $300K)",
          "G2 Edward Manifold Stakes (1600m)",
          "Bart Cummings (2520m · Melbourne Cup Qualifier)",
        ],
        stakesHighlight: "$4.8M+ Flemington Stakes",
        hypePitch:
          "Key Caulfield Cup, Cox Plate, and Melbourne Cup prospects clash over 2000m.",
      },
      closingRallyCry:
        "NEXT MEET FOCUS: Lock in 1st–3rd preferences, 2× Joker nominations, and Quaddie legs ahead of Race 1.",
    };
  }

  if (raceDate <= "2026-10-16") {
    return {
      headline: "Next Feature Cards: $20M The Everest (Randwick) & $5M Caulfield Cup (Melbourne)",
      introHook:
        "Australia's richest turf sprint in Sydney pairs with the world's richest 2400m handicap in Melbourne.",
      sydneyNextMeet: {
        venue: "Royal Randwick (NSW)",
        dateLabel: "Saturday 17 Oct 2026 · The Everest Day",
        carnivalTitle: "$20M The Everest & $5M G1 King Charles III Stakes",
        featureRaces: [
          "The Everest (1200m WFA · $20,000,000)",
          "G1 King Charles III Stakes (1600m WFA · $5,000,000)",
          "The Kosciuszko (1200m · $2,000,000)",
          "G3 Sydney Stakes (1200m · $2,000,000)",
        ],
        stakesHighlight: "$30.5M+ Sydney Card",
        hypePitch:
          "Capacity 12-runner WFA sprint field at Randwick creates prime Boxed Trifecta and Quaddie pools.",
      },
      melbourneNextMeet: {
        venue: "Caulfield (VIC)",
        dateLabel: "Saturday 17 Oct 2026 · Caulfield Cup Finale",
        carnivalTitle: "$5,000,000 Group 1 Caulfield Cup (2400m)",
        featureRaces: [
          "G1 Caulfield Cup (2400m · $5,000,000)",
          "G1 Thousand Guineas (1600m · $1,500,000)",
          "G2 Caulfield Sprint (1000m · $300,000)",
          "G2 Tristarc Stakes (1400m · $300,000)",
        ],
        stakesHighlight: "$8.2M+ Caulfield Card",
        hypePitch:
          "18-runner staying handicap across a high-pressure 2400m tests wide Quaddie and Trifecta combinations.",
      },
      closingRallyCry:
        "NEXT MEET FOCUS: Enter 1st, 2nd & 3rd preferences early and review Combined Trifecta and Quaddie coverage.",
    };
  }

  return {
    headline: "Next Feature Cards: $10M Golden Eagle, Cox Plate & Melbourne Cup Carnival",
    introHook:
      "Championship Group 1 cards headline Rosehill, Moonee Valley, and Flemington Cup Week.",
    sydneyNextMeet: {
      venue: "Rosehill & Randwick (NSW)",
      dateLabel: "Golden Eagle & Five Diamonds",
      carnivalTitle: "$10M Golden Eagle (1500m) & $2M Five Diamonds",
      featureRaces: [
        "The Golden Eagle (1500m 4YO · $10,000,000)",
        "Russell Balding Stakes (1300m · $3,000,000)",
        "The Five Diamonds (1800m 5YO · $2,000,000)",
        "G2 Hot Danish Stakes & Golden Gift",
      ],
      stakesHighlight: "$16M+ Sydney Stakes",
      hypePitch:
        "Large 4YO fields over 1500m offer deep value for multi-runner Trifecta and Quaddie pools.",
    },
    melbourneNextMeet: {
      venue: "Moonee Valley & Flemington (VIC)",
      dateLabel: "Cox Plate & Melbourne Cup Week",
      carnivalTitle: "G1 Cox Plate, Victoria Derby & Melbourne Cup",
      featureRaces: [
        "G1 Cox Plate (2040m WFA · $5,000,000)",
        "G1 Victoria Derby (2500m · $2,000,000) & Coolmore Stud Stakes",
        "G1 Melbourne Cup (3200m · $8,500,000)",
        "G1 Champions Stakes, Sprint & Mile ($3,000,000 each)",
      ],
      stakesHighlight: "$40M+ Melbourne Stakes",
      hypePitch:
        "Deep Group 1 fields across all four legs of the Quaddie deliver the largest exotic pools of the season.",
    },
    closingRallyCry:
      "NEXT MEET FOCUS: Finalise selections, 2× Joker race nominations, and Quaddie savers before jump.",
  };
}

/**
 * Generates a short, punchy, data-driven quantitative race report assessment
 * with explicit commentary on Leaderboard Standings, Combined Trifecta results, and Combined Quaddie results.
 */
export function buildTechnicalAndFunnyAssessment(
  venue: string,
  raceDate: string,
  standings: ReportUserStandingRow[],
  raceRows: ReportRaceRow[],
  trifectaSummary: SavedRaceReport["trifectaSummary"],
  trifectaBetAmount: number,
  quaddieSummary?: ReportQuaddieSummary
): TechnicalFunnyAssessment {
  const leader = standings[0];
  const runnerUp = standings[1];
  const totalPointsAll = standings.reduce((s, u) => s + u.totalPoints, 0);
  const totalDollarsAll = Number(
    standings.reduce((s, u) => s + u.totalDollarReturn, 0).toFixed(2)
  );
  const totalWinnersAll = standings.reduce((s, u) => s + u.winnersPicked, 0);
  const totalPodiumsAll = standings.reduce((s, u) => s + u.podiumsPicked, 0);

  const leaderMarginPts =
    leader && runnerUp ? leader.totalPoints - runnerUp.totalPoints : 0;

  let headline = `${venue} (${raceDate}) — Punters Club Results, Trifecta & Quaddie Report`;
  if (trifectaSummary.trifectaHits > 0 && quaddieSummary?.isWon) {
    headline = `${venue.toUpperCase()} EXOTICS DOUBLE: ${trifectaSummary.trifectaHits} Trifecta Hit(s) + Quaddie Landed (${formatDollarReturn(trifectaSummary.totalFlexiReturn + (quaddieSummary.flexiPayout || 0))} Collect)`;
  } else if (trifectaSummary.trifectaHits > 0) {
    headline = `TRIFECTA LANDED AT ${venue.toUpperCase()}: ${trifectaSummary.trifectaHits} Boxed Hit(s) (${formatDollarReturn(trifectaSummary.totalFlexiReturn)}) · ${leader?.punterName || "Syndicate"} Leads (${leader?.totalPoints || 0} pts)`;
  } else if (quaddieSummary?.isWon) {
    headline = `QUADDIE LANDED AT ${venue.toUpperCase()}: 4/4 Legs (${formatDollarReturn(quaddieSummary.flexiPayout)}) · ${leader?.punterName || "Syndicate"} Leads (${leader?.totalPoints || 0} pts)`;
  } else if (leader) {
    headline = `${venue} (${raceDate}) Results: ${leader.punterName} Leads on ${leader.totalPoints} pts (${formatDollarReturn(leader.totalDollarReturn)} Return)`;
  }

  // 1. Short, punchy Leaderboard & Preference Accuracy Summary
  const jokerUsersHit = standings.filter((u) => u.jokerTriggered);
  const jokerNote =
    jokerUsersHit.length > 0
      ? `2× Joker converted by ${jokerUsersHit.map((u) => `${u.punterName} (R${u.jokerRaceNumber}, +${u.jokerBonusPoints} pts)`).join(" & ")}.`
      : `No 2× Joker bonus converted across nominated races.`;

  const para1 =
    `CARD TELEMETRY (${raceRows.length} Races): Syndicate totalled ${totalPointsAll} pts, ${totalWinnersAll} winners, ${totalPodiumsAll} podiums, and ${formatDollarReturn(totalDollarsAll)} in Win/Place returns. ` +
    (leader && runnerUp
      ? `${leader.punterName} finished #1 with ${leader.totalPoints} pts (${formatDollarReturn(leader.totalDollarReturn)}, ${leader.strikeRatePct}% podium SR), ${leaderMarginPts === 0 ? "edging" : `+${leaderMarginPts} pts clear of`} ${runnerUp.punterName} (${runnerUp.totalPoints} pts, ${formatDollarReturn(runnerUp.totalDollarReturn)}). `
      : leader
      ? `${leader.punterName} led with ${leader.totalPoints} pts (${formatDollarReturn(leader.totalDollarReturn)}, ${leader.strikeRatePct}% SR). `
      : "") +
    `Preference splits: 1st (${standings.reduce((s, u) => s + u.firstPrefHits, 0)}), 2nd (${standings.reduce((s, u) => s + u.secondPrefHits, 0)}), 3rd (${standings.reduce((s, u) => s + u.thirdPrefHits, 0)}). ${jokerNote}`;

  // 2. Short, punchy Combined Trifecta Commentary
  const hitRacesList = raceRows
    .filter((r) => r.trifecta.isHit)
    .map(
      (r) =>
        `R${r.raceNumber} (${r.trifecta.officialCombination}, $1 div $${r.trifecta.officialDividend.toFixed(2)} → ${formatDollarReturn(r.trifecta.flexiReturnOnBet)})`
    );

  const para2 =
    trifectaSummary.trifectaHits > 0
      ? `TRIFECTA RESULTS ($${trifectaBetAmount}/Race Box): Landed ${trifectaSummary.trifectaHits}/${trifectaSummary.racesEvaluated} boxed Trifectas [${hitRacesList.join("; ")}] with ${trifectaSummary.nearMisses2Of3} additional 2/3 near-misses. Total Flexi return: ${formatDollarReturn(trifectaSummary.totalFlexiReturn)} on ${formatDollarReturn(trifectaSummary.totalOutlay)} outlay (Net: ${trifectaSummary.netProfit >= 0 ? "+" : "-"}${formatDollarReturn(Math.abs(trifectaSummary.netProfit))}).`
      : `TRIFECTA RESULTS ($${trifectaBetAmount}/Race Box): 0/${trifectaSummary.racesEvaluated} full boxed collects (${formatDollarReturn(trifectaSummary.totalOutlay)} outlay), with ${trifectaSummary.nearMisses2Of3} race(s) hitting 2 of the top 3 podium finishers.`;

  // 3. Short, punchy Combined Quaddie Commentary
  let para3 = `QUADDIE RESULTS: Less than 4 races evaluated on this card.`;
  if (quaddieSummary && quaddieSummary.legs.length > 0) {
    const legBreakdown = quaddieSummary.legs
      .map(
        (l) =>
          `L${l.legIndex} R${l.raceNumber}: ${
            l.isResulted
              ? `${l.winnerText} (${l.isHit ? "HIT" : "MISS"})`
              : "Pending"
          }`
      )
      .join(" | ");

    const buyInTag = `$${quaddieSummary.buyInPerUser || DEFAULT_QUADDIE_BUY_IN_PER_USER}/user buy-in · $${quaddieSummary.betAmount} pool`;
    if (quaddieSummary.isWon) {
      para3 = `QUADDIE RESULTS (${buyInTag} · ${quaddieSummary.totalCombinations} Combos @ ${quaddieSummary.flexiPercentage}%): WON (4/4 Legs Landed — ${quaddieSummary.combinationString}). $1 Dividend: $${quaddieSummary.officialOrEstimatedDividend.toFixed(2)} → Flexi Collect: ${formatDollarReturn(quaddieSummary.flexiPayout)} (${formatDollarReturn(quaddieSummary.flexiPayoutPerUser || quaddieSummary.flexiPayout / Math.max(1, quaddieSummary.participatingUsersCount || 2))}/user · Net: +${formatDollarReturn(quaddieSummary.netProfit)}). Legs: ${legBreakdown}.`;
    } else {
      para3 = `QUADDIE RESULTS (${buyInTag} · ${quaddieSummary.totalCombinations} Combos @ ${quaddieSummary.flexiPercentage}%): ${quaddieSummary.hitLegsCount}/${quaddieSummary.legs.length} Legs Landed (${quaddieSummary.combinationString}; $1 Div $${quaddieSummary.officialOrEstimatedDividend.toFixed(2)}). Legs: ${legBreakdown}.`;
    }
  }

  const upfrontParagraphs = [para1, para2, para3];
  const executiveSummary = para1;

  const punterRoastsAndPraises = standings.map((u, idx) => {
    const jokerStatus =
      u.jokerRaceNumber !== null
        ? u.jokerTriggered
          ? `2× Joker R${u.jokerRaceNumber} HIT (+${u.jokerBonusPoints} pts)`
          : `2× Joker R${u.jokerRaceNumber} missed`
        : `No Joker nominated`;

    const badge =
      idx === 0
        ? "🥇 #1 Card Leader"
        : u.totalDollarReturn >= (leader?.totalDollarReturn || 0) &&
          u.totalDollarReturn > 0
        ? "💰 Top Cash Return"
        : u.strikeRatePct >= 35
        ? "🎯 High Strike Rate"
        : "📊 Syndicate Contender";

    return {
      punterName: u.punterName,
      badge,
      commentary: `${u.totalPoints} pts · ${formatDollarReturn(u.totalDollarReturn)} return · ${u.winnersPicked}W / ${u.podiumsPicked}P (${u.strikeRatePct}% SR across ${u.racesParticipated} races). Pref hits: 1st (${u.firstPrefHits}), 2nd (${u.secondPrefHits}), 3rd (${u.thirdPrefHits}) · ${jokerStatus}.`,
    };
  });

  const trifectaVerdict = para2;
  const quaddieVerdict = para3;

  const totalExoticNet =
    trifectaSummary.netProfit + (quaddieSummary?.netProfit || 0);
  const stewardsFunnyConclusion =
    `EXECUTIVE VERDICT: ${leader?.punterName || "Syndicate"} topped ${venue} on ${leader?.totalPoints || 0} pts (${formatDollarReturn(leader?.totalDollarReturn || 0)}), with Combined Trifectas hitting ${trifectaSummary.trifectaHits}/${trifectaSummary.racesEvaluated} (${trifectaSummary.nearMisses2Of3} near-misses) and the Quaddie landing ${quaddieSummary?.hitLegsCount ?? 0}/${quaddieSummary?.legs.length ?? 4} legs (${totalExoticNet >= 0 ? "+" : "-"}${formatDollarReturn(Math.abs(totalExoticNet))} net exotics).`;

  const nextMajorMeetsPreview = buildNextMajorMeetsPreview(raceDate);

  return {
    headline,
    upfrontParagraphs,
    executiveSummary,
    punterRoastsAndPraises,
    trifectaVerdict,
    quaddieVerdict,
    stewardsFunnyConclusion,
    nextMajorMeetsPreview,
  };
}

/**
 * Builds a SavedRaceReport for a meeting including Leaderboard, Race-by-Race matrix,
 * Combined Trifecta telemetry, Combined 4-Leg Quaddie evaluation, and Quantitative Analytics.
 */
export function buildRaceReportForMeeting(
  meeting: RaceMeeting,
  punters: PunterProfile[],
  trifectaBetAmount: number = 20,
  options?: {
    isRetroactive?: boolean;
    customCreatedAtIso?: string;
    existingReport?: SavedRaceReport;
    forceGenerateForMeeting?: boolean;
    quaddieExtraByRace?: Record<number, number[]>;
    quaddieBuyInPerUser?: number;
    quaddieBetAmount?: number;
  }
): SavedRaceReport | null {
  const completedRaces = meeting.races.filter((r) =>
    isRaceOfficialOrCompleted(r, meeting.date)
  );
  if (completedRaces.length === 0 && !options?.forceGenerateForMeeting) {
    return null;
  }

  const candidateRaces =
    completedRaces.length > 0 ? completedRaces : meeting.races;

  let participatedCompletedRaces = candidateRaces.filter((race) =>
    punters.some((p) => {
      const mSel = getPunterSelectionsForMeeting(p, meeting);
      const t = mSel[race.raceNumber];
      return (
        t &&
        (t.firstPref !== null ||
          t.secondPref !== null ||
          t.thirdPref !== null)
      );
    })
  );

  let effectivePunters = punters;
  if (
    participatedCompletedRaces.length === 0 &&
    options?.forceGenerateForMeeting
  ) {
    participatedCompletedRaces = candidateRaces;
    effectivePunters = punters.map((p, pIdx) => {
      const existingMap = p.selectionsByMeeting[meeting.id] || {};
      const hasAny = Object.values(existingMap).some(
        (t) =>
          t &&
          (t.firstPref !== null ||
            t.secondPref !== null ||
            t.thirdPref !== null)
      );
      if (hasAny) return p;

      const fallbackMap: Record<
        number,
        { firstPref: number; secondPref: number; thirdPref: number }
      > = {};
      for (const r of participatedCompletedRaces) {
        const sortedByOdds = [...r.runners].sort(
          (a, b) => (a.nswTabWin || 99) - (b.nswTabWin || 99)
        );
        const shift =
          (r.raceNumber + pIdx * 2) %
          Math.max(1, Math.min(5, sortedByOdds.length));
        fallbackMap[r.raceNumber] = {
          firstPref: sortedByOdds[shift % sortedByOdds.length]?.tabNumber ?? 1,
          secondPref:
            sortedByOdds[(shift + 1) % sortedByOdds.length]?.tabNumber ?? 2,
          thirdPref:
            sortedByOdds[(shift + 2) % sortedByOdds.length]?.tabNumber ?? 3,
        };
      }
      return {
        ...p,
        selectionsByMeeting: {
          ...p.selectionsByMeeting,
          [meeting.id]: fallbackMap,
        },
        jokerRaceByMeeting: {
          ...(p.jokerRaceByMeeting || {}),
          [meeting.id]:
            p.jokerRaceByMeeting?.[meeting.id] ??
            getFeatureRaceNumberForMeeting(meeting),
        },
      };
    });
  }

  if (participatedCompletedRaces.length === 0) {
    return null;
  }

  const participatingUsersSet = new Set<string>();
  const rawStandings = effectivePunters.map((punter) => {
    const mSel = getPunterSelectionsForMeeting(punter, meeting);
    const jokerRaceNumber = getPunterJokerForMeeting(punter, meeting);

    let racesParticipated = 0;
    let winnersPicked = 0;
    let podiumsPicked = 0;
    let firstPrefHits = 0;
    let secondPrefHits = 0;
    let thirdPrefHits = 0;
    let jokerTriggered = false;
    let jokerBonusPoints = 0;
    let totalPoints = 0;
    let totalDollarReturn = 0;

    for (const race of participatedCompletedRaces) {
      const isJoker = jokerRaceNumber === race.raceNumber;
      const ev = evaluateRaceTrio(
        race,
        mSel[race.raceNumber],
        meeting.date,
        isJoker
      );
      if (ev.hasAnySelection) {
        racesParticipated += 1;
        participatingUsersSet.add(punter.name);
        totalPoints += ev.racePointsTally;
        totalDollarReturn = Number(
          (totalDollarReturn + ev.raceDollarReturn).toFixed(2)
        );
        if (ev.jokerTriggered) {
          jokerTriggered = true;
          jokerBonusPoints += ev.jokerBonusPoints;
        }
        for (const p of ev.picks) {
          if (p.tabNumber !== null) {
            if (p.finishPosition === 1) winnersPicked += 1;
            if (p.finishPosition >= 1 && p.finishPosition <= 3) {
              podiumsPicked += 1;
              if (p.preferenceRank === 1) firstPrefHits += 1;
              if (p.preferenceRank === 2) secondPrefHits += 1;
              if (p.preferenceRank === 3) thirdPrefHits += 1;
            }
          }
        }
      }
    }

    const strikeRatePct =
      racesParticipated > 0
        ? Math.round((podiumsPicked / (racesParticipated * 3)) * 100)
        : 0;
    const winStrikeRatePct =
      racesParticipated > 0
        ? Math.round((winnersPicked / racesParticipated) * 100)
        : 0;
    const avgPtsPerRace =
      racesParticipated > 0
        ? Number((totalPoints / racesParticipated).toFixed(1))
        : 0;

    return {
      punterId: punter.id,
      punterName: punter.name,
      role: punter.role,
      rank: 1,
      racesParticipated,
      winnersPicked,
      podiumsPicked,
      firstPrefHits,
      secondPrefHits,
      thirdPrefHits,
      jokerRaceNumber,
      jokerTriggered,
      jokerBonusPoints,
      totalPoints,
      totalDollarReturn,
      strikeRatePct,
      winStrikeRatePct,
      avgPtsPerRace,
    };
  });

  const sortedStandings = [...rawStandings]
    .sort(
      (a, b) =>
        b.totalPoints - a.totalPoints ||
        b.totalDollarReturn - a.totalDollarReturn
    )
    .map((row, idx) => ({ ...row, rank: idx + 1 }));

  let trifectaHits = 0;
  let nearMisses2Of3 = 0;
  let totalOutlay = 0;
  let totalFlexiReturn = 0;
  let totalCapturedUnitDividends = 0;

  let highestSingleRaceCollect = {
    raceNumber: 1,
    punterName: sortedStandings[0]?.punterName || "Syndicate",
    dollarReturn: 0,
    points: 0,
  };

  let winningOddsSum = 0;
  let winningOddsCount = 0;

  const raceRows: ReportRaceRow[] = participatedCompletedRaces.map((race) => {
    const first = race.runners.find((r) => r.finishPosition === 1);
    const second = race.runners.find((r) => r.finishPosition === 2);
    const third = race.runners.find((r) => r.finishPosition === 3);

    if (first?.nswTabWin) {
      winningOddsSum += Number(first.nswTabWin);
      winningOddsCount += 1;
    }

    const userCells = effectivePunters.map((punter) => {
      const mSel = getPunterSelectionsForMeeting(punter, meeting);
      const jokerRaceNo = getPunterJokerForMeeting(punter, meeting);
      const isJokerRace = jokerRaceNo === race.raceNumber;
      const ev = evaluateRaceTrio(
        race,
        mSel[race.raceNumber],
        meeting.date,
        isJokerRace
      );

      if (ev.raceDollarReturn > highestSingleRaceCollect.dollarReturn) {
        highestSingleRaceCollect = {
          raceNumber: race.raceNumber,
          punterName: punter.name,
          dollarReturn: ev.raceDollarReturn,
          points: ev.racePointsTally,
        };
      }

      const picksText = ev.picks
        .map((p) =>
          p.tabNumber !== null
            ? `${p.preferenceRank === 1 ? "1st" : p.preferenceRank === 2 ? "2nd" : "3rd"}: #${p.tabNumber} ${p.runner?.horseName || ""}`
            : null
        )
        .filter(Boolean)
        .join(" · ");

      const hitsText = ev.picks
        .filter((p) => p.points > 0 && p.runner)
        .map(
          (p) =>
            `#${p.tabNumber} (${
              p.finishPosition === 1
                ? "1st"
                : p.finishPosition === 2
                ? "2nd"
                : "3rd"
            })`
        )
        .join(", ");

      return {
        punterId: punter.id,
        punterName: punter.name,
        hasParticipated: ev.hasAnySelection,
        picksSummary: picksText || "No selection",
        hitSummary: hitsText || "Unplaced",
        isJokerRace,
        jokerTriggered: ev.jokerTriggered,
        points: ev.racePointsTally,
        dollarReturn: ev.raceDollarReturn,
      };
    });

    const triEval = evaluateCombinedTrifectaForRace(
      race,
      effectivePunters,
      meeting.id,
      meeting.date,
      trifectaBetAmount,
      meeting.venue
    );

    if (triEval.combinedRunners.length >= 3) {
      totalOutlay = Number((totalOutlay + trifectaBetAmount).toFixed(2));
    }
    if (triEval.isCombinedBoxedTrifectaHit) {
      trifectaHits += 1;
      totalFlexiReturn = Number(
        (totalFlexiReturn + triEval.customBetFlexiReturn).toFixed(2)
      );
      totalCapturedUnitDividends = Number(
        (
          totalCapturedUnitDividends + triEval.bookmakerTrifectaDividend
        ).toFixed(2)
      );
    } else if (triEval.podiumHitFlags.hitCount === 2) {
      nearMisses2Of3 += 1;
    }

    return {
      raceNumber: race.raceNumber,
      raceName: race.raceName,
      startTime: race.startTime,
      distance: race.distance,
      classGrade: race.classGrade,
      podium: {
        first: first ? `#${first.tabNumber} ${first.horseName}` : "TBA",
        second: second ? `#${second.tabNumber} ${second.horseName}` : "TBA",
        third: third ? `#${third.tabNumber} ${third.horseName}` : "TBA",
        firstWinOdds: Number(first?.nswTabWin) || 0,
      },
      userCells,
      trifecta: {
        poolRunnersText: triEval.combinedRunners
          .map((c) => `#${c.tabNumber} ${c.runner?.horseName || ""}`)
          .join(", "),
        poolCount: triEval.combinedRunners.length,
        boxedCombinations: triEval.boxedCombinationsCount,
        officialCombination: triEval.officialTrifectaCombination,
        officialDividend: triEval.bookmakerTrifectaDividend,
        isHit: triEval.isCombinedBoxedTrifectaHit,
        hitCount: triEval.podiumHitFlags.hitCount,
        betAmount: trifectaBetAmount,
        flexiReturnOnBet: triEval.isCombinedBoxedTrifectaHit
          ? triEval.customBetFlexiReturn
          : 0,
      },
    };
  });

  const trifectaSummary = {
    racesEvaluated: participatedCompletedRaces.length,
    trifectaHits,
    nearMisses2Of3,
    totalOutlay,
    totalFlexiReturn,
    netProfit: Number((totalFlexiReturn - totalOutlay).toFixed(2)),
    totalCapturedUnitDividends,
  };

  // Evaluate Combined 4-Leg Quaddie for this meeting (defaults to $50 buy-in per user)
  const resolvedQuaddieBuyInPerUser =
    options?.quaddieBuyInPerUser && options.quaddieBuyInPerUser > 0
      ? options.quaddieBuyInPerUser
      : DEFAULT_QUADDIE_BUY_IN_PER_USER;

  const qEval = evaluateCombinedQuaddieForMeeting(
    meeting,
    effectivePunters,
    options?.quaddieExtraByRace || {},
    resolvedQuaddieBuyInPerUser
  );

  const quaddieSummary: ReportQuaddieSummary = {
    buyInPerUser: qEval.buyInPerUser,
    participatingUsersCount: qEval.participatingUsersCount,
    betAmount: qEval.quaddieBetAmount,
    totalCombinations: qEval.totalCombinations,
    flexiPercentage: qEval.flexiPercentage,
    completedLegsCount: qEval.completedLegsCount,
    hitLegsCount: qEval.hitLegsCount,
    isAlive: qEval.isQuaddieAlive,
    isWon: qEval.isQuaddieWon,
    combinationString: qEval.quaddieCombinationString,
    officialOrEstimatedDividend: qEval.officialOrEstimatedQuaddieDividend,
    isOfficialDividend: qEval.isOfficialDividend,
    flexiPayout: qEval.isQuaddieWon ? qEval.flexiPayoutOnBetAmount : 0,
    flexiPayoutPerUser: qEval.isQuaddieWon ? qEval.flexiPayoutPerUser : 0,
    netProfit: qEval.netProfitOnBet,
    netProfitPerUser: qEval.netProfitPerUser,
    legs: qEval.legs.map((leg) => {
      const fieldSize = Math.max(1, leg.race.runners.length);
      return {
        legIndex: leg.legIndex,
        raceNumber: leg.raceNumber,
        raceName: leg.race.raceName,
        isResulted: leg.isRaceResulted,
        winnerText: leg.winner
          ? `#${leg.winner.tabNumber} ${leg.winner.horseName}`
          : "Pending",
        winnerOdds: Number(leg.winner?.nswTabWin) || 0,
        runnerCount: leg.allLegRunners.length,
        runnersText: leg.allLegRunners
          .map((r) => `#${r.tabNumber}${r.isQuaddieExtra && r.source === "extra" ? "+" : ""}`)
          .join(", "),
        fieldSize,
        fieldCoveragePct: Math.round(
          (leg.allLegRunners.length / fieldSize) * 100
        ),
        isHit: leg.isLegHit,
        winningSource: leg.winningRunnerSource,
      };
    }),
  };

  const syndicateTotalPoints = sortedStandings.reduce(
    (s, u) => s + u.totalPoints,
    0
  );
  const syndicateTotalCashReturn = Number(
    sortedStandings.reduce((s, u) => s + u.totalDollarReturn, 0).toFixed(2)
  );
  const totalPicksMade = sortedStandings.reduce(
    (s, u) => s + u.racesParticipated * 3,
    0
  );
  const totalPodiumsAll = sortedStandings.reduce(
    (s, u) => s + u.podiumsPicked,
    0
  );
  const totalWinnersAll = sortedStandings.reduce(
    (s, u) => s + u.winnersPicked,
    0
  );
  const totalUserRaces = sortedStandings.reduce(
    (s, u) => s + u.racesParticipated,
    0
  );

  const bestTriRow =
    [...raceRows].sort(
      (a, b) =>
        b.trifecta.flexiReturnOnBet - a.trifecta.flexiReturnOnBet ||
        b.trifecta.hitCount - a.trifecta.hitCount ||
        b.trifecta.officialDividend - a.trifecta.officialDividend
    )[0] || null;

  const combinedExoticsOutlay = Number(
    (
      trifectaSummary.totalOutlay +
      (quaddieSummary.totalCombinations > 0 ? quaddieSummary.betAmount : 0)
    ).toFixed(2)
  );
  const combinedExoticsReturn = Number(
    (trifectaSummary.totalFlexiReturn + quaddieSummary.flexiPayout).toFixed(2)
  );
  const combinedExoticsNetProfit = Number(
    (combinedExoticsReturn - combinedExoticsOutlay).toFixed(2)
  );
  const combinedExoticsRoiPct =
    combinedExoticsOutlay > 0
      ? Math.round((combinedExoticsReturn / combinedExoticsOutlay) * 100)
      : 0;

  const analytics: ReportAnalyticsMetrics = {
    syndicateTotalPoints,
    syndicateTotalCashReturn,
    syndicateWinPlaceOutlay: totalUserRaces * 4, // $2 1st pref ($1W/$1P) + $1 2ndP + $1 3rdP
    syndicateStrikeRatePct:
      totalPicksMade > 0
        ? Math.round((totalPodiumsAll / totalPicksMade) * 100)
        : 0,
    syndicateWinRatePct:
      totalUserRaces > 0
        ? Math.round((totalWinnersAll / totalUserRaces) * 100)
        : 0,
    avgWinningRunnerOdds:
      winningOddsCount > 0
        ? Number((winningOddsSum / winningOddsCount).toFixed(2))
        : 0,
    highestSingleRaceCollect,
    bestTrifectaRace: bestTriRow
      ? {
          raceNumber: bestTriRow.raceNumber,
          isHit: bestTriRow.trifecta.isHit,
          hitCount: bestTriRow.trifecta.hitCount,
          dividend: bestTriRow.trifecta.officialDividend,
          flexiCollect: bestTriRow.trifecta.flexiReturnOnBet,
        }
      : null,
    combinedExoticsOutlay,
    combinedExoticsReturn,
    combinedExoticsNetProfit,
    combinedExoticsRoiPct,
  };

  const assessment = buildTechnicalAndFunnyAssessment(
    meeting.venue,
    meeting.date,
    sortedStandings,
    raceRows,
    trifectaSummary,
    trifectaBetAmount,
    quaddieSummary
  );

  const createdIso =
    options?.existingReport?.createdAtIso ||
    options?.customCreatedAtIso ||
    new Date(`${meeting.date}T08:00:00Z`).toISOString();
  const createdMs = Date.parse(createdIso) || Date.now();
  const expiresIso = new Date(
    createdMs + SIX_MONTHS_RETENTION_MS
  ).toISOString();

  return {
    id: `report-${meeting.id}`,
    meetingId: meeting.id,
    venue: meeting.venue,
    state: meeting.state,
    raceDate: meeting.date,
    createdAtIso: createdIso,
    updatedAtIso: new Date().toISOString(),
    expiresAtIso: expiresIso,
    isRetroactive: options?.isRetroactive ?? true,
    trifectaBetAmount,
    participatingUsers: Array.from(participatingUsersSet),
    completedParticipatedRacesCount: participatedCompletedRaces.length,
    totalCardRacesCount: meeting.races.length,
    standings: sortedStandings,
    raceRows,
    trifectaSummary,
    quaddieSummary,
    analytics,
    assessment,
    lastEmailedAtIso: options?.existingReport?.lastEmailedAtIso,
    lastEmailedTo: options?.existingReport?.lastEmailedTo,
  };
}

/**
 * Generates retroactive historical reports over the past 6 months
 */
export function buildRetroactiveSixMonthReportsSeed(
  allMeetings: RaceMeeting[],
  currentPunters: PunterProfile[],
  trifectaBetAmount: number = 20
): SavedRaceReport[] {
  const reportsMap = new Map<string, SavedRaceReport>();
  const nowMs = Date.now();
  const cutoffMs = nowMs - SIX_MONTHS_RETENTION_MS;

  for (const m of allMeetings) {
    const mDateMs = Date.parse(`${m.date}T00:00:00Z`) || nowMs;
    if (mDateMs < cutoffMs) continue;
    const built = buildRaceReportForMeeting(m, currentPunters, trifectaBetAmount, {
      isRetroactive: true,
    });
    if (built) {
      reportsMap.set(built.id, built);
    }
  }

  const completedMeetings = allMeetings.filter((m) => {
    const mDateMs = Date.parse(`${m.date}T00:00:00Z`) || nowMs;
    const isWithinSixMonths = mDateMs >= cutoffMs && mDateMs <= nowMs + 86400000;
    const hasCompletedRaces =
      m.races.filter((r) => isRaceOfficialOrCompleted(r, m.date)).length >= 4;
    return isWithinSixMonths && hasCompletedRaces;
  });

  const retroCandidateMeetings = completedMeetings.slice(0, 6);

  for (let mIdx = 0; mIdx < retroCandidateMeetings.length; mIdx++) {
    const m = retroCandidateMeetings[mIdx];
    const reportId = `report-${m.id}`;
    if (reportsMap.has(reportId)) continue;

    const retroPunters: PunterProfile[] = currentPunters.slice(0, 2).map((p, pIdx) => {
      const raceMap: Record<number, { firstPref: number; secondPref: number; thirdPref: number }> = {};
      for (const r of m.races) {
        if (!isRaceOfficialOrCompleted(r, m.date)) continue;
        const sortedByOdds = [...r.runners].sort(
          (a, b) => (a.nswTabWin || 99) - (b.nswTabWin || 99)
        );
        const shift = (r.raceNumber + pIdx * 2 + mIdx) % Math.max(1, Math.min(5, sortedByOdds.length));
        const pick1 = sortedByOdds[shift % sortedByOdds.length]?.tabNumber ?? 1;
        const pick2 = sortedByOdds[(shift + 1) % sortedByOdds.length]?.tabNumber ?? 2;
        const pick3 = sortedByOdds[(shift + 2) % sortedByOdds.length]?.tabNumber ?? 3;
        raceMap[r.raceNumber] = {
          firstPref: pick1,
          secondPref: pick2,
          thirdPref: pick3,
        };
      }
      const jokerRace =
        getFeatureRaceNumberForMeeting(m) ??
        ((mIdx + pIdx * 3) % Math.min(8, m.races.length)) + 1;
      return {
        ...p,
        selectionsByMeeting: {
          ...p.selectionsByMeeting,
          [m.id]: raceMap,
        },
        jokerRaceByMeeting: {
          ...(p.jokerRaceByMeeting || {}),
          [m.id]: jokerRace,
        },
      };
    });

    const retroBuilt = buildRaceReportForMeeting(
      m,
      retroPunters,
      trifectaBetAmount,
      {
        isRetroactive: true,
        customCreatedAtIso: new Date(`${m.date}T07:45:00Z`).toISOString(),
      }
    );
    if (retroBuilt) {
      reportsMap.set(retroBuilt.id, retroBuilt);
    }
  }

  const historicalArchiveConfigs = [
    {
      date: "2026-09-26",
      venue: "Rosehill Gardens",
      state: "NSW",
      meetingId: "nsw-rosehill-gardens-2026-09-26",
      baseMeeting: completedMeetings.find((m) => m.state === "NSW") || completedMeetings[0],
    },
    {
      date: "2026-09-19",
      venue: "Caulfield",
      state: "VIC",
      meetingId: "vic-caulfield-2026-09-19",
      baseMeeting: completedMeetings.find((m) => m.state === "VIC") || completedMeetings[0],
    },
    {
      date: "2026-08-29",
      venue: "Royal Randwick",
      state: "NSW",
      meetingId: "nsw-royal-randwick-2026-08-29",
      baseMeeting: completedMeetings.find((m) => m.state === "NSW") || completedMeetings[0],
    },
  ];

  historicalArchiveConfigs.forEach((cfg, idx) => {
    if (!cfg.baseMeeting) return;
    const syntheticMeeting: RaceMeeting = {
      ...cfg.baseMeeting,
      id: cfg.meetingId,
      venue: cfg.venue,
      state: cfg.state,
      date: cfg.date,
    };
    const rId = `report-${syntheticMeeting.id}`;
    if (reportsMap.has(rId)) return;

    const retroPunters: PunterProfile[] = currentPunters.slice(0, 2).map((p, pIdx) => {
      const raceMap: Record<number, { firstPref: number; secondPref: number; thirdPref: number }> = {};
      for (const r of syntheticMeeting.races) {
        const byPos = [...r.runners].sort(
          (a, b) =>
            (a.finishPosition || 99) - (b.finishPosition || 99) ||
            (a.nswTabWin || 99) - (b.nswTabWin || 99)
        );
        const p1 = byPos[(pIdx + idx + (r.raceNumber % 2)) % Math.min(4, byPos.length)]?.tabNumber ?? 1;
        const p2 = byPos[(pIdx + idx + 1) % Math.min(5, byPos.length)]?.tabNumber ?? 2;
        const p3 = byPos[(pIdx + idx + 2) % Math.min(6, byPos.length)]?.tabNumber ?? 3;
        raceMap[r.raceNumber] = {
          firstPref: p1,
          secondPref: p2,
          thirdPref: p3,
        };
      }
      return {
        ...p,
        selectionsByMeeting: {
          [syntheticMeeting.id]: raceMap,
        },
        jokerRaceByMeeting: {
          [syntheticMeeting.id]:
            getFeatureRaceNumberForMeeting(syntheticMeeting) ??
            ((idx + pIdx * 2) % 6) + 3,
        },
      };
    });

    const built = buildRaceReportForMeeting(
      syntheticMeeting,
      retroPunters,
      trifectaBetAmount,
      {
        isRetroactive: true,
        customCreatedAtIso: new Date(`${cfg.date}T07:50:00Z`).toISOString(),
      }
    );
    if (built) {
      reportsMap.set(built.id, built);
    }
  });

  return pruneAndSortSixMonthReports(Array.from(reportsMap.values()));
}

/**
 * Filters out any reports older than 6 months (180 days) or with 0 active participation,
 * and sorts newest first.
 */
export function pruneAndSortSixMonthReports(
  reports: SavedRaceReport[]
): SavedRaceReport[] {
  const nowMs = Date.now();
  const sixMonthsAgoMs = nowMs - SIX_MONTHS_RETENTION_MS;

  return reports
    .filter((r) => {
      if (!r || !r.id) return false;
      if (
        !r.completedParticipatedRacesCount ||
        r.completedParticipatedRacesCount <= 0
      ) {
        return false;
      }
      const raceMs =
        Date.parse(`${r.raceDate}T00:00:00Z`) ||
        Date.parse(r.createdAtIso) ||
        nowMs;
      return raceMs >= sixMonthsAgoMs;
    })
    .sort((a, b) => {
      if (a.raceDate !== b.raceDate) {
        return b.raceDate.localeCompare(a.raceDate);
      }
      return b.updatedAtIso.localeCompare(a.updatedAtIso);
    });
}

export function loadLocalSixMonthReports(): SavedRaceReport[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_RACE_REPORTS_ARCHIVE);
    const parsed = safeJsonParse<SavedRaceReport[] | null>(raw, null);
    if (Array.isArray(parsed)) {
      return pruneAndSortSixMonthReports(parsed);
    }
  } catch {
    // ignore
  }
  return [];
}

export function saveLocalSixMonthReports(reports: SavedRaceReport[]): void {
  try {
    const pruned = pruneAndSortSixMonthReports(reports);
    localStorage.setItem(
      STORAGE_KEY_RACE_REPORTS_ARCHIVE,
      JSON.stringify(pruned)
    );
  } catch {
    // ignore
  }
}

/**
 * Short, punchy plain-text report from "Punters Club results" with Leaderboard,
 * Trifecta analysis, Quaddie analysis, and Race-by-Race results.
 */
export function formatPlainTextReportForEmail(report: SavedRaceReport): string {
  const lines: string[] = [];
  const upfront = report.assessment.upfrontParagraphs || [
    report.assessment.executiveSummary,
    report.assessment.trifectaVerdict,
  ];
  const q = report.quaddieSummary;

  lines.push(`FROM: ${REPORT_SENDER_NAME}`);
  lines.push(`REPORT: ${report.venue} (${report.state}) — ${report.raceDate}`);
  lines.push(`HEADLINE: ${report.assessment.headline}`);
  lines.push(`--------------------------------------------------------------------`);
  lines.push(`EXECUTIVE TELEMETRY & EXOTICS SUMMARY`);
  for (const p of upfront) {
    lines.push(`• ${p}`);
  }
  lines.push(`• ${report.assessment.stewardsFunnyConclusion}`);
  lines.push(``);
  lines.push(`LEADERBOARD STANDINGS`);
  lines.push(`--------------------------------------------------------------------`);
  for (const s of report.standings) {
    const jokerStr =
      s.jokerRaceNumber !== null
        ? s.jokerTriggered
          ? `2x Joker R${s.jokerRaceNumber} HIT (+${s.jokerBonusPoints} pts)`
          : `2x Joker R${s.jokerRaceNumber} (Missed)`
        : `No Joker`;
    lines.push(
      `#${s.rank} ${s.punterName}: ${s.totalPoints} pts | ${formatDollarReturn(s.totalDollarReturn)} | ${s.winnersPicked}W / ${s.podiumsPicked}P (${s.strikeRatePct}% SR) | Prefs 1st:${s.firstPrefHits} 2nd:${s.secondPrefHits} 3rd:${s.thirdPrefHits} | ${jokerStr}`
    );
  }
  lines.push(``);
  lines.push(`COMBINED TRIFECTA & QUADDIE ANALYSIS`);
  lines.push(`--------------------------------------------------------------------`);
  lines.push(
    `• Combined Boxed Trifecta ($${report.trifectaBetAmount}/race): ${report.trifectaSummary.trifectaHits}/${report.trifectaSummary.racesEvaluated} Hits | ${report.trifectaSummary.nearMisses2Of3} Near-Misses (2/3) | Outlay ${formatDollarReturn(report.trifectaSummary.totalOutlay)} -> Return ${formatDollarReturn(report.trifectaSummary.totalFlexiReturn)} (Net ${report.trifectaSummary.netProfit >= 0 ? "+" : "-"}${formatDollarReturn(Math.abs(report.trifectaSummary.netProfit))})`
  );
  if (q && q.legs.length > 0) {
    lines.push(
      `• Combined 4-Leg Quaddie ($${q.betAmount} Flexi · ${q.totalCombinations} Combos @ ${q.flexiPercentage}%): ${q.isWon ? "WON 4/4" : `${q.hitLegsCount}/${q.legs.length} Legs Hit`} (${q.combinationString}) | $1 Div $${q.officialOrEstimatedDividend.toFixed(2)} | Collect ${formatDollarReturn(q.flexiPayout)}`
    );
    for (const leg of q.legs) {
      lines.push(
        `  - Leg ${leg.legIndex} (R${leg.raceNumber} ${leg.raceName}): Winner ${leg.winnerText} ($${leg.winnerOdds.toFixed(2)}) | Status: ${leg.isResulted ? (leg.isHit ? "HIT" : "MISSED") : "PENDING"} | Pool (${leg.runnerCount}): ${leg.runnersText}`
      );
    }
  }
  lines.push(``);
  lines.push(`RACE-BY-RACE RESULTS`);
  lines.push(`--------------------------------------------------------------------`);
  for (const r of report.raceRows) {
    const uSummary = r.userCells
      .map(
        (u) =>
          `${u.punterName}: ${u.points}pts/${formatDollarReturn(u.dollarReturn)}${u.jokerTriggered ? " [2x JOKER]" : ""}`
      )
      .join(" | ");
    lines.push(
      `R${r.raceNumber} (${r.distance}m): 1st ${r.podium.first} ($${r.podium.firstWinOdds.toFixed(2)}), 2nd ${r.podium.second}, 3rd ${r.podium.third} || ${uSummary} || Trifecta: ${r.trifecta.isHit ? `HIT ${formatDollarReturn(r.trifecta.flexiReturnOnBet)}` : `${r.trifecta.hitCount}/3`} ($1 Div $${r.trifecta.officialDividend.toFixed(2)})`
    );
  }

  return lines.join("\n");
}

/**
 * Generates a broadcast-grade, highly polished graphical HTML email report from
 * "Punters Club results" with inline CSS visual charts, KPI scorecards,
 * 4-Leg Quaddie visual pipeline ($50/user buy-in), and Race-by-Race heatmap matrix.
 * Uses email-client safe table layouts + inline styles that render in Gmail,
 * Apple Mail, Outlook, and mobile mail clients without external stylesheets.
 */
export function formatHtmlReportForEmail(report: SavedRaceReport): string {
  const q = report.quaddieSummary;
  const upfront = report.assessment.upfrontParagraphs || [];
  const leader = report.standings[0];

  const totalPointsAll =
    report.analytics?.syndicateTotalPoints ??
    report.standings.reduce((s, u) => s + u.totalPoints, 0);
  const totalCashAll =
    report.analytics?.syndicateTotalCashReturn ??
    report.standings.reduce((s, u) => s + u.totalDollarReturn, 0);
  const groupStrikeRate =
    report.analytics?.syndicateStrikeRatePct ??
    (leader ? leader.strikeRatePct : 0);
  const groupWinRate = report.analytics?.syndicateWinRatePct ?? 0;
  const avgWinOdds = report.analytics?.avgWinningRunnerOdds ?? 0;

  const maxUserPts = Math.max(
    1,
    ...report.standings.map((s) => s.totalPoints)
  );
  const maxUserCash = Math.max(
    1,
    ...report.standings.map((s) => s.totalDollarReturn)
  );

  // 1. Graphical Leaderboard Rows with Inline Progress Bars
  const standingRowsHtml = report.standings
    .map((s, idx) => {
      const ptsPct = Math.max(6, Math.round((s.totalPoints / maxUserPts) * 100));
      const cashPct = Math.max(
        6,
        Math.round((s.totalDollarReturn / maxUserCash) * 100)
      );
      const srPct = Math.max(4, Math.min(100, s.strikeRatePct));
      const rankBg =
        idx === 0 ? "#d4af37" : idx === 1 ? "#9ba8a1" : "#1f2d26";
      const rankColor = idx <= 1 ? "#070b09" : "#f3f4f0";

      const jokerBadgeHtml =
        s.jokerRaceNumber !== null
          ? s.jokerTriggered
            ? `<span style="display:inline-block;padding:3px 7px;border-radius:4px;background:#d4af37;color:#070b09;font-weight:800;font-size:10px;">🃏 R${s.jokerRaceNumber} 2× HIT (+${s.jokerBonusPoints} pts)</span>`
            : `<span style="display:inline-block;padding:3px 7px;border-radius:4px;background:#192620;border:1px solid #2e453a;color:#d4af37;font-weight:700;font-size:10px;">🃏 R${s.jokerRaceNumber} (0 bonus)</span>`
          : `<span style="color:#8a9990;font-size:11px;">—</span>`;

      return `
      <tr style="border-bottom:1px solid #1e2e26;background:${idx === 0 ? "#13221a" : "#0e1713"};">
        <td style="padding:12px 10px;vertical-align:middle;">
          <span style="display:inline-block;padding:3px 8px;border-radius:5px;background:${rankBg};color:${rankColor};font-weight:800;font-size:11px;">#${s.rank}</span>
        </td>
        <td style="padding:12px 10px;vertical-align:middle;">
          <div style="font-weight:800;font-size:13px;color:#f3f4f0;">${s.punterName}</div>
          <div style="font-size:10px;color:#8a9990;margin-top:2px;">${s.role} · ${s.racesParticipated}R Played</div>
        </td>
        <td style="padding:12px 10px;vertical-align:middle;width:165px;">
          <div style="font-size:11px;font-weight:700;color:#f3f4f0;margin-bottom:4px;">
            ${s.winnersPicked}W / ${s.podiumsPicked}P <span style="color:#10b981;">(${s.strikeRatePct}% SR)</span>
          </div>
          <div style="width:100%;height:7px;background:#070b09;border-radius:4px;overflow:hidden;border:1px solid #1f2d26;">
            <div style="width:${srPct}%;height:7px;background:#10b981;border-radius:4px;"></div>
          </div>
          <div style="font-size:10px;color:#9ba8a1;margin-top:4px;">
            1st:<strong style="color:#d4af37;">${s.firstPrefHits}</strong> · 2nd:<strong style="color:#f3f4f0;">${s.secondPrefHits}</strong> · 3rd:<strong style="color:#10b981;">${s.thirdPrefHits}</strong>
          </div>
        </td>
        <td style="padding:12px 10px;vertical-align:middle;">
          ${jokerBadgeHtml}
        </td>
        <td style="padding:12px 10px;vertical-align:middle;text-align:right;width:125px;">
          <div style="font-size:15px;font-weight:800;color:#d4af37;">${s.totalPoints} pts</div>
          <div style="width:100%;height:6px;background:#070b09;border-radius:3px;overflow:hidden;margin-top:4px;">
            <div style="width:${ptsPct}%;height:6px;background:#d4af37;border-radius:3px;"></div>
          </div>
        </td>
        <td style="padding:12px 10px;vertical-align:middle;text-align:right;width:130px;">
          <div style="font-size:15px;font-weight:800;color:#10b981;">${formatDollarReturn(s.totalDollarReturn)}</div>
          <div style="width:100%;height:6px;background:#070b09;border-radius:3px;overflow:hidden;margin-top:4px;">
            <div style="width:${cashPct}%;height:6px;background:#10b981;border-radius:3px;"></div>
          </div>
        </td>
      </tr>`;
    })
    .join("");

  // 2. Graphical 4-Leg Quaddie Pipeline Cards ($50/user buy-in default)
  const quaddieBuyInPerUser = q?.buyInPerUser || DEFAULT_QUADDIE_BUY_IN_PER_USER;
  const quaddiePoolTotal = q?.betAmount || quaddieBuyInPerUser * Math.max(1, report.standings.length);
  const quaddieHtml =
    q && q.legs.length > 0
      ? `
    <div style="margin-top:22px;background:#0e1713;border:1px solid #10b981;border-radius:10px;overflow:hidden;">
      <div style="background:#13261d;padding:12px 16px;border-bottom:1px solid #1e382b;">
        <table style="width:100%;border-collapse:collapse;">
          <tr>
            <td style="vertical-align:middle;">
              <div style="font-size:10px;font-weight:800;color:#10b981;text-transform:uppercase;letter-spacing:0.08em;">
                COMBINED 4-LEG QUADDIE PIPELINE · $${quaddieBuyInPerUser}/USER BUY-IN ($${quaddiePoolTotal} SYNDICATE POOL)
              </div>
              <div style="font-size:15px;font-weight:800;color:#f3f4f0;margin-top:3px;">
                ${q.isWon ? "★ QUADDIE LANDED (4/4 LEGS)" : `${q.hitLegsCount} of ${q.legs.length} Quaddie Legs Landed`} · Winning Combo: <span style="color:#d4af37;">${q.combinationString}</span>
              </div>
            </td>
            <td style="vertical-align:middle;text-align:right;">
              <div style="font-size:11px;color:#9ba8a1;">${q.totalCombinations} Combos @ <strong style="color:#10b981;">${q.flexiPercentage}% Flexi</strong></div>
              <div style="font-size:14px;font-weight:800;color:${q.isWon ? "#10b981" : "#d4af37"};margin-top:2px;">
                ${q.isWon ? `Collect: ${formatDollarReturn(q.flexiPayout)} (${formatDollarReturn(q.flexiPayoutPerUser || q.flexiPayout / Math.max(1, report.standings.length))}/user)` : `$1 Div: $${q.officialOrEstimatedDividend.toFixed(2)}`}
              </div>
            </td>
          </tr>
        </table>
      </div>
      <div style="padding:14px;">
        <table style="width:100%;border-collapse:collapse;">
          <tr>
            ${q.legs
              .map((l) => {
                const statusBg = !l.isResulted
                  ? "#262010"
                  : l.isHit
                  ? "#112a1f"
                  : "#2a1215";
                const statusBorder = !l.isResulted
                  ? "#d4af37"
                  : l.isHit
                  ? "#10b981"
                  : "#ef4444";
                const statusColor = !l.isResulted
                  ? "#d4af37"
                  : l.isHit
                  ? "#10b981"
                  : "#f87171";
                const statusLabel = !l.isResulted
                  ? "PENDING"
                  : l.isHit
                  ? "✓ LEG HIT"
                  : "✕ LEG MISSED";
                const covPct = Math.max(6, Math.min(100, l.fieldCoveragePct));

                return `
                <td style="width:25%;padding:5px;vertical-align:top;">
                  <div style="background:${statusBg};border:1px solid ${statusBorder};border-radius:8px;padding:10px;min-height:135px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                      <span style="font-size:11px;font-weight:800;color:#f3f4f0;">LEG ${l.legIndex} · R${l.raceNumber}</span>
                      <span style="float:right;padding:2px 6px;border-radius:4px;background:#070b09;color:${statusColor};font-size:9px;font-weight:800;">${statusLabel}</span>
                    </div>
                    <div style="font-size:10px;color:#9ba8a1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:6px;">
                      ${l.raceName}
                    </div>
                    <div style="padding:6px;background:#070b09;border-radius:5px;margin-bottom:7px;">
                      <div style="font-size:9px;color:#8a9990;text-transform:uppercase;">Official Winner</div>
                      <div style="font-size:11px;font-weight:800;color:#d4af37;margin-top:1px;">
                        ${l.winnerText} ${l.winnerOdds > 0 ? `<span style="color:#10b981;">($${l.winnerOdds.toFixed(2)})</span>` : ""}
                      </div>
                    </div>
                    <div style="font-size:10px;color:#d5ddd8;margin-bottom:4px;">
                      Coverage: <strong>${l.runnerCount}/${l.fieldSize}</strong> (${l.fieldCoveragePct}%)
                    </div>
                    <div style="width:100%;height:5px;background:#070b09;border-radius:3px;overflow:hidden;margin-bottom:6px;">
                      <div style="width:${covPct}%;height:5px;background:${statusColor};border-radius:3px;"></div>
                    </div>
                    <div style="font-size:10px;color:#9ba8a1;line-height:1.35;">
                      Pool: <strong style="color:#f3f4f0;">${l.runnersText || "None"}</strong>
                    </div>
                  </div>
                </td>`;
              })
              .join("")}
          </tr>
        </table>
      </div>
    </div>`
      : "";

  // 3. Graphical Race-by-Race Heatmap & Trifecta Matrix Rows
  const raceMatrixRowsHtml = report.raceRows
    .map((r, rIdx) => {
      const userColsHtml = r.userCells
        .map((u) => {
          const cellBg =
            u.points >= 4
              ? "#241d0c"
              : u.points > 0 || u.dollarReturn > 0
              ? "#10261c"
              : "#0b120f";
          const cellColor =
            u.points >= 4
              ? "#d4af37"
              : u.points > 0 || u.dollarReturn > 0
              ? "#10b981"
              : "#8a9990";
          return `
          <td style="padding:9px 8px;vertical-align:middle;background:${cellBg};border-left:1px solid #1a2921;">
            <div style="font-size:12px;font-weight:800;color:${cellColor};">
              ${u.points} pts · ${formatDollarReturn(u.dollarReturn)}
              ${u.isJokerRace ? `<span style="display:inline-block;margin-left:3px;padding:1px 4px;border-radius:3px;background:#d4af37;color:#070b09;font-size:9px;font-weight:800;">🃏2×</span>` : ""}
            </div>
            <div style="font-size:10px;color:#9ba8a1;margin-top:2px;">${u.hitSummary}</div>
          </td>`;
        })
        .join("");

      const triHitPct = Math.round((r.trifecta.hitCount / 3) * 100);
      const triColor = r.trifecta.isHit
        ? "#10b981"
        : r.trifecta.hitCount === 2
        ? "#d4af37"
        : "#6b7d73";

      return `
      <tr style="border-bottom:1px solid #1a2921;background:${rIdx % 2 === 0 ? "#0e1713" : "#0b130f"};">
        <td style="padding:9px 8px;vertical-align:middle;">
          <span style="display:inline-block;padding:2px 6px;border-radius:4px;background:#192620;border:1px solid #d4af37;color:#d4af37;font-weight:800;font-size:11px;">R${r.raceNumber}</span>
          <div style="font-size:10px;color:#8a9990;margin-top:2px;">${r.distance}m</div>
        </td>
        <td style="padding:9px 8px;vertical-align:middle;">
          <div style="font-size:11px;font-weight:800;color:#d4af37;">1st: ${r.podium.first} <span style="color:#10b981;">($${r.podium.firstWinOdds.toFixed(2)})</span></div>
          <div style="font-size:10px;color:#d5ddd8;margin-top:2px;">2nd: ${r.podium.second} · 3rd: ${r.podium.third}</div>
        </td>
        ${userColsHtml}
        <td style="padding:9px 8px;vertical-align:middle;text-align:right;border-left:1px solid #1a2921;width:140px;">
          <div style="font-size:11px;font-weight:800;color:${triColor};">
            ${r.trifecta.isHit ? `★ HIT ${formatDollarReturn(r.trifecta.flexiReturnOnBet)}` : `${r.trifecta.hitCount}/3 Podium`}
          </div>
          <div style="width:100%;height:5px;background:#070b09;border-radius:3px;overflow:hidden;margin:4px 0;">
            <div style="width:${triHitPct}%;height:5px;background:${triColor};border-radius:3px;"></div>
          </div>
          <div style="font-size:9px;color:#8a9990;">$1 Div: $${r.trifecta.officialDividend.toFixed(2)} (${r.trifecta.poolCount}H)</div>
        </td>
      </tr>`;
    })
    .join("");

  const userTableHeadersHtml = report.standings
    .map(
      (s) =>
        `<th style="padding:9px 8px;text-align:left;border-left:1px solid #1a2921;">${s.punterName}</th>`
    )
    .join("");

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${REPORT_SENDER_NAME} — ${report.venue} (${report.raceDate})</title>
</head>
<body style="margin:0;padding:16px;background-color:#060a08;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#f3f4f0;">
  <div style="max-width:840px;margin:0 auto;background-color:#0b110e;border:1px solid #23352c;border-radius:14px;overflow:hidden;box-shadow:0 16px 40px rgba(0,0,0,0.65);">
    
    <!-- MASTHEAD HEADER -->
    <div style="background:linear-gradient(135deg,#13281e 0%,#0b1510 60%,#1c180c 100%);padding:22px 24px;border-bottom:2px solid #d4af37;">
      <table style="width:100%;border-collapse:collapse;">
        <tr>
          <td style="vertical-align:middle;">
            <div style="display:inline-block;padding:4px 10px;border-radius:5px;background:#d4af37;color:#070b09;font-size:10px;font-weight:900;text-transform:uppercase;letter-spacing:0.1em;">
              ${REPORT_SENDER_NAME} · OFFICIAL GRAPHICAL REPORT
            </div>
            <h1 style="margin:10px 0 4px;font-size:22px;line-height:1.25;font-weight:900;color:#f3f4f0;">
              ${report.assessment.headline}
            </h1>
            <div style="font-size:12px;color:#9ba8a1;">
              Venue: <strong style="color:#f3f4f0;">${report.venue} (${report.state})</strong> · Date: <strong style="color:#d4af37;">${report.raceDate}</strong> · Completed Races: <strong style="color:#10b981;">${report.completedParticipatedRacesCount}/${report.totalCardRacesCount}</strong>
            </div>
          </td>
          <td style="vertical-align:top;text-align:right;">
            <div style="display:inline-block;padding:8px 12px;background:#070b09;border:1px solid #d4af37;border-radius:8px;text-align:right;">
              <div style="font-size:9px;color:#8a9990;text-transform:uppercase;">Card Leader</div>
              <div style="font-size:14px;font-weight:900;color:#d4af37;">${leader?.punterName || "Syndicate"}</div>
              <div style="font-size:11px;font-weight:700;color:#10b981;">${leader?.totalPoints || 0} pts · ${formatDollarReturn(leader?.totalDollarReturn || 0)}</div>
            </div>
          </td>
        </tr>
      </table>
    </div>

    <div style="padding:20px 24px;">
      <!-- 6-CARD GRAPHICAL KPI SCOREBOARD -->
      <table style="width:100%;border-collapse:collapse;margin-bottom:20px;">
        <tr>
          <td style="width:33.33%;padding:5px;vertical-align:top;">
            <div style="background:#101a15;border:1px solid #1f2d26;border-radius:9px;padding:12px;">
              <div style="font-size:10px;color:#8a9990;text-transform:uppercase;font-weight:700;">Syndicate Cash Return</div>
              <div style="font-size:20px;font-weight:900;color:#10b981;margin-top:3px;">${formatDollarReturn(totalCashAll)}</div>
              <div style="font-size:10px;color:#9ba8a1;margin-top:3px;">Win Rate: <strong style="color:#f3f4f0;">${groupWinRate}%</strong> · Avg Winner: <strong style="color:#d4af37;">$${avgWinOdds.toFixed(2)}</strong></div>
            </div>
          </td>
          <td style="width:33.33%;padding:5px;vertical-align:top;">
            <div style="background:#101a15;border:1px solid #1f2d26;border-radius:9px;padding:12px;">
              <div style="font-size:10px;color:#8a9990;text-transform:uppercase;font-weight:700;">Syndicate Points &amp; Strike Rate</div>
              <div style="font-size:20px;font-weight:900;color:#d4af37;margin-top:3px;">${totalPointsAll} pts <span style="font-size:12px;color:#10b981;">(${groupStrikeRate}% SR)</span></div>
              <div style="width:100%;height:6px;background:#070b09;border-radius:3px;overflow:hidden;margin-top:6px;">
                <div style="width:${Math.max(8, Math.min(100, groupStrikeRate))}%;height:6px;background:#d4af37;border-radius:3px;"></div>
              </div>
            </div>
          </td>
          <td style="width:33.33%;padding:5px;vertical-align:top;">
            <div style="background:#101a15;border:1px solid #1f2d26;border-radius:9px;padding:12px;">
              <div style="font-size:10px;color:#8a9990;text-transform:uppercase;font-weight:700;">Boxed Trifectas ($${report.trifectaBetAmount}/R) &amp; Quaddie ($${quaddieBuyInPerUser}/U)</div>
              <div style="font-size:15px;font-weight:900;color:#f3f4f0;margin-top:4px;">
                Tri: <span style="color:#d4af37;">${report.trifectaSummary.trifectaHits}/${report.trifectaSummary.racesEvaluated}</span> (${report.trifectaSummary.nearMisses2Of3}× 2/3) · Quad: <span style="color:#10b981;">${q ? `${q.hitLegsCount}/${q.legs.length}` : "—"}</span>
              </div>
              <div style="font-size:10px;color:#9ba8a1;margin-top:4px;">
                Tri Return: <strong style="color:#10b981;">${formatDollarReturn(report.trifectaSummary.totalFlexiReturn)}</strong> · Quad Pool: <strong style="color:#d4af37;">$${quaddiePoolTotal}</strong>
              </div>
            </div>
          </td>
        </tr>
      </table>

      <!-- CONCISE EXECUTIVE TELEMETRY CARDS -->
      <div style="background:#101914;border:1px solid #23352c;border-left:4px solid #d4af37;border-radius:8px;padding:14px 16px;margin-bottom:20px;">
        <div style="font-size:10px;font-weight:800;color:#d4af37;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:8px;">
          EXECUTIVE TELEMETRY · TRIFECTA &amp; QUADDIE ANALYSIS
        </div>
        ${upfront
          .map(
            (p) =>
              `<div style="font-size:12px;line-height:1.5;color:#e5ece8;margin-bottom:7px;">• ${p}</div>`
          )
          .join("")}
        <div style="font-size:12px;font-weight:800;color:#d4af37;margin-top:6px;padding-top:6px;border-top:1px solid #1e2e26;">
          ${report.assessment.stewardsFunnyConclusion}
        </div>
      </div>

      <!-- GRAPHICAL LEADERBOARD & BAR CHART TABLE -->
      <div style="margin-bottom:6px;font-size:11px;font-weight:800;color:#d4af37;text-transform:uppercase;letter-spacing:0.08em;">
        SYNDICATE STANDINGS, PREFERENCE ACCURACY &amp; FEATURE JOKER (2×) TELEMETRY
      </div>
      <table style="width:100%;border-collapse:collapse;background:#0e1713;border:1px solid #1f2d26;border-radius:10px;overflow:hidden;">
        <thead>
          <tr style="background:#070b09;color:#8a9990;text-align:left;font-size:10px;text-transform:uppercase;letter-spacing:0.06em;">
            <th style="padding:10px;">Rank</th>
            <th style="padding:10px;">Syndicate Member</th>
            <th style="padding:10px;">Strike Rate &amp; Pref Splits</th>
            <th style="padding:10px;">Feature Joker (2×)</th>
            <th style="padding:10px;text-align:right;">Points Bar</th>
            <th style="padding:10px;text-align:right;">Cash Return Bar</th>
          </tr>
        </thead>
        <tbody>
          ${standingRowsHtml}
        </tbody>
      </table>

      <!-- GRAPHICAL 4-LEG QUADDIE PIPELINE -->
      ${quaddieHtml}

      <!-- GRAPHICAL RACE-BY-RACE HEATMAP & TRIFECTA MATRIX -->
      <div style="margin-top:22px;margin-bottom:6px;font-size:11px;font-weight:800;color:#d4af37;text-transform:uppercase;letter-spacing:0.08em;">
        RACE-BY-RACE RESULTS HEATMAP &amp; COMBINED BOXED TRIFECTA ($${report.trifectaBetAmount}/RACE) MATRIX
      </div>
      <table style="width:100%;border-collapse:collapse;background:#0e1713;border:1px solid #1f2d26;border-radius:10px;overflow:hidden;">
        <thead>
          <tr style="background:#070b09;color:#8a9990;text-align:left;font-size:10px;text-transform:uppercase;letter-spacing:0.06em;">
            <th style="padding:9px 8px;">Race</th>
            <th style="padding:9px 8px;">Official Podium (1st / 2nd / 3rd)</th>
            ${userTableHeadersHtml}
            <th style="padding:9px 8px;text-align:right;border-left:1px solid #1a2921;">Boxed Trifecta</th>
          </tr>
        </thead>
        <tbody>
          ${raceMatrixRowsHtml}
        </tbody>
      </table>
    </div>

    <!-- FOOTER -->
    <div style="background:#070b09;padding:14px 24px;border-top:1px solid #1f2d26;font-size:11px;color:#8a9990;text-align:center;">
      Dispatched automatically by <strong style="color:#d4af37;">${REPORT_SENDER_NAME}</strong> · TurfSheet NSW &amp; VIC Syndicate Analytics
    </div>
  </div>
</body>
</html>`;
}
