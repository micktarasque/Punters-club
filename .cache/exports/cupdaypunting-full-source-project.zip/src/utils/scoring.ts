import type {
  PunterProfile,
  RaceEvent,
  RaceRunner,
  RaceSelectionTrio,
} from "../types/racing.ts";
import {
  SEED_NSW_TAB_MEETINGS,
  isRaceOfficialOrCompleted,
} from "../data/seedNswTab.ts";

export const DEFAULT_QUADDIE_BUY_IN_PER_USER = 50;

export function getPointsForFinishPosition(finishPosition: number): number {
  if (finishPosition === 1) return 3;
  if (finishPosition === 2) return 2;
  if (finishPosition === 3) return 1;
  return 0;
}

/**
 * Calculate the $ Return for a single preference selection (assuming a $1 unit stake):
 * - 1st Preference: Win + Place dividend if the horse finishes 1st; Place dividend if it finishes 2nd or 3rd; $0 otherwise.
 * - 2nd Preference: Place dividend if the horse finishes 1st, 2nd, or 3rd; $0 otherwise.
 * - 3rd Preference: Place dividend if the horse finishes 1st, 2nd, or 3rd; $0 otherwise.
 */
export function getDollarReturnForPick(
  preferenceRank: 1 | 2 | 3,
  runner: RaceRunner | null
): number {
  if (!runner) return 0;
  const pos = runner.finishPosition;
  const winDiv = Number(runner.nswTabWin) || 0;
  const placeDiv = Number(runner.nswTabPlace) || 0;

  if (preferenceRank === 1) {
    if (pos === 1) {
      return Number((winDiv + placeDiv).toFixed(2));
    }
    if (pos === 2 || pos === 3) {
      return Number(placeDiv.toFixed(2));
    }
    return 0;
  }

  // 2nd and 3rd preference selections are Place-only bets
  if (pos === 1 || pos === 2 || pos === 3) {
    return Number(placeDiv.toFixed(2));
  }

  return 0;
}

export interface EvaluatedPickDetail {
  preferenceRank: 1 | 2 | 3;
  tabNumber: number | null;
  runner: RaceRunner | null;
  finishPosition: number;
  basePoints: number;
  points: number;
  dollarReturn: number;
  winDividend: number;
  placeDividend: number;
}

export interface EvaluatedRaceSelection {
  raceNumber: number;
  isComplete: boolean;
  hasAnySelection: boolean;
  isOfficialResult: boolean;
  isRaceResulted: boolean;
  isJokerRace: boolean;
  jokerTriggered: boolean;
  jokerBonusPoints: number;
  baseRacePointsTally: number;
  picks: [EvaluatedPickDetail, EvaluatedPickDetail, EvaluatedPickDetail];
  racePointsTally: number;
  raceDollarReturn: number;
}

export type EvaluatedRaceResult = EvaluatedRaceSelection;

/**
 * Evaluates a user's 3-horse preference trio for a race.
 * Joker Round Rule:
 * - Each user can select 1 preferred race per meeting as their Joker Round (`isJokerRace = true`).
 * - If their selected 1st Preference horse (`firstPref`, rank 1) WINS (`finishPosition === 1`) in an officially completed race,
 *   they receive DOUBLE POINTS (2x) for that race!
 */
export function evaluateRaceTrio(
  race: RaceEvent,
  trio: RaceSelectionTrio | undefined,
  meetingDate?: string,
  isJokerRace: boolean = false
): EvaluatedRaceSelection {
  const ranks: [1, 2, 3] = [1, 2, 3];
  const tabNumbers: [number | null, number | null, number | null] = [
    trio?.firstPref ?? null,
    trio?.secondPref ?? null,
    trio?.thirdPref ?? null,
  ];

  const hasAnySelection =
    tabNumbers[0] !== null || tabNumbers[1] !== null || tabNumbers[2] !== null;

  const isRaceResulted =
    isRaceOfficialOrCompleted(race, meetingDate) &&
    race.runners.some((r) => r.finishPosition === 1);

  const firstPrefRunner =
    tabNumbers[0] !== null
      ? race.runners.find((r) => r.tabNumber === tabNumbers[0]) ?? null
      : null;

  // Joker triggers ONLY when this is the user's nominated Joker Race AND their selected 1st place (1st Pref) horse wins!
  const jokerTriggered = Boolean(
    isJokerRace &&
      isRaceResulted &&
      tabNumbers[0] !== null &&
      firstPrefRunner?.finishPosition === 1
  );

  const picks = ranks.map((rank, idx) => {
    const tabNo = tabNumbers[idx];
    const runner =
      tabNo !== null
        ? race.runners.find((r) => r.tabNumber === tabNo) ?? null
        : null;
    const finishPosition =
      isRaceResulted && runner ? runner.finishPosition : 0;

    // Only award points or dollar return when the race is officially completed AND the user has selected a horse
    const basePoints =
      tabNo !== null && isRaceResulted
        ? getPointsForFinishPosition(finishPosition)
        : 0;

    // Double points if Joker Round is triggered (selected 1st Preference horse wins)
    const points = jokerTriggered ? basePoints * 2 : basePoints;

    const dollarReturn =
      tabNo !== null && isRaceResulted
        ? getDollarReturnForPick(rank, runner)
        : 0;
    const winDividend = runner ? Number(runner.nswTabWin) || 0 : 0;
    const placeDividend = runner ? Number(runner.nswTabPlace) || 0 : 0;

    return {
      preferenceRank: rank,
      tabNumber: tabNo,
      runner,
      finishPosition,
      basePoints,
      points,
      dollarReturn,
      winDividend,
      placeDividend,
    };
  }) as [EvaluatedPickDetail, EvaluatedPickDetail, EvaluatedPickDetail];

  const isComplete =
    tabNumbers[0] !== null &&
    tabNumbers[1] !== null &&
    tabNumbers[2] !== null &&
    new Set(tabNumbers).size === 3;

  const baseRacePointsTally =
    hasAnySelection && isRaceResulted
      ? picks[0].basePoints + picks[1].basePoints + picks[2].basePoints
      : 0;

  const racePointsTally =
    hasAnySelection && isRaceResulted
      ? picks[0].points + picks[1].points + picks[2].points
      : 0;

  const jokerBonusPoints = Math.max(0, racePointsTally - baseRacePointsTally);

  const raceDollarReturn =
    hasAnySelection && isRaceResulted
      ? Number(
          (
            picks[0].dollarReturn +
            picks[1].dollarReturn +
            picks[2].dollarReturn
          ).toFixed(2)
        )
      : 0;

  return {
    raceNumber: race.raceNumber,
    isComplete,
    hasAnySelection,
    isOfficialResult: isRaceResulted,
    isRaceResulted,
    isJokerRace,
    jokerTriggered,
    jokerBonusPoints,
    baseRacePointsTally,
    picks,
    racePointsTally,
    raceDollarReturn,
  };
}

export function formatDollarReturn(amount: number): string {
  if (!amount || amount <= 0) return "$0.00";
  return `$${amount.toFixed(2)}`;
}

export interface CombinedRunnerEntry {
  tabNumber: number;
  runner: RaceRunner | null;
  pickedByUsers: Array<{
    punterId: string;
    punterName: string;
    preferenceRank: 1 | 2 | 3;
  }>;
  consensusWeight: number; // 1st Pref = 3, 2nd Pref = 2, 3rd Pref = 1
  finishPosition: number;
}

export interface UserTrifectaPickEntry {
  punterId: string;
  punterName: string;
  preferenceRank: 1 | 2 | 3;
  tabNumber: number;
  runner: RaceRunner | null;
}

export interface CombinedRaceTrifectaEvaluation {
  raceNumber: number;
  isRaceResulted: boolean;
  hasCombinedSelections: boolean;
  participatingUserCount: number;
  totalUserPicksCount: number; // Total horse picks made across all users (e.g. 2 users x 3 = 6, 3 users x 3 = 9)
  allUserSelections: UserTrifectaPickEntry[]; // Every horse selected by every user
  combinedRunners: CombinedRunnerEntry[]; // All horses in the cumulative Trifecta pool across all users
  boxedCombinationsCount: number; // n * (n - 1) * (n - 2) for ALL n horses selected by users
  officialPodium: {
    first: RaceRunner | null;
    second: RaceRunner | null;
    third: RaceRunner | null;
  };
  podiumHitFlags: {
    firstInCombined: boolean;
    secondInCombined: boolean;
    thirdInCombined: boolean;
    hitCount: number; // 0, 1, 2, or 3
  };
  isCombinedBoxedTrifectaHit: boolean;
  officialTrifectaCombination: string;
  trifectaBetAmount: number; // Default $20, user customizable
  flexiPercentage: number; // (trifectaBetAmount / combos) * 100 across ALL selected horses
  bookmakerTrifectaDividend: number; // Official $1 unit Trifecta dividend from bookmaker/tote
  trifectaOddsOnBetAmount: number; // Boxed Trifecta payout for this race based on trifectaBetAmount (default $20) across ALL selected horses
  straightPayoutOnBetAmount: number; // Straight Trifecta payout for trifectaBetAmount ($20 x $1 dividend)
  estimatedUpcomingTrifectaDividend: number; // Estimated $1 base dividend across ALL selected horses when race is not yet resulted
  estimatedPayoutOnBetAmount: number; // Estimated Boxed Trifecta payout based on trifectaBetAmount (default $20) across ALL selected horses
  capturedTrifectaReturn: number; // Gross $1 unit Trifecta return won when hit
  customBetFlexiReturn: number; // Won Flexi Boxed Trifecta return on trifectaBetAmount (default $20) across ALL selected horses
  flexi20Return: number; // Return on the active Flexi Boxed Trifecta stake (default $20)
}

function normalizeVenueSlugForMatch(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/^[a-z]{2,3}-/i, "")
    .replace(/-\d{4}-\d{2}-\d{2}$/, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(
      /^(royal-|aami-|tab-|ladbrokes-|sportsbet-|picklebet-|bet365-|schweppes-|quayclean-)/,
      ""
    )
    .replace(
      /(-gardens|-racecourse|-park|-parks|-hillside|-lakeside|-valley|-downs)$/,
      ""
    )
    .replace(/^-|-$/g, "");
}

function doesMeetingKeyMatchTarget(
  key: string,
  meeting: { id: string; venue?: string; date?: string }
): boolean {
  if (key === meeting.id) return true;
  const mDate = meeting.date || meeting.id.slice(-10);
  if (!key.endsWith(mDate)) return false;

  const targetRaw =
    meeting.venue ||
    meeting.id
      .replace(/^[a-z]{2,3}-/i, "")
      .replace(/-\d{4}-\d{2}-\d{2}$/, "");
  const targetSlug = normalizeVenueSlugForMatch(targetRaw);
  const keySlug = normalizeVenueSlugForMatch(key);

  if (!targetSlug || !keySlug) return false;
  if (
    keySlug === targetSlug ||
    keySlug.includes(targetSlug) ||
    targetSlug.includes(keySlug)
  ) {
    return true;
  }
  const pfx = targetSlug.slice(0, 4);
  return pfx.length >= 4 && keySlug.startsWith(pfx);
}

/**
 * Combines selections from all users for a race to form the Syndicate Trifecta pool,
 * ensuring selections saved under any matching venue/date key are included.
 */
export function getPunterSelectionsForMeeting(
  punter: PunterProfile,
  meeting: { id: string; venue?: string; date?: string }
): Record<number, RaceSelectionTrio> {
  const allMaps = punter.selectionsByMeeting || {};
  const direct = allMaps[meeting.id] || {};

  const merged: Record<number, RaceSelectionTrio> = {};
  for (const [rKey, trio] of Object.entries(direct)) {
    const rNo = Number(rKey);
    if (!rNo || !trio) continue;
    merged[rNo] = {
      firstPref:
        trio.firstPref !== null && trio.firstPref !== undefined
          ? Number(trio.firstPref)
          : null,
      secondPref:
        trio.secondPref !== null && trio.secondPref !== undefined
          ? Number(trio.secondPref)
          : null,
      thirdPref:
        trio.thirdPref !== null && trio.thirdPref !== undefined
          ? Number(trio.thirdPref)
          : null,
      updatedAt: trio.updatedAt,
    };
  }

  for (const [k, raceMap] of Object.entries(allMaps)) {
    if (k === meeting.id || !raceMap) continue;
    if (doesMeetingKeyMatchTarget(k, meeting)) {
      for (const [rKey, trio] of Object.entries(raceMap)) {
        const rNo = Number(rKey);
        if (!rNo || !trio) continue;
        const normIncoming: RaceSelectionTrio = {
          firstPref:
            trio.firstPref !== null && trio.firstPref !== undefined
              ? Number(trio.firstPref)
              : null,
          secondPref:
            trio.secondPref !== null && trio.secondPref !== undefined
              ? Number(trio.secondPref)
              : null,
          thirdPref:
            trio.thirdPref !== null && trio.thirdPref !== undefined
              ? Number(trio.thirdPref)
              : null,
          updatedAt: trio.updatedAt,
        };
        const existing = merged[rNo];
        const existingCount = existing
          ? [existing.firstPref, existing.secondPref, existing.thirdPref].filter(
              (x) => x !== null
            ).length
          : 0;
        const incomingCount = [
          normIncoming.firstPref,
          normIncoming.secondPref,
          normIncoming.thirdPref,
        ].filter((x) => x !== null).length;

        if (existingCount === 0 && incomingCount > 0) {
          merged[rNo] = normIncoming;
        } else if (existingCount > 0 && incomingCount > 0) {
          if (incomingCount > existingCount) {
            merged[rNo] = {
              firstPref: existing.firstPref ?? normIncoming.firstPref,
              secondPref: existing.secondPref ?? normIncoming.secondPref,
              thirdPref: existing.thirdPref ?? normIncoming.thirdPref,
              updatedAt:
                (normIncoming.updatedAt || "") > (existing.updatedAt || "")
                  ? normIncoming.updatedAt
                  : existing.updatedAt,
            };
          } else if (
            (normIncoming.updatedAt || "") > (existing.updatedAt || "")
          ) {
            merged[rNo] = normIncoming;
          }
        }
      }
    }
  }
  return merged;
}

export function parsePrizeMoneyValue(raw?: string | null): number {
  if (!raw || typeof raw !== "string") return 0;
  const s = raw.trim().toUpperCase();
  if (!s || s === "-") return 0;
  const millionMatch = s.match(/([\d,.]+)\s*M\b/);
  if (millionMatch) {
    const val = Number(millionMatch[1].replace(/,/g, ""));
    if (Number.isFinite(val)) return Math.round(val * 1_000_000);
  }
  const thousandMatch = s.match(/([\d,.]+)\s*K\b/);
  if (thousandMatch) {
    const val = Number(thousandMatch[1].replace(/,/g, ""));
    if (Number.isFinite(val)) return Math.round(val * 1_000);
  }
  const numeric = Number(s.replace(/[^0-9.]/g, ""));
  return Number.isFinite(numeric) ? numeric : 0;
}

function getFeatureRaceScore(race: RaceEvent, totalRacesOnCard: number): number {
  const prize = parsePrizeMoneyValue(race.prizeMoney);
  const text = `${race.classGrade || ""} ${race.pattern || ""} ${race.raceName || ""}`.toLowerCase();

  let patternBonus = 0;
  if (race.bigRace) patternBonus += 500_000;
  if (/\b(group\s*1|grp\s*1|g1)\b/.test(text)) patternBonus += 2_000_000;
  else if (/\b(group\s*2|grp\s*2|g2)\b/.test(text)) patternBonus += 1_000_000;
  else if (/\b(group\s*3|grp\s*3|g3)\b/.test(text)) patternBonus += 600_000;
  else if (/\b(listed|feature)\b/.test(text)) patternBonus += 350_000;

  if (
    /\b(everest|guineas|cup|stakes|classic|plate|mile|trophy|championship|golden eagle|slipper|doncaster|epsom|turnbull|cox plate|melbourne cup|caulfield cup)\b/.test(
      text
    )
  ) {
    patternBonus += 150_000;
  }

  // Prefer the traditional Australian feature race slot (penultimate or 3rd-last race, e.g. R7 or R8) on ties
  const idealFeatureRaceNo = Math.max(1, totalRacesOnCard - 2);
  const slotClosenessBonus =
    Math.max(0, 10 - Math.abs(race.raceNumber - idealFeatureRaceNo)) * 100;

  return prize * 10 + patternBonus + slotClosenessBonus;
}

/**
 * Identifies the primary Feature Race on a race meeting card (highest stakes / Group / Feature race).
 */
export function getFeatureRaceForMeeting(meeting: {
  id: string;
  venue?: string;
  date?: string;
  races?: RaceEvent[];
}): RaceEvent | null {
  let races = meeting.races;
  if (!Array.isArray(races) || races.length === 0) {
    const fallbackMeeting = SEED_NSW_TAB_MEETINGS.find((m) =>
      doesMeetingKeyMatchTarget(m.id, meeting)
    );
    races = fallbackMeeting?.races;
  }
  if (!Array.isArray(races) || races.length === 0) return null;

  const sortedByRaceNo = [...races].sort((a, b) => a.raceNumber - b.raceNumber);
  const totalRaces = sortedByRaceNo.length;

  let bestRace: RaceEvent =
    sortedByRaceNo[Math.max(0, totalRaces - 2)] || sortedByRaceNo[0];
  let bestScore = -1;

  for (const r of sortedByRaceNo) {
    const score = getFeatureRaceScore(r, totalRaces);
    if (score > bestScore) {
      bestScore = score;
      bestRace = r;
    }
  }

  return bestRace;
}

export function getFeatureRaceNumberForMeeting(meeting: {
  id: string;
  venue?: string;
  date?: string;
  races?: RaceEvent[];
}): number | null {
  return getFeatureRaceForMeeting(meeting)?.raceNumber ?? null;
}

export function isFeatureRaceOnMeeting(
  race: RaceEvent,
  meeting: { id: string; venue?: string; date?: string; races?: RaceEvent[] }
): boolean {
  const featureNo = getFeatureRaceNumberForMeeting(meeting);
  return featureNo !== null && race.raceNumber === featureNo;
}

/**
 * Resolves a punter's Joker Race for a meeting.
 * Defaults automatically to the meeting's Feature Race unless the user has explicitly selected
 * a different race or explicitly cleared their Joker (`null`).
 */
export function getPunterJokerForMeeting(
  punter: PunterProfile,
  meeting: { id: string; venue?: string; date?: string; races?: RaceEvent[] }
): number | null {
  const jMap = punter.jokerRaceByMeeting || {};
  if (Object.prototype.hasOwnProperty.call(jMap, meeting.id)) {
    const explicitVal = jMap[meeting.id];
    if (explicitVal !== undefined) {
      return explicitVal;
    }
  }
  for (const [k, jRace] of Object.entries(jMap)) {
    if (jRace === undefined) continue;
    if (doesMeetingKeyMatchTarget(k, meeting)) {
      return jRace;
    }
  }
  return getFeatureRaceNumberForMeeting(meeting);
}

/**
 * Evaluates the Combined Syndicate Trifecta for a race by adding ALL horses
 * selected by ALL users (1st, 2nd, and 3rd preferences across every user).
 * Never restricts or slices the cumulative selections to 3 horses.
 */
export function evaluateCombinedTrifectaForRace(
  race: RaceEvent,
  punters: PunterProfile[],
  meetingId: string,
  meetingDate?: string,
  customTrifectaBetAmount: number = 20,
  meetingVenue?: string
): CombinedRaceTrifectaEvaluation {
  const trifectaBetAmount =
    Number.isFinite(customTrifectaBetAmount) && customTrifectaBetAmount > 0
      ? Number(customTrifectaBetAmount.toFixed(2))
      : 20;
  const isRaceResulted =
    isRaceOfficialOrCompleted(race, meetingDate) &&
    race.runners.some((r) => r.finishPosition === 1);

  const runnerMap = new Map<number, CombinedRunnerEntry>();
  const allUserSelections: UserTrifectaPickEntry[] = [];
  let participatingUserCount = 0;

  for (const punter of punters) {
    const mSelections = getPunterSelectionsForMeeting(punter, {
      id: meetingId,
      venue: meetingVenue,
      date: meetingDate,
    });
    const trio = mSelections[race.raceNumber];
    if (!trio) continue;

    const entries: Array<{
      rank: 1 | 2 | 3;
      tab: number | null;
      weight: number;
    }> = [
      {
        rank: 1,
        tab:
          trio.firstPref !== null && trio.firstPref !== undefined
            ? Number(trio.firstPref)
            : null,
        weight: 3,
      },
      {
        rank: 2,
        tab:
          trio.secondPref !== null && trio.secondPref !== undefined
            ? Number(trio.secondPref)
            : null,
        weight: 2,
      },
      {
        rank: 3,
        tab:
          trio.thirdPref !== null && trio.thirdPref !== undefined
            ? Number(trio.thirdPref)
            : null,
        weight: 1,
      },
    ];

    const validEntries = entries.filter(
      (e): e is { rank: 1 | 2 | 3; tab: number; weight: number } =>
        e.tab !== null && Number.isFinite(e.tab) && e.tab > 0
    );

    if (validEntries.length > 0) {
      participatingUserCount += 1;
    }

    // Add EVERY horse selected by this user into the cumulative Trifecta pool
    for (const item of validEntries) {
      const runnerObj =
        race.runners.find((r) => r.tabNumber === item.tab) ?? null;

      allUserSelections.push({
        punterId: punter.id,
        punterName: punter.name,
        preferenceRank: item.rank,
        tabNumber: item.tab,
        runner: runnerObj,
      });

      const existing = runnerMap.get(item.tab);
      if (existing) {
        existing.pickedByUsers.push({
          punterId: punter.id,
          punterName: punter.name,
          preferenceRank: item.rank,
        });
        existing.consensusWeight += item.weight;
      } else {
        runnerMap.set(item.tab, {
          tabNumber: item.tab,
          runner: runnerObj,
          pickedByUsers: [
            {
              punterId: punter.id,
              punterName: punter.name,
              preferenceRank: item.rank,
            },
          ],
          consensusWeight: item.weight,
          finishPosition:
            isRaceResulted && runnerObj ? runnerObj.finishPosition : 0,
        });
      }
    }
  }

  // Keep ALL horses selected by all users (sorted by saddlecloth/tabNumber or consensus weight, NEVER sliced to 3)
  const combinedRunners = Array.from(runnerMap.values()).sort((a, b) => {
    if (b.consensusWeight !== a.consensusWeight) {
      return b.consensusWeight - a.consensusWeight;
    }
    const oddsA = Number(a.runner?.nswTabWin) || 99;
    const oddsB = Number(b.runner?.nswTabWin) || 99;
    if (oddsA !== oddsB) return oddsA - oddsB;
    return a.tabNumber - b.tabNumber;
  });

  // Total horses in the cumulative Boxed Trifecta = ALL unique horses selected across all users
  const n = combinedRunners.length;
  // Standard Boxed Trifecta combinations for ALL n selected horses: n * (n - 1) * (n - 2)
  // e.g. 3 horses = 6 combos, 4 horses = 24 combos, 5 horses = 60 combos, 6 horses = 120 combos, 9 horses = 504 combos
  const boxedCombinationsCount = n >= 3 ? n * (n - 1) * (n - 2) : 0;

  const first = isRaceResulted
    ? race.runners.find((r) => r.finishPosition === 1) ?? null
    : null;
  const second = isRaceResulted
    ? race.runners.find((r) => r.finishPosition === 2) ?? null
    : null;
  const third = isRaceResulted
    ? race.runners.find((r) => r.finishPosition === 3) ?? null
    : null;

  const combinedTabs = new Set(combinedRunners.map((c) => c.tabNumber));

  const firstInCombined = Boolean(first && combinedTabs.has(first.tabNumber));
  const secondInCombined = Boolean(second && combinedTabs.has(second.tabNumber));
  const thirdInCombined = Boolean(third && combinedTabs.has(third.tabNumber));

  const hitCount =
    (firstInCombined ? 1 : 0) +
    (secondInCombined ? 1 : 0) +
    (thirdInCombined ? 1 : 0);

  // Trifecta hits whenever 1st, 2nd, and 3rd are all present among ALL horses selected by the users
  const isCombinedBoxedTrifectaHit = Boolean(
    isRaceResulted &&
      first &&
      second &&
      third &&
      firstInCombined &&
      secondInCombined &&
      thirdInCombined
  );

  // Extract official Bookmaker / Tote Trifecta dividend from race.exotics
  const trifectaExotic = (race.exotics || []).find(
    (ex) => ex.poolType.toLowerCase() === "trifecta"
  );

  let bookmakerTrifectaDividend = Number(trifectaExotic?.dividend) || 0;
  if (
    isRaceResulted &&
    bookmakerTrifectaDividend <= 0 &&
    first &&
    second &&
    third
  ) {
    const w1 = Math.max(1.5, Number(first.nswTabWin) || 3.5);
    const w2 = Math.max(2.0, Number(second.nswTabWin) || 5.0);
    const w3 = Math.max(2.5, Number(third.nswTabWin) || 7.0);
    bookmakerTrifectaDividend = Number((w1 * w2 * w3 * 0.72).toFixed(2));
  }

  const officialTrifectaCombination =
    trifectaExotic?.combination ||
    (first && second && third
      ? `${first.tabNumber} - ${second.tabNumber} - ${third.tabNumber}`
      : "Pending");

  // Calculate estimated Trifecta dividend across ALL horses selected by the users (never just 3 horses)
  const defaultExpectedHorsesCount = Math.min(
    race.runners.length,
    Math.max(6, punters.length * 3)
  );
  const poolRunnersForEst: RaceRunner[] =
    combinedRunners.length >= 3
      ? combinedRunners
          .map((c) => c.runner)
          .filter((r): r is RaceRunner => Boolean(r))
      : [...race.runners]
          .sort((a, b) => (a.nswTabWin || 99) - (b.nswTabWin || 99))
          .slice(0, defaultExpectedHorsesCount);

  let permSum = 0;
  let permCount = 0;
  const m = poolRunnersForEst.length;
  for (let i = 0; i < m; i++) {
    for (let j = 0; j < m; j++) {
      if (j === i) continue;
      for (let k = 0; k < m; k++) {
        if (k === i || k === j) continue;
        const o1 = Math.max(1.5, Number(poolRunnersForEst[i]?.nswTabWin) || 3.5);
        const o2 = Math.max(2.0, Number(poolRunnersForEst[j]?.nswTabWin) || 5.0);
        const o3 = Math.max(2.5, Number(poolRunnersForEst[k]?.nswTabWin) || 7.0);
        permSum += o1 * o2 * o3 * 0.68;
        permCount += 1;
      }
    }
  }

  const estimatedUpcomingTrifectaDividend =
    permCount > 0 ? Number((permSum / permCount).toFixed(2)) : 85.0;

  // Use the actual boxed combinations of ALL selected horses; if no selections yet, use expected all-users pool (e.g. 6 horses = 120 combos for 2 users)
  const expectedDefaultCombos =
    defaultExpectedHorsesCount >= 3
      ? defaultExpectedHorsesCount *
        (defaultExpectedHorsesCount - 1) *
        (defaultExpectedHorsesCount - 2)
      : 120;
  const effectiveCombos =
    boxedCombinationsCount > 0 ? boxedCombinationsCount : expectedDefaultCombos;

  const flexiPercentage = Number(
    ((trifectaBetAmount / effectiveCombos) * 100).toFixed(2)
  );

  // Trifecta odds / payout calculated on the $20 (or custom $) boxed bet across ALL selected horses
  const trifectaOddsOnBetAmount = Number(
    ((trifectaBetAmount / effectiveCombos) * bookmakerTrifectaDividend).toFixed(
      2
    )
  );
  const straightPayoutOnBetAmount = Number(
    (trifectaBetAmount * bookmakerTrifectaDividend).toFixed(2)
  );
  const estimatedPayoutOnBetAmount = Number(
    (
      (trifectaBetAmount / effectiveCombos) *
      estimatedUpcomingTrifectaDividend
    ).toFixed(2)
  );

  const capturedTrifectaReturn = isCombinedBoxedTrifectaHit
    ? bookmakerTrifectaDividend
    : 0;

  // On a $20 (or custom $) Flexi Boxed Trifecta across ALL selected horses:
  // Flexi Unit = trifectaBetAmount / boxedCombinationsCount
  const customBetFlexiReturn =
    isCombinedBoxedTrifectaHit && boxedCombinationsCount > 0
      ? Number(
          (
            (trifectaBetAmount / boxedCombinationsCount) *
            bookmakerTrifectaDividend
          ).toFixed(2)
        )
      : 0;

  const flexi20Return = customBetFlexiReturn;

  return {
    raceNumber: race.raceNumber,
    isRaceResulted,
    hasCombinedSelections: combinedRunners.length > 0,
    participatingUserCount,
    totalUserPicksCount: allUserSelections.length,
    allUserSelections,
    combinedRunners,
    boxedCombinationsCount,
    officialPodium: {
      first,
      second,
      third,
    },
    podiumHitFlags: {
      firstInCombined,
      secondInCombined,
      thirdInCombined,
      hitCount,
    },
    isCombinedBoxedTrifectaHit,
    officialTrifectaCombination,
    trifectaBetAmount,
    flexiPercentage,
    bookmakerTrifectaDividend,
    trifectaOddsOnBetAmount,
    straightPayoutOnBetAmount,
    estimatedUpcomingTrifectaDividend,
    estimatedPayoutOnBetAmount,
    capturedTrifectaReturn,
    customBetFlexiReturn,
    flexi20Return,
  };
}

export interface QuaddieLegRunnerEntry {
  tabNumber: number;
  runner: RaceRunner | null;
  source: "user" | "extra" | "both";
  pickedByUsers: Array<{
    punterId: string;
    punterName: string;
    preferenceRank: 1 | 2 | 3;
  }>;
  isQuaddieExtra: boolean;
  finishPosition: number;
}

export interface QuaddieLegEvaluation {
  legIndex: number; // 1, 2, 3, or 4
  race: RaceEvent;
  raceNumber: number;
  isRaceResulted: boolean;
  winner: RaceRunner | null;
  userSelectedRunners: QuaddieLegRunnerEntry[];
  extraSelectedRunners: QuaddieLegRunnerEntry[];
  allLegRunners: QuaddieLegRunnerEntry[]; // Combined user selections + Quaddie-only extra selections
  isLegHit: boolean;
  winningRunnerSource: "user" | "extra" | "both" | "missed" | "pending";
}

export interface CombinedMeetingQuaddieEvaluation {
  meetingId: string;
  venue: string;
  date: string;
  legs: QuaddieLegEvaluation[];
  hasAnySelections: boolean;
  allLegsHaveSelections: boolean;
  totalCombinations: number; // L1 * L2 * L3 * L4
  buyInPerUser: number; // Default $50 buy-in per user
  participatingUsersCount: number;
  quaddieBetAmount: number; // Total combined Quaddie stake (buyInPerUser * participatingUsersCount)
  flexiPercentage: number;
  completedLegsCount: number;
  hitLegsCount: number;
  isQuaddieAlive: boolean;
  isQuaddieWon: boolean;
  officialOrEstimatedQuaddieDividend: number;
  isOfficialDividend: boolean;
  quaddieCombinationString: string;
  flexiPayoutOnBetAmount: number;
  flexiPayoutPerUser: number;
  netProfitOnBet: number;
  netProfitPerUser: number;
}

/**
 * Evaluates the Combined Syndicate Quaddie across the last 4 races of a meeting.
 * Combines all horses selected by all users in those 4 races PLUS any Quaddie-only
 * extra selections (`extraSelectionsByRace[raceNumber]`).
 * Defaults to a $50 buy-in per user (`DEFAULT_QUADDIE_BUY_IN_PER_USER = 50`).
 * Note: Quaddie-only extra selections are NEVER scored anywhere else.
 */
export function evaluateCombinedQuaddieForMeeting(
  meeting: { id: string; venue: string; date: string; races: RaceEvent[] },
  punters: PunterProfile[],
  extraSelectionsByRace: Record<number, number[]> = {},
  customBuyInPerUser: number = DEFAULT_QUADDIE_BUY_IN_PER_USER
): CombinedMeetingQuaddieEvaluation {
  const buyInPerUser =
    Number.isFinite(customBuyInPerUser) && customBuyInPerUser > 0
      ? Number(customBuyInPerUser.toFixed(2))
      : DEFAULT_QUADDIE_BUY_IN_PER_USER;
  const participatingUsersCount = Math.max(1, punters.length);
  const quaddieBetAmount = Number(
    (buyInPerUser * participatingUsersCount).toFixed(2)
  );

  const sortedRaces = [...meeting.races].sort(
    (a, b) => a.raceNumber - b.raceNumber
  );
  const quaddieRaces =
    sortedRaces.length >= 4 ? sortedRaces.slice(-4) : sortedRaces;

  const legs: QuaddieLegEvaluation[] = quaddieRaces.map((race, idx) => {
    const isRaceResulted =
      isRaceOfficialOrCompleted(race, meeting.date) &&
      race.runners.some((r) => r.finishPosition === 1);
    const winner = isRaceResulted
      ? race.runners.find((r) => r.finishPosition === 1) ?? null
      : null;

    const runnerMap = new Map<number, QuaddieLegRunnerEntry>();

    // 1. Add all user selections for this race
    for (const punter of punters) {
      const mSelections = getPunterSelectionsForMeeting(punter, meeting);
      const trio = mSelections[race.raceNumber];
      if (!trio) continue;

      const ranks: Array<{ rank: 1 | 2 | 3; tab: number | null }> = [
        {
          rank: 1,
          tab:
            trio.firstPref !== null && trio.firstPref !== undefined
              ? Number(trio.firstPref)
              : null,
        },
        {
          rank: 2,
          tab:
            trio.secondPref !== null && trio.secondPref !== undefined
              ? Number(trio.secondPref)
              : null,
        },
        {
          rank: 3,
          tab:
            trio.thirdPref !== null && trio.thirdPref !== undefined
              ? Number(trio.thirdPref)
              : null,
        },
      ];

      for (const item of ranks) {
        if (item.tab === null || !Number.isFinite(item.tab) || item.tab <= 0)
          continue;
        const runnerObj =
          race.runners.find((r) => r.tabNumber === item.tab) ?? null;
        const existing = runnerMap.get(item.tab);
        if (existing) {
          existing.pickedByUsers.push({
            punterId: punter.id,
            punterName: punter.name,
            preferenceRank: item.rank,
          });
        } else {
          runnerMap.set(item.tab, {
            tabNumber: item.tab,
            runner: runnerObj,
            source: "user",
            pickedByUsers: [
              {
                punterId: punter.id,
                punterName: punter.name,
                preferenceRank: item.rank,
              },
            ],
            isQuaddieExtra: false,
            finishPosition:
              isRaceResulted && runnerObj ? runnerObj.finishPosition : 0,
          });
        }
      }
    }

    // 2. Add Quaddie-only extra selections for this race
    const extraTabs = extraSelectionsByRace[race.raceNumber] || [];
    for (const rawTab of extraTabs) {
      const tabNo = Number(rawTab);
      if (!Number.isFinite(tabNo) || tabNo <= 0) continue;
      const runnerObj =
        race.runners.find((r) => r.tabNumber === tabNo) ?? null;
      const existing = runnerMap.get(tabNo);
      if (existing) {
        existing.isQuaddieExtra = true;
        existing.source =
          existing.pickedByUsers.length > 0 ? "both" : "extra";
      } else {
        runnerMap.set(tabNo, {
          tabNumber: tabNo,
          runner: runnerObj,
          source: "extra",
          pickedByUsers: [],
          isQuaddieExtra: true,
          finishPosition:
            isRaceResulted && runnerObj ? runnerObj.finishPosition : 0,
        });
      }
    }

    const allLegRunners = Array.from(runnerMap.values()).sort(
      (a, b) => a.tabNumber - b.tabNumber
    );
    const userSelectedRunners = allLegRunners.filter(
      (r) => r.pickedByUsers.length > 0
    );
    const extraSelectedRunners = allLegRunners.filter(
      (r) => r.source === "extra"
    );

    const winningEntry = winner
      ? runnerMap.get(winner.tabNumber) ?? null
      : null;
    const isLegHit = Boolean(isRaceResulted && winner && winningEntry);

    let winningRunnerSource: QuaddieLegEvaluation["winningRunnerSource"] =
      "pending";
    if (isRaceResulted) {
      if (winningEntry) {
        winningRunnerSource = winningEntry.source;
      } else {
        winningRunnerSource = "missed";
      }
    }

    return {
      legIndex: idx + 1,
      race,
      raceNumber: race.raceNumber,
      isRaceResulted,
      winner,
      userSelectedRunners,
      extraSelectedRunners,
      allLegRunners,
      isLegHit,
      winningRunnerSource,
    };
  });

  const hasAnySelections = legs.some((l) => l.allLegRunners.length > 0);
  const allLegsHaveSelections =
    legs.length === 4 && legs.every((l) => l.allLegRunners.length > 0);

  const totalCombinations = allLegsHaveSelections
    ? legs.reduce((acc, l) => acc * l.allLegRunners.length, 1)
    : 0;

  const flexiPercentage =
    totalCombinations > 0
      ? Number(((quaddieBetAmount / totalCombinations) * 100).toFixed(2))
      : 0;

  const completedLegsCount = legs.filter((l) => l.isRaceResulted).length;
  const hitLegsCount = legs.filter((l) => l.isLegHit).length;

  const anyCompletedLegMissed = legs.some(
    (l) => l.isRaceResulted && !l.isLegHit
  );
  const isQuaddieAlive = !anyCompletedLegMissed && legs.length === 4;
  const isQuaddieWon =
    legs.length === 4 &&
    legs.every((l) => l.isRaceResulted && l.isLegHit);

  // Check if final leg has an official Quaddie exotic dividend
  const lastLegRace = legs[legs.length - 1]?.race;
  const officialQuaddieExotic = (lastLegRace?.exotics || []).find((ex) =>
    ex.poolType.toLowerCase().includes("quaddie")
  );

  let officialOrEstimatedQuaddieDividend =
    Number(officialQuaddieExotic?.dividend) || 0;
  let isOfficialDividend = officialOrEstimatedQuaddieDividend > 0;

  if (officialOrEstimatedQuaddieDividend <= 0) {
    // Estimate Quaddie $1 dividend from leg winners (or top selected/favourite runners for pending legs)
    let productOdds = 1;
    for (const leg of legs) {
      if (leg.isRaceResulted && leg.winner) {
        const wOdds = Math.max(1.6, Number(leg.winner.nswTabWin) || 4.0);
        productOdds *= wOdds;
      } else if (leg.allLegRunners.length > 0) {
        const avgOdds =
          leg.allLegRunners.reduce(
            (sum, item) =>
              sum + Math.max(1.8, Number(item.runner?.nswTabWin) || 4.5),
            0
          ) / leg.allLegRunners.length;
        productOdds *= avgOdds;
      } else {
        const fav = [...leg.race.runners].sort(
          (a, b) => (a.nswTabWin || 99) - (b.nswTabWin || 99)
        )[0];
        productOdds *= Math.max(2.2, Number(fav?.nswTabWin) || 3.8);
      }
    }
    officialOrEstimatedQuaddieDividend = Number(
      (productOdds * 0.78).toFixed(2)
    );
    isOfficialDividend = completedLegsCount === legs.length && legs.length === 4;
  }

  const quaddieCombinationString = legs
    .map((l) => (l.isRaceResulted && l.winner ? `#${l.winner.tabNumber}` : "?"))
    .join(" - ");

  const effectiveCombos = totalCombinations > 0 ? totalCombinations : 81;
  const flexiPayoutOnBetAmount = Number(
    (
      (quaddieBetAmount / effectiveCombos) *
      officialOrEstimatedQuaddieDividend
    ).toFixed(2)
  );
  const flexiPayoutPerUser = Number(
    (flexiPayoutOnBetAmount / participatingUsersCount).toFixed(2)
  );

  const actualReturn = isQuaddieWon ? flexiPayoutOnBetAmount : 0;
  const netProfitOnBet =
    completedLegsCount === legs.length && allLegsHaveSelections
      ? Number((actualReturn - quaddieBetAmount).toFixed(2))
      : 0;
  const netProfitPerUser =
    completedLegsCount === legs.length && allLegsHaveSelections
      ? Number((netProfitOnBet / participatingUsersCount).toFixed(2))
      : 0;

  return {
    meetingId: meeting.id,
    venue: meeting.venue,
    date: meeting.date,
    legs,
    hasAnySelections,
    allLegsHaveSelections,
    totalCombinations,
    buyInPerUser,
    participatingUsersCount,
    quaddieBetAmount,
    flexiPercentage,
    completedLegsCount,
    hitLegsCount,
    isQuaddieAlive,
    isQuaddieWon,
    officialOrEstimatedQuaddieDividend,
    isOfficialDividend,
    quaddieCombinationString,
    flexiPayoutOnBetAmount,
    flexiPayoutPerUser,
    netProfitOnBet,
    netProfitPerUser,
  };
}


