// Multi-Channel Background-Capable Audio & Notification Push Engine for TurfSheet
// 1. Trifecta Siren ("WOO-OOO-WOO-OOO!") when the Syndicate lands a Winning Trifecta
// 2. Cash Register ("Ka-Ching!") for Winning Race Selections / Official Race Confirmations
// 3. Game Show Wrong Answer ("Dun-Dun!") for Unplaced Race Selections
//
// Features:
// - Pre-synthesized 16-bit PCM WAV Data URIs for HTML5 <audio> playback (works in background tabs!)
// - Web Audio API Dual-Oscillator Synthesizer
// - Silent background audio keep-alive channel + MediaSession integration so browsers never suspend audio in inactive tabs
// - Auto-unlock on pointermove/mousemove/scroll/wheel/touchstart/keydown/focus + Pending Sound Queue (no button click required)
// - Web Worker unthrottled background timer so background tab polling & sound triggers fire on schedule

export type SoundEffectType = "trifecta" | "cash" | "wrong";

let sharedAudioCtx: AudioContext | null = null;
let unlockListenersAttached = false;
let audioUnlockedOnce = false;
let keepAliveAudio: HTMLAudioElement | null = null;
const wavDataUrlCache: Partial<Record<SoundEffectType | "keepalive", string>> = {};
const audioElementPool: Partial<Record<SoundEffectType, HTMLAudioElement[]>> = {};
const pendingSoundQueue: Array<{ type: SoundEffectType; queuedAt: number }> = [];

function encodeWavFromSamples(samples: Float32Array, sampleRate = 22050): string {
  const numSamples = samples.length;
  const buffer = new ArrayBuffer(44 + numSamples * 2);
  const view = new DataView(buffer);

  const writeStr = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeStr(0, "RIFF");
  view.setUint32(4, 36 + numSamples * 2, true);
  writeStr(8, "WAVE");
  writeStr(12, "fmt ");
  view.setUint32(16, 16, true); // PCM chunk size
  view.setUint16(20, 1, true); // PCM format
  view.setUint16(22, 1, true); // Mono
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(36, "data");
  view.setUint32(40, numSamples * 2, true);

  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    const clamped = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(
      offset,
      clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff,
      true
    );
    offset += 2;
  }

  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return `data:audio/wav;base64,${btoa(binary)}`;
}

function buildSynthesizedWav(type: SoundEffectType | "keepalive"): string {
  const cached = wavDataUrlCache[type];
  if (cached) return cached;

  const sampleRate = 22050;

  if (type === "keepalive") {
    const samples = new Float32Array(sampleRate);
    for (let i = 0; i < samples.length; i++) {
      samples[i] = Math.sin((2 * Math.PI * 40 * i) / sampleRate) * 0.00002;
    }
    const url = encodeWavFromSamples(samples, sampleRate);
    wavDataUrlCache[type] = url;
    return url;
  }

  if (type === "trifecta") {
    const duration = 2.15;
    const totalSamples = Math.floor(sampleRate * duration);
    const samples = new Float32Array(totalSamples);
    let phase1 = 0;
    let phase2 = 0;

    const getSirenFreq = (t: number): number => {
      if (t < 0.38) return 420 + ((920 - 420) * t) / 0.38;
      if (t < 0.72) return 920 + ((460 - 920) * (t - 0.38)) / 0.34;
      if (t < 1.12) return 460 + ((980 - 460) * (t - 0.72)) / 0.4;
      if (t < 1.46) return 980 + ((480 - 980) * (t - 1.12)) / 0.34;
      if (t < 1.88) return 480 + ((1040 - 480) * (t - 1.46)) / 0.42;
      return 1040 + ((620 - 1040) * (t - 1.88)) / 0.27;
    };

    const bellNotes = [2093.0, 2637.02, 3135.96, 4186.01];

    for (let i = 0; i < totalSamples; i++) {
      const t = i / sampleRate;
      const f1 = getSirenFreq(t);
      const f2 = f1 * 1.5;
      phase1 += (2 * Math.PI * f1) / sampleRate;
      phase2 += (2 * Math.PI * f2) / sampleRate;

      const env =
        t < 0.05
          ? t / 0.05
          : t > 1.8
          ? Math.max(0, 1 - (t - 1.8) / 0.35)
          : 1.0;

      // Rich sawtooth/harmonic blend
      const wave1 = Math.sin(phase1) + 0.35 * Math.sin(2 * phase1);
      const wave2 = Math.sin(phase2) * 0.6;
      let val = (wave1 + wave2) * 0.28 * env;

      // Bell fanfare overlay starting at 1.42s
      bellNotes.forEach((bf, idx) => {
        const bStart = 1.42 + idx * 0.11;
        if (t >= bStart && t <= bStart + 0.52) {
          const bt = t - bStart;
          const bEnv = Math.exp(-bt * 6.5);
          val += Math.sin(2 * Math.PI * bf * bt) * 0.24 * bEnv;
        }
      });

      samples[i] = Math.max(-0.98, Math.min(0.98, val));
    }

    const url = encodeWavFromSamples(samples, sampleRate);
    wavDataUrlCache[type] = url;
    return url;
  }

  if (type === "cash") {
    const duration = 1.05;
    const totalSamples = Math.floor(sampleRate * duration);
    const samples = new Float32Array(totalSamples);
    const bellFreqs = [2637.02, 3951.07, 5274.04];

    for (let i = 0; i < totalSamples; i++) {
      const t = i / sampleRate;
      let val = 0;

      // 1. "Ka-" mechanical click transient (0.00s - 0.075s)
      if (t < 0.075) {
        const cf = 920 + ((1480 - 920) * t) / 0.075;
        const cEnv = Math.exp(-t * 42);
        val += Math.sin(2 * Math.PI * cf * t) * 0.45 * cEnv;
      }

      // 2. "-Ching!" bright metallic register bell (starts at 0.08s)
      if (t >= 0.08) {
        const bt = t - 0.08;
        bellFreqs.forEach((freq, idx) => {
          const peak = idx === 0 ? 0.38 : idx === 1 ? 0.22 : 0.15;
          const decay = idx === 0 ? 3.8 : 5.2;
          val += Math.sin(2 * Math.PI * freq * bt) * peak * Math.exp(-bt * decay);
        });
      }

      // 3. Coin shimmer overtone at 0.15s
      if (t >= 0.15 && t <= 0.72) {
        const ct = t - 0.15;
        const cf = ct < 0.05 ? 3135.96 : 4186.01;
        val += Math.sin(2 * Math.PI * cf * ct) * 0.24 * Math.exp(-ct * 5.0);
      }

      samples[i] = Math.max(-0.98, Math.min(0.98, val));
    }

    const url = encodeWavFromSamples(samples, sampleRate);
    wavDataUrlCache[type] = url;
    return url;
  }

  // "wrong" ("Dun-Dun!" Game Show Buzzer)
  const duration = 0.92;
  const totalSamples = Math.floor(sampleRate * duration);
  const samples = new Float32Array(totalSamples);

  for (let i = 0; i < totalSamples; i++) {
    const t = i / sampleRate;
    let val = 0;

    // Note 1: "DUN" (0.00s - 0.23s, G3 ~ 196Hz)
    if (t >= 0 && t <= 0.23) {
      const nt = t;
      const f = 196.0 - (6.0 * nt) / 0.23;
      const env = nt < 0.015 ? nt / 0.015 : Math.exp(-(nt - 0.015) * 8.5);
      const brass =
        Math.sin(2 * Math.PI * f * nt) +
        0.55 * Math.sin(4 * Math.PI * f * nt) +
        0.3 * Math.sin(6 * Math.PI * f * nt);
      val += brass * 0.36 * env;
    }

    // Note 2: "DUNNNN" (0.26s - 0.88s, C#3 138.59Hz -> C3 128Hz)
    if (t >= 0.26 && t <= 0.88) {
      const nt = t - 0.26;
      const f = 138.59 - (10.59 * nt) / 0.62;
      const env = nt < 0.015 ? nt / 0.015 : Math.exp(-(nt - 0.015) * 4.2);
      const brass =
        Math.sin(2 * Math.PI * f * nt) +
        0.6 * Math.sin(4 * Math.PI * f * nt) +
        0.35 * Math.sin(6 * Math.PI * f * nt);
      val += brass * 0.4 * env;
    }

    samples[i] = Math.max(-0.98, Math.min(0.98, val));
  }

  const url = encodeWavFromSamples(samples, sampleRate);
  wavDataUrlCache[type] = url;
  return url;
}

function getAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext })
      .webkitAudioContext;
  if (!AudioCtx) return null;
  if (!sharedAudioCtx || sharedAudioCtx.state === "closed") {
    try {
      sharedAudioCtx = new AudioCtx();
    } catch {
      return null;
    }
  }
  return sharedAudioCtx;
}

function ensureBackgroundKeepAlive(): void {
  if (typeof window === "undefined") return;
  try {
    if (!keepAliveAudio) {
      keepAliveAudio = new Audio(buildSynthesizedWav("keepalive"));
      keepAliveAudio.loop = true;
      keepAliveAudio.volume = 0.01;
      keepAliveAudio.preload = "auto";
    }
    if (keepAliveAudio.paused) {
      keepAliveAudio.play().catch(() => {});
    }
  } catch {
    // ignore
  }
}

function playHtml5WavSound(type: SoundEffectType): Promise<boolean> {
  if (typeof window === "undefined" || typeof Audio === "undefined") {
    return Promise.resolve(false);
  }
  try {
    const dataUrl = buildSynthesizedWav(type);
    let pool = audioElementPool[type];
    if (!pool) {
      pool = [new Audio(dataUrl), new Audio(dataUrl)];
      pool.forEach((a) => {
        a.preload = "auto";
        a.volume = 0.95;
      });
      audioElementPool[type] = pool;
    }
    const player = pool.find((a) => a.paused || a.ended) || pool[0];
    player.currentTime = 0;
    player.volume = 0.95;
    const playPromise = player.play();
    if (playPromise && typeof playPromise.then === "function") {
      return playPromise
        .then(() => {
          audioUnlockedOnce = true;
          ensureBackgroundKeepAlive();
          return true;
        })
        .catch(() => false);
    }
    return Promise.resolve(true);
  } catch {
    return Promise.resolve(false);
  }
}

function enqueuePendingSound(type: SoundEffectType): void {
  const now = Date.now();
  // Keep only recent triggers (within last 60s) and avoid duplicate spam
  while (pendingSoundQueue.length > 0 && now - pendingSoundQueue[0].queuedAt > 60_000) {
    pendingSoundQueue.shift();
  }
  if (pendingSoundQueue.length < 3) {
    pendingSoundQueue.push({ type, queuedAt: now });
  }
}

function flushPendingSounds(): void {
  if (pendingSoundQueue.length === 0) return;
  const now = Date.now();
  const next = pendingSoundQueue.shift();
  if (!next || now - next.queuedAt > 60_000) return;
  if (next.type === "trifecta") {
    playTrifectaSirenSound();
  } else if (next.type === "cash") {
    playCashRegisterSound();
  } else {
    playWrongAnswerSound();
  }
}

export function attachSafariAudioUnlock(): void {
  if (typeof window === "undefined" || unlockListenersAttached) return;
  unlockListenersAttached = true;

  // Pre-build WAV Data URIs so background playback is zero-latency
  try {
    buildSynthesizedWav("trifecta");
    buildSynthesizedWav("cash");
    buildSynthesizedWav("wrong");
    buildSynthesizedWav("keepalive");
  } catch {
    // ignore
  }

  const unlock = () => {
    try {
      const ctx = getAudioContext();
      if (ctx) {
        if (ctx.state === "suspended") {
          ctx.resume().catch(() => {});
        }
        if (!audioUnlockedOnce) {
          const buf = ctx.createBuffer(1, 1, 22050);
          const src = ctx.createBufferSource();
          src.buffer = buf;
          src.connect(ctx.destination);
          src.start(0);
          audioUnlockedOnce = true;
        }
      }
      ensureBackgroundKeepAlive();
      if (pendingSoundQueue.length > 0) {
        flushPendingSounds();
      }
    } catch {
      // ignore
    }

    // Request browser notification permission opportunistically so background tab alerts work
    try {
      if (
        typeof Notification !== "undefined" &&
        Notification.permission === "default"
      ) {
        Notification.requestPermission().catch(() => {});
      }
    } catch {
      // ignore
    }
  };

  // Attempt immediate unlock on load
  unlock();

  // Attach broad non-blocking listeners so moving mouse, scrolling, focusing, or touching unlocks audio without needing a button click
  const events = [
    "pointerdown",
    "pointermove",
    "mousedown",
    "mousemove",
    "touchstart",
    "touchmove",
    "wheel",
    "scroll",
    "keydown",
    "keyup",
    "click",
    "focus",
  ];
  events.forEach((evt) => {
    window.addEventListener(evt, unlock, { passive: true });
  });
  document.addEventListener("visibilitychange", unlock, { passive: true });
}

attachSafariAudioUnlock();

function playWebAudioSynthesizer(
  type: SoundEffectType,
  callback: (ctx: AudioContext) => void
): void {
  // Always fire the HTML5 WAV engine in parallel so background tabs play reliably even when Web Audio oscillators are throttled
  playHtml5WavSound(type).then((playedHtml5) => {
    const ctx = getAudioContext();
    if (!ctx) {
      if (!playedHtml5) enqueuePendingSound(type);
      return;
    }

    if (ctx.state === "suspended") {
      ctx
        .resume()
        .then(() => {
          audioUnlockedOnce = true;
          ensureBackgroundKeepAlive();
          // If HTML5 WAV didn't already play, synthesize via Web Audio
          if (!playedHtml5) {
            callback(ctx);
          }
        })
        .catch(() => {
          if (!playedHtml5) {
            enqueuePendingSound(type);
          }
        });
    } else if (!playedHtml5) {
      callback(ctx);
    }
  });
}

/**
 * Plays a celebratory Racecourse Trifecta Siren ("WOO-OOO-WOO-OOO!")
 * when the syndicate's combined selections successfully land 1st, 2nd & 3rd in a race!
 */
export function playTrifectaSirenSound(): void {
  playWebAudioSynthesizer("trifecta", (ctx) => {
    try {
      const now = ctx.currentTime + 0.01;
      const totalDuration = 2.15;

      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const sirenGain = ctx.createGain();

      osc1.type = "sawtooth";
      osc2.type = "triangle";

      osc1.frequency.setValueAtTime(420, now);
      osc1.frequency.exponentialRampToValueAtTime(920, now + 0.38);
      osc1.frequency.exponentialRampToValueAtTime(460, now + 0.72);
      osc1.frequency.exponentialRampToValueAtTime(980, now + 1.12);
      osc1.frequency.exponentialRampToValueAtTime(480, now + 1.46);
      osc1.frequency.exponentialRampToValueAtTime(1040, now + 1.88);
      osc1.frequency.exponentialRampToValueAtTime(620, now + totalDuration);

      osc2.frequency.setValueAtTime(630, now);
      osc2.frequency.exponentialRampToValueAtTime(1380, now + 0.38);
      osc2.frequency.exponentialRampToValueAtTime(690, now + 0.72);
      osc2.frequency.exponentialRampToValueAtTime(1470, now + 1.12);
      osc2.frequency.exponentialRampToValueAtTime(720, now + 1.46);
      osc2.frequency.exponentialRampToValueAtTime(1560, now + 1.88);
      osc2.frequency.exponentialRampToValueAtTime(930, now + totalDuration);

      filter.type = "lowpass";
      filter.frequency.setValueAtTime(2400, now);

      sirenGain.gain.setValueAtTime(0.001, now);
      sirenGain.gain.linearRampToValueAtTime(0.32, now + 0.05);
      sirenGain.gain.setValueAtTime(0.32, now + 1.8);
      sirenGain.gain.exponentialRampToValueAtTime(0.001, now + totalDuration);

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(sirenGain);
      sirenGain.connect(ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + totalDuration + 0.03);
      osc2.stop(now + totalDuration + 0.03);

      const bellNotes = [2093.0, 2637.02, 3135.96, 4186.01];
      bellNotes.forEach((freq, idx) => {
        const bStart = now + 1.45 + idx * 0.11;
        const bOsc = ctx.createOscillator();
        const bGain = ctx.createGain();
        bOsc.type = "sine";
        bOsc.frequency.setValueAtTime(freq, bStart);
        bGain.gain.setValueAtTime(0.001, bStart);
        bGain.gain.linearRampToValueAtTime(0.24, bStart + 0.01);
        bGain.gain.exponentialRampToValueAtTime(0.001, bStart + 0.55);
        bOsc.connect(bGain);
        bGain.connect(ctx.destination);
        bOsc.start(bStart);
        bOsc.stop(bStart + 0.58);
      });
    } catch {
      // ignore audio errors
    }
  });
}

/**
 * Plays a realistic Cash Register "Ka-Ching!" sound effect:
 * - Mechanical drawer latch click ("Ka-")
 * - Dual-harmonic high brass bell ring ("-Ching!")
 */
export function playCashRegisterSound(): void {
  playWebAudioSynthesizer("cash", (ctx) => {
    try {
      const now = ctx.currentTime + 0.01;

      const clickOsc = ctx.createOscillator();
      const clickGain = ctx.createGain();
      clickOsc.type = "triangle";
      clickOsc.frequency.setValueAtTime(920, now);
      clickOsc.frequency.exponentialRampToValueAtTime(1480, now + 0.065);

      clickGain.gain.setValueAtTime(0.32, now);
      clickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.075);

      clickOsc.connect(clickGain);
      clickGain.connect(ctx.destination);
      clickOsc.start(now);
      clickOsc.stop(now + 0.08);

      const bellStart = now + 0.085;
      const bellFreqs = [2637.02, 3951.07, 5274.04];

      bellFreqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = idx === 1 ? "triangle" : "sine";
        osc.frequency.setValueAtTime(freq, bellStart);

        const peakGain = idx === 0 ? 0.36 : idx === 1 ? 0.2 : 0.15;
        const duration = idx === 0 ? 0.95 : 0.7;

        gain.gain.setValueAtTime(0.0001, bellStart);
        gain.gain.linearRampToValueAtTime(peakGain, bellStart + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.0008, bellStart + duration);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(bellStart);
        osc.stop(bellStart + duration + 0.02);
      });

      const coinStart = now + 0.16;
      const coinOsc = ctx.createOscillator();
      const coinGain = ctx.createGain();
      coinOsc.type = "sine";
      coinOsc.frequency.setValueAtTime(3135.96, coinStart);
      coinOsc.frequency.setValueAtTime(4186.01, coinStart + 0.05);

      coinGain.gain.setValueAtTime(0.22, coinStart);
      coinGain.gain.exponentialRampToValueAtTime(0.001, coinStart + 0.55);

      coinOsc.connect(coinGain);
      coinGain.connect(ctx.destination);
      coinOsc.start(coinStart);
      coinOsc.stop(coinStart + 0.58);
    } catch {
      // ignore
    }
  });
}

/**
 * Plays the classic Game Show Wrong Answer "Dun-Dun!" sound effect:
 * - Note 1 ("DUN"): Low brass/buzzer G3
 * - Note 2 ("DUNNNN"): Descending C#3 -> C3 tritone drop
 */
export function playWrongAnswerSound(): void {
  playWebAudioSynthesizer("wrong", (ctx) => {
    try {
      const now = ctx.currentTime + 0.01;

      const playNote = (
        startTime: number,
        duration: number,
        startFreq: number,
        endFreq: number,
        volume: number
      ) => {
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const filter = ctx.createBiquadFilter();
        const gain = ctx.createGain();

        osc1.type = "sawtooth";
        osc2.type = "square";

        osc1.frequency.setValueAtTime(startFreq, startTime);
        osc1.frequency.linearRampToValueAtTime(endFreq, startTime + duration);

        osc2.frequency.setValueAtTime(startFreq * 0.994, startTime);
        osc2.frequency.linearRampToValueAtTime(
          endFreq * 0.994,
          startTime + duration
        );

        filter.type = "lowpass";
        filter.frequency.setValueAtTime(980, startTime);
        filter.frequency.exponentialRampToValueAtTime(
          420,
          startTime + duration
        );

        gain.gain.setValueAtTime(0.0001, startTime);
        gain.gain.linearRampToValueAtTime(volume, startTime + 0.018);
        gain.gain.setValueAtTime(
          volume * 0.85,
          startTime + Math.max(0.04, duration - 0.12)
        );
        gain.gain.exponentialRampToValueAtTime(0.0008, startTime + duration);

        osc1.connect(filter);
        osc2.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);

        osc1.start(startTime);
        osc2.start(startTime);
        osc1.stop(startTime + duration + 0.02);
        osc2.stop(startTime + duration + 0.02);
      };

      playNote(now, 0.22, 196.0, 190.0, 0.34);
      playNote(now + 0.26, 0.58, 138.59, 128.0, 0.38);
    } catch {
      // ignore
    }
  });
}

/**
 * Dispatches a native OS / Browser Desktop & Mobile notification (plus title flash)
 * so the user gets immediate audible + visual notice even when TurfSheet is in a background browser tab.
 */
export function dispatchBackgroundRaceAlert(options: {
  title: string;
  body: string;
  tag?: string;
}): void {
  if (typeof window === "undefined") return;

  // 1. Flash document title when tab is in the background so user spots it on the tab bar
  try {
    if (typeof document !== "undefined" && document.hidden) {
      const originalTitle = "TurfSheet - Punters club";
      document.title = `🔔 ${options.title} | TurfSheet`;
      const restore = () => {
        if (!document.hidden) {
          document.title = originalTitle;
          document.removeEventListener("visibilitychange", restore);
        }
      };
      document.addEventListener("visibilitychange", restore);
    }
  } catch {
    // ignore
  }

  // 2. Native Web Notification / ServiceWorker Notification (plays OS alert & banner across tabs)
  try {
    if (typeof Notification !== "undefined") {
      const fireNotification = () => {
        try {
          if (
            "serviceWorker" in navigator &&
            navigator.serviceWorker?.controller
          ) {
            navigator.serviceWorker.ready
              .then((reg) => {
                reg.showNotification(options.title, {
                  body: options.body,
                  tag: options.tag || `turfsheet-race-${Date.now()}`,
                  silent: false,
                });
              })
              .catch(() => {
                new Notification(options.title, {
                  body: options.body,
                  tag: options.tag || `turfsheet-race-${Date.now()}`,
                  silent: false,
                });
              });
          } else {
            new Notification(options.title, {
              body: options.body,
              tag: options.tag || `turfsheet-race-${Date.now()}`,
              silent: false,
            });
          }
        } catch {
          // ignore
        }
      };

      if (Notification.permission === "granted") {
        fireNotification();
      } else if (Notification.permission === "default") {
        Notification.requestPermission()
          .then((perm) => {
            if (perm === "granted") fireNotification();
          })
          .catch(() => {});
      }
    }
  } catch {
    // ignore
  }
}

/**
 * Creates an unthrottled 1-second background ticker using a dedicated Web Worker thread.
 * Unlike window.setInterval (which browsers throttle to 60s+ when a tab is in the background),
 * a Web Worker timer continues firing every second even when the page is not the active tab.
 */
export function createUnthrottledBackgroundTicker(
  onTick: () => void,
  intervalMs = 1000
): () => void {
  if (typeof window === "undefined") return () => {};

  let worker: Worker | null = null;
  let workerUrl: string | null = null;
  let fallbackId: number | null = null;

  try {
    const workerCode = `
      let timer = setInterval(() => {
        postMessage("tick");
      }, ${Math.max(250, intervalMs)});
      onmessage = (e) => {
        if (e.data === "stop" && timer) {
          clearInterval(timer);
          timer = null;
        }
      };
    `;
    const blob = new Blob([workerCode], { type: "application/javascript" });
    workerUrl = URL.createObjectURL(blob);
    worker = new Worker(workerUrl);
    worker.onmessage = () => {
      onTick();
    };
  } catch {
    fallbackId = window.setInterval(onTick, intervalMs);
  }

  return () => {
    if (worker) {
      try {
        worker.postMessage("stop");
        worker.terminate();
      } catch {
        // ignore
      }
      worker = null;
    }
    if (workerUrl) {
      try {
        URL.revokeObjectURL(workerUrl);
      } catch {
        // ignore
      }
      workerUrl = null;
    }
    if (fallbackId !== null) {
      window.clearInterval(fallbackId);
      fallbackId = null;
    }
  };
}
