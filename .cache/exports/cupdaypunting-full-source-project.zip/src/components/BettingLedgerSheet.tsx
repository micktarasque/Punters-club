import React, { useState, useEffect } from "react";
import {
  RaceMeeting,
  RaceEvent,
  RaceRunner,
  PunterProfile,
  RaceSelectionTrio,
} from "../types/racing";
import {
  getSydneyAndMelbourneMeetings,
  sortMeetingsByMetroPriority,
  isMainMetroVenue,
  isRaceOfficialOrCompleted,
} from "../data/seedNswTab";
import {
  getFeatureRaceForMeeting,
  getFeatureRaceNumberForMeeting,
  getPunterJokerForMeeting,
  getPunterSelectionsForMeeting,
} from "../utils/scoring";
import {
  Trophy,
  UserPlus,
  UserMinus,
  Trash2,
  CheckCircle2,
  Check,
  Award,
  RotateCcw,
  Users,
  Sparkles,
  DollarSign,
  MapPin,
  Layers,
  Clock,
} from "lucide-react";
import { RaceCardMultiSelectDropdown } from "./RaceCardMultiSelectDropdown";

interface BettingLedgerSheetProps {
  meetings: RaceMeeting[];
  activeMeetingId?: string;
  selectedMeetingId?: string;
  onSelectMeeting: (id: string) => void;
  selectedMeetingIds?: string[];
  onChangeSelectedMeetingIds?: (ids: string[]) => void;
  selectedDate?: string;
  onChangeDate?: (newIsoDate: string) => void;
  onRefreshSelectedDay?: () => void;
  isScraping?: boolean;
  punters: PunterProfile[];
  activePunterId: string;
  onSelectPunter: (id: string) => void;
  onAddPunter: (name: string, role: string) => void;
  onRemovePunter?: (punterId: string) => void;
  onUpdateRaceSelection: (
    punterId: string,
    meetingId: string,
    raceNumber: number,
    preferenceRank: 1 | 2 | 3,
    tabNumber: number | null
  ) => void;
  onToggleJokerRace?: (
    punterId: string,
    meetingId: string,
    raceNumber: number | null
  ) => void;
  onAutoFillCardSelections?: (punterId: string, meetingId: string) => void;
  onAutoFillCardForPunter?: (punterId: string, meeting: RaceMeeting) => void;
  onClearCardSelections?: (punterId: string, meetingId: string) => void;
  onClearCardForPunter?: (punterId: string, meetingId: string) => void;
  onSaveConfirmation?: (msg: string) => void;
  cloudSyncState?: "synced" | "saving" | "local";
  lastSyncedTime?: string;
  onManualCloudSync?: () => void;
  scoringMode: "points" | "dollars";
  onToggleScoringMode: (mode: "points" | "dollars") => void;
  onJumpToSharedResults?: () => void;
  onNavigateToResults?: () => void;
}

export interface RacePointsBreakdown {
  preferenceRank: 1 | 2 | 3;
  tabNumber: number | null;
  runner?: RaceRunner;
  finishPosition: number;
  basePoints: number;
  points: number;
  dollarReturn: number;
}

export interface EvaluatedRaceTrio {
  picks: [RacePointsBreakdown, RacePointsBreakdown, RacePointsBreakdown];
  baseRacePointsTally: number;
  racePointsTally: number;
  jokerBonusPoints: number;
  raceDollarReturn: number;
  isComplete: boolean;
  hasAnySelection: boolean;
  isRaceResulted: boolean;
  isJokerRace: boolean;
  jokerTriggered: boolean;
}

/**
 * Evaluates a user's 3-horse preference trio for a single race.
 * Crucially checks `isRaceOfficialOrCompleted(race, meetingDate)` so uncompleted
 * or future races NEVER show premature results, "Unplaced", "$0", or "0 pts".
 * Also evaluates the Joker Round: if `isJokerRace` is true and the user's 1st Preference
 * horse wins (`finishPosition === 1`), the user receives DOUBLE POINTS (2x)!
 */
export function evaluateRaceTrio(
  race: RaceEvent,
  trio: RaceSelectionTrio | undefined,
  meetingDate?: string,
  isJokerRace: boolean = false
): EvaluatedRaceTrio {
  const isRaceResulted = isRaceOfficialOrCompleted(race, meetingDate);
  const prefs: Array<{ rank: 1 | 2 | 3; tab: number | null }> = [
    { rank: 1, tab: trio?.firstPref ?? null },
    { rank: 2, tab: trio?.secondPref ?? null },
    { rank: 3, tab: trio?.thirdPref ?? null },
  ];

  const firstPrefRunner =
    prefs[0].tab !== null
      ? race.runners.find((r) => r.tabNumber === prefs[0].tab)
      : undefined;

  const jokerTriggered = Boolean(
    isJokerRace &&
      isRaceResulted &&
      prefs[0].tab !== null &&
      firstPrefRunner?.finishPosition === 1
  );

  const picks = prefs.map(({ rank, tab }): RacePointsBreakdown => {
    if (tab === null) {
      return {
        preferenceRank: rank,
        tabNumber: null,
        finishPosition: 0,
        basePoints: 0,
        points: 0,
        dollarReturn: 0,
      };
    }
    const runner = race.runners.find((r) => r.tabNumber === tab);
    const finishPosition = isRaceResulted ? runner?.finishPosition ?? 0 : 0;

    // Points System: 1st = 3 pts, 2nd = 2 pts, 3rd = 1 pt (only once race is official/completed)
    let basePoints = 0;
    if (isRaceResulted) {
      if (finishPosition === 1) basePoints = 3;
      else if (finishPosition === 2) basePoints = 2;
      else if (finishPosition === 3) basePoints = 1;
    }

    // Double points if Joker Round is triggered (selected 1st Preference horse wins)
    const points = jokerTriggered ? basePoints * 2 : basePoints;

    // Dollar Return System ($1 unit stake, only once race is official/completed):
    // - 1st Preference: Win + Place if 1st; Place only if 2nd or 3rd
    // - 2nd & 3rd Preferences: Place dividend if 1st, 2nd, or 3rd
    let dollarReturn = 0;
    if (isRaceResulted && runner) {
      const winDiv = Number(runner.nswTabWin) || 0;
      const placeDiv = Number(runner.nswTabPlace) || 0;
      if (rank === 1) {
        if (finishPosition === 1) {
          dollarReturn = winDiv + placeDiv;
        } else if (finishPosition === 2 || finishPosition === 3) {
          dollarReturn = placeDiv;
        }
      } else {
        if (
          finishPosition === 1 ||
          finishPosition === 2 ||
          finishPosition === 3
        ) {
          dollarReturn = placeDiv;
        }
      }
    }

    return {
      preferenceRank: rank,
      tabNumber: tab,
      runner,
      finishPosition,
      basePoints,
      points,
      dollarReturn: Number(dollarReturn.toFixed(2)),
    };
  }) as [RacePointsBreakdown, RacePointsBreakdown, RacePointsBreakdown];

  const baseRacePointsTally = picks.reduce((sum, p) => sum + p.basePoints, 0);
  const racePointsTally = picks.reduce((sum, p) => sum + p.points, 0);
  const jokerBonusPoints = Math.max(0, racePointsTally - baseRacePointsTally);
  const raceDollarReturn = Number(
    picks.reduce((sum, p) => sum + p.dollarReturn, 0).toFixed(2)
  );
  const isComplete = picks.every((p) => p.tabNumber !== null);
  const hasAnySelection = picks.some((p) => p.tabNumber !== null);

  return {
    picks,
    baseRacePointsTally,
    racePointsTally,
    jokerBonusPoints,
    raceDollarReturn,
    isComplete,
    hasAnySelection,
    isRaceResulted,
    isJokerRace,
    jokerTriggered,
  };
}

export function formatDollarReturn(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export const BettingLedgerSheet: React.FC<BettingLedgerSheetProps> = ({
  meetings,
  activeMeetingId,
  selectedMeetingId,
  onSelectMeeting,
  selectedMeetingIds: controlledSelectedIds,
  onChangeSelectedMeetingIds,
  punters,
  activePunterId,
  onSelectPunter,
  onAddPunter,
  onRemovePunter,
  onUpdateRaceSelection,
  onToggleJokerRace,
  onAutoFillCardSelections,
  onAutoFillCardForPunter,
  onClearCardSelections,
  onClearCardForPunter,
  cloudSyncState = "synced",
  lastSyncedTime,
  onManualCloudSync,
  scoringMode,
  onToggleScoringMode,
  onJumpToSharedResults,
  onNavigateToResults,
}) => {
  const resolvedMeetingId = activeMeetingId || selectedMeetingId || "";
  const handleJumpToResults = () => {
    if (onJumpToSharedResults) onJumpToSharedResults();
    else if (onNavigateToResults) onNavigateToResults();
  };
  const [newPunterName, setNewPunterName] = useState("");
  const [newPunterRole, setNewPunterRole] = useState("Syndicate Member");
  const [showAddMember, setShowAddMember] = useState(false);

  const sortedMeetings = sortMeetingsByMetroPriority(meetings);
  const { sydneyMeeting, melbourneMeeting, combinedRequiredMeetings } =
    getSydneyAndMelbourneMeetings(sortedMeetings);

  const defaultSelectedIds =
    combinedRequiredMeetings.length > 0
      ? combinedRequiredMeetings.map((m) => m.id)
      : resolvedMeetingId
      ? [resolvedMeetingId]
      : sortedMeetings.slice(0, 2).map((m) => m.id);

  const [internalSelectedIds, setInternalSelectedIds] =
    useState<string[]>(defaultSelectedIds);

  useEffect(() => {
    setInternalSelectedIds((prev) => {
      const valid = prev.filter((id) => sortedMeetings.some((m) => m.id === id));
      return valid.length > 0 ? valid : defaultSelectedIds;
    });
  }, [meetings]);

  const activeSelectedIds = (
    controlledSelectedIds && controlledSelectedIds.length > 0
      ? controlledSelectedIds
      : internalSelectedIds
  ).filter((id) => sortedMeetings.some((m) => m.id === id));

  const effectiveSelectedIds =
    activeSelectedIds.length > 0 ? activeSelectedIds : defaultSelectedIds;

  const updateSelectedMeetingIds = (nextIds: string[]) => {
    const safeIds = nextIds.length > 0 ? nextIds : defaultSelectedIds;
    setInternalSelectedIds(safeIds);
    onChangeSelectedMeetingIds?.(safeIds);
    if (safeIds[0] && !safeIds.includes(resolvedMeetingId)) {
      onSelectMeeting(safeIds[0]);
    }
  };

  const toggleMeetingCheckbox = (id: string) => {
    if (effectiveSelectedIds.includes(id)) {
      if (effectiveSelectedIds.length > 1) {
        updateSelectedMeetingIds(
          effectiveSelectedIds.filter((item) => item !== id)
        );
      }
    } else {
      const nextSet = new Set([...effectiveSelectedIds, id]);
      const ordered = sortedMeetings
        .filter((m) => nextSet.has(m.id))
        .map((m) => m.id);
      updateSelectedMeetingIds(ordered);
    }
  };

  const activeMeetingsInScope: RaceMeeting[] = sortedMeetings.filter((m) =>
    effectiveSelectedIds.includes(m.id)
  );

  // Never cap at 8 races: always reflect all races scheduled for each location on that day
  const displayedMeetings: RaceMeeting[] = (
    activeMeetingsInScope.length > 0
      ? activeMeetingsInScope
      : sortedMeetings.slice(0, 1)
  ).map((m) => ({
    ...m,
    races: [...m.races].sort((a, b) => a.raceNumber - b.raceNumber),
  }));

  const activePunter =
    punters.find((p) => p.id === activePunterId) || punters[0];

  if (!activePunter || displayedMeetings.length === 0) return null;

  // Evaluate all punters across the active scope (only counting points/returns on completed races)
  const leaderboard = punters
    .map((punter) => {
      let totalPoints = 0;
      let totalDollarReturn = 0;
      let completedRaces = 0;
      let selectedRacesCount = 0;
      let resultedRacesCount = 0;
      let winnersPicked = 0;
      let podiumsPicked = 0;
      let totalRacesInScope = 0;

      const byVenue: Record<
        string,
        {
          points: number;
          dollars: number;
          completed: number;
          totalRaces: number;
          resultedRaces: number;
        }
      > = {};

      displayedMeetings.forEach((m) => {
        const mSelections = getPunterSelectionsForMeeting(punter, m);
        const jokerRaceNo = getPunterJokerForMeeting(punter, m);
        let vPoints = 0;
        let vDollars = 0;
        let vCompleted = 0;
        let vResulted = 0;

        m.races.forEach((race) => {
          totalRacesInScope += 1;
          const trio = mSelections[race.raceNumber];
          const isJoker = jokerRaceNo === race.raceNumber;
          const evaluated = evaluateRaceTrio(race, trio, m.date, isJoker);

          if (evaluated.isRaceResulted) {
            resultedRacesCount += 1;
            vResulted += 1;
          }
          if (evaluated.isComplete) {
            completedRaces += 1;
            vCompleted += 1;
          }
          if (evaluated.hasAnySelection) {
            selectedRacesCount += 1;
          }
          totalPoints += evaluated.racePointsTally;
          vPoints += evaluated.racePointsTally;
          totalDollarReturn = Number(
            (totalDollarReturn + evaluated.raceDollarReturn).toFixed(2)
          );
          vDollars = Number((vDollars + evaluated.raceDollarReturn).toFixed(2));

          if (evaluated.isRaceResulted) {
            evaluated.picks.forEach((pk) => {
              if (pk.finishPosition === 1) winnersPicked += 1;
              if (pk.finishPosition >= 1 && pk.finishPosition <= 3)
                podiumsPicked += 1;
            });
          }
        });

        byVenue[m.id] = {
          points: vPoints,
          dollars: vDollars,
          completed: vCompleted,
          totalRaces: m.races.length,
          resultedRaces: vResulted,
        };
      });

      return {
        punter,
        totalPoints,
        totalDollarReturn,
        completedRaces,
        selectedRacesCount,
        resultedRacesCount,
        totalRacesInScope,
        winnersPicked,
        podiumsPicked,
        byVenue,
      };
    })
    .sort((a, b) => {
      if (scoringMode === "dollars") {
        if (b.totalDollarReturn !== a.totalDollarReturn)
          return b.totalDollarReturn - a.totalDollarReturn;
        return b.totalPoints - a.totalPoints;
      }
      if (b.totalPoints !== a.totalPoints)
        return b.totalPoints - a.totalPoints;
      return b.totalDollarReturn - a.totalDollarReturn;
    });

  const activeSummary =
    leaderboard.find((l) => l.punter.id === activePunter.id) || leaderboard[0];

  const handleCreatePunter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPunterName.trim()) return;
    onAddPunter(newPunterName.trim(), newPunterRole.trim() || "Punter");
    setNewPunterName("");
    setShowAddMember(false);
  };

  const handleAutoFillRequiredScope = () => {
    displayedMeetings.forEach((m) => {
      if (onAutoFillCardForPunter) onAutoFillCardForPunter(activePunter.id, m);
      else if (onAutoFillCardSelections) onAutoFillCardSelections(activePunter.id, m.id);
    });
  };

  const handleClearRequiredScope = () => {
    displayedMeetings.forEach((m) => {
      if (onClearCardForPunter) onClearCardForPunter(activePunter.id, m.id);
      else if (onClearCardSelections) onClearCardSelections(activePunter.id, m.id);
    });
  };

  return (
    <div className="space-y-6">
      {/* 1. Venue Selection Scope Bar + Scoring Mode Toggle */}
      <div className="bg-[#121A16] border border-[#1F2D26] rounded-lg p-4 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[#1F2D26] pb-4">
          <div className="space-y-2.5">
            <div className="flex flex-wrap items-center gap-2.5">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-xs font-mono uppercase tracking-wider text-[#D4AF37] font-semibold">
                  Select Race Cards / Locations (Check 1 or Multiple Cards):
                </span>
              </div>

              <RaceCardMultiSelectDropdown
                meetings={sortedMeetings}
                selectedMeetingIds={effectiveSelectedIds}
                onChangeSelectedMeetingIds={updateSelectedMeetingIds}
                punters={punters}
                labelPrefix="Betting Race Cards"
                compact
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Individual Venue Buttons with Checkboxes */}
              {sortedMeetings.map((m) => {
                const isChecked = effectiveSelectedIds.includes(m.id);
                const isMetro = isMainMetroVenue(m.venue, m.meetingCode);
                const firstR = m.races[0]?.raceNumber ?? 1;
                const lastR =
                  m.races[m.races.length - 1]?.raceNumber ?? m.races.length;

                return (
                  <button
                    key={m.id}
                    type="button"
                    role="checkbox"
                    aria-checked={isChecked}
                    onClick={() => toggleMeetingCheckbox(m.id)}
                    className={`min-h-[38px] px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center gap-2 border cursor-pointer ${
                      isChecked
                        ? "bg-[#152920] text-[#F3F4F0] border-[#10B981] font-semibold shadow-sm"
                        : "bg-[#0B110E] text-[#8A9990] border-[#1F2D26] hover:border-[#10B981] hover:text-[#F3F4F0]"
                    }`}
                  >
                    <span
                      className={`w-4 h-4 rounded flex items-center justify-center border shrink-0 ${
                        isChecked
                          ? "bg-[#10B981] border-[#10B981] text-[#0B110E]"
                          : "bg-[#0B110E] border-[#52665B]"
                      }`}
                    >
                      {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                    </span>
                    <span
                      className={`font-mono text-[10px] px-1.5 py-0.5 rounded font-bold ${
                        isChecked
                          ? "bg-[#0B110E]/40 text-[#D4AF37]"
                          : isMetro
                          ? "bg-[#192620] text-[#D4AF37]"
                          : "bg-[#16201B] text-[#8A9990]"
                      }`}
                    >
                      {m.state} {isMetro ? "METRO" : "TAB"}
                    </span>
                    <span>{m.venue}</span>
                    <span className="font-mono text-[11px] opacity-85">
                      ({m.races.length}R · R{firstR}–R{lastR})
                    </span>
                  </button>
                );
              })}

              {/* Quick Preset: Sydney + Melbourne Default */}
              {combinedRequiredMeetings.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    updateSelectedMeetingIds(
                      combinedRequiredMeetings.map((m) => m.id)
                    );
                  }}
                  className="min-h-[38px] px-3 py-1.5 rounded-md text-xs font-semibold transition-colors flex items-center gap-1.5 border bg-[#0B110E] text-[#D4AF37] border-[#D4AF37]/40 hover:bg-[#D4AF37]/15 cursor-pointer"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>
                    Sydney &amp; Melb (
                    {sydneyMeeting ? sydneyMeeting.venue : "NSW"} +{" "}
                    {melbourneMeeting ? melbourneMeeting.venue : "VIC"})
                  </span>
                </button>
              )}

              {/* Quick Preset: Check All Cards */}
              {sortedMeetings.length > 2 && (
                <button
                  type="button"
                  onClick={() =>
                    updateSelectedMeetingIds(sortedMeetings.map((m) => m.id))
                  }
                  className="min-h-[38px] px-3 py-1.5 rounded-md text-xs font-semibold transition-colors flex items-center gap-1.5 border bg-[#0B110E] text-[#10B981] border-[#10B981]/40 hover:bg-[#10B981]/15 cursor-pointer"
                >
                  <span>Check All ({sortedMeetings.length})</span>
                </button>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Toggle Switch: Points vs $ Return */}
            <div
              role="group"
              aria-label="Scoring Mode Switch"
              className="flex items-center p-1 bg-[#0B110E] border border-[#1F2D26] rounded-md"
            >
              <button
                type="button"
                onClick={() => onToggleScoringMode("points")}
                className={`min-h-[36px] sm:min-h-[30px] flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                  scoringMode === "points"
                    ? "bg-[#D4AF37] text-[#0B110E] font-semibold"
                    : "text-[#8A9990] hover:text-[#F3F4F0]"
                }`}
              >
                <Trophy className="w-3.5 h-3.5" />
                <span>Points (3 / 2 / 1)</span>
              </button>
              <button
                type="button"
                onClick={() => onToggleScoringMode("dollars")}
                className={`min-h-[36px] sm:min-h-[30px] flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                  scoringMode === "dollars"
                    ? "bg-[#10B981] text-[#0B110E] font-semibold"
                    : "text-[#8A9990] hover:text-[#F3F4F0]"
                }`}
              >
                <DollarSign className="w-3.5 h-3.5" />
                <span>$ Return (Win/Place)</span>
              </button>
            </div>

            <button
              type="button"
              onClick={handleJumpToResults}
              className="min-h-[38px] inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md bg-[#192620] border border-[#10B981]/50 text-[#10B981] text-xs font-semibold hover:bg-[#21332B] transition-colors cursor-pointer"
            >
              <Users className="w-3.5 h-3.5" />
              <span>View Selection Results Sheet</span>
            </button>
          </div>
        </div>

        {/* User / Punter Selector Bar */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="text-xs font-mono uppercase tracking-wider text-[#8A9990]">
              Active Punter Making Selections
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {punters.map((p) => {
                const isSelected = p.id === activePunter.id;
                const summary = leaderboard.find((l) => l.punter.id === p.id);
                const metricBadge =
                  scoringMode === "dollars"
                    ? formatDollarReturn(summary?.totalDollarReturn ?? 0)
                    : `${summary?.totalPoints ?? 0} pts`;
                const normName = (p.name || "").trim().toLowerCase();
                const isDefaultCoreUser =
                  p.id === "punter-steve-f" ||
                  p.id === "punter-mark-s" ||
                  normName === "steve f" ||
                  normName === "mark s";
                const canRemoveUser =
                  Boolean(onRemovePunter) && !isDefaultCoreUser;

                return (
                  <div
                    key={p.id}
                    className={`min-h-[40px] rounded-md text-xs font-medium transition-colors flex items-center border overflow-hidden ${
                      isSelected
                        ? "bg-[#D4AF37] text-[#0B110E] border-[#D4AF37] font-semibold"
                        : "bg-[#0B110E] text-[#F3F4F0] border-[#1F2D26] hover:border-[#8A9990]"
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => onSelectPunter(p.id)}
                      className="px-3.5 py-2 flex items-center gap-2 cursor-pointer"
                    >
                      <span>{p.name}</span>
                      <span
                        className={`font-mono px-1.5 py-0.5 rounded text-[11px] tabular-nums ${
                          isSelected
                            ? "bg-[#0B110E]/20 text-[#0B110E] font-bold"
                            : "bg-[#121A16] text-[#D4AF37]"
                        }`}
                      >
                        {summary?.completedRaces ?? 0}/
                        {summary?.totalRacesInScope ?? 8} R · {metricBadge}
                      </span>
                    </button>

                    {canRemoveUser && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onRemovePunter?.(p.id);
                        }}
                        title={`Remove user "${p.name}" from Punters Club`}
                        aria-label={`Remove user ${p.name}`}
                        className={`px-2 py-2 border-l transition-colors cursor-pointer flex items-center justify-center ${
                          isSelected
                            ? "border-[#0B110E]/20 text-[#0B110E] hover:bg-[#EF4444] hover:text-white"
                            : "border-[#1F2D26] text-[#8A9990] hover:bg-[#EF4444]/20 hover:text-[#EF4444]"
                        }`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                );
              })}

              <button
                type="button"
                onClick={() => setShowAddMember((prev) => !prev)}
                className="min-h-[40px] px-3 py-2 rounded-md text-xs font-medium bg-[#0B110E] text-[#10B981] border border-[#1F2D26] hover:border-[#10B981] transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>
                  {showAddMember ? "Close User Manager" : "Add / Manage Users"}
                </span>
              </button>

              {onRemovePunter &&
                activePunter.id !== "punter-steve-f" &&
                activePunter.id !== "punter-mark-s" &&
                activePunter.name.trim().toLowerCase() !== "steve f" &&
                activePunter.name.trim().toLowerCase() !== "mark s" && (
                  <button
                    type="button"
                    onClick={() => onRemovePunter(activePunter.id)}
                    className="min-h-[40px] px-3 py-2 rounded-md text-xs font-medium bg-[#291414] text-[#EF4444] border border-[#EF4444]/40 hover:bg-[#EF4444] hover:text-[#0B110E] transition-colors flex items-center gap-1.5 cursor-pointer"
                    title={`Remove user "${activePunter.name}"`}
                  >
                    <UserMinus className="w-3.5 h-3.5" />
                    <span>Remove {activePunter.name}</span>
                  </button>
                )}
            </div>
          </div>

          {/* Quick Actions for Active User's Scope */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => onManualCloudSync?.()}
              className="min-h-[38px] inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md bg-[#D4AF37] text-[#0B110E] text-xs font-bold hover:bg-[#e3be42] transition-colors cursor-pointer shadow-sm"
              title="Immediately save and sync all user selections across all devices (iPad, Phone, Desktop)"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>
                {cloudSyncState === "saving"
                  ? "Saving to Cloud..."
                  : `Save & Sync Selections${
                      lastSyncedTime ? ` (${lastSyncedTime})` : ""
                    }`}
              </span>
            </button>
            <button
              type="button"
              onClick={handleAutoFillRequiredScope}
              className="min-h-[38px] inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#192620] border border-[#10B981]/40 text-[#10B981] text-xs font-medium hover:bg-[#21332B] transition-colors cursor-pointer"
              title="Auto-fill 3 top-rated TAB runners for every race in the selected scope"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>
                Auto-Fill {displayedMeetings.length} Checked Card
                {displayedMeetings.length > 1 ? "s" : ""} (
                {activeSummary.totalRacesInScope} Races)
              </span>
            </button>
            <button
              type="button"
              onClick={handleClearRequiredScope}
              className="min-h-[38px] inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#0B110E] border border-[#1F2D26] text-[#8A9990] hover:text-[#EF4444] hover:border-[#EF4444]/50 text-xs font-medium transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Clear Scope Picks</span>
            </button>
          </div>
        </div>

        {showAddMember && (
          <div className="pt-3 border-t border-[#1F2D26] space-y-3">
            <form
              onSubmit={handleCreatePunter}
              className="flex flex-wrap items-end gap-3"
            >
              <div>
                <label className="block text-[11px] font-mono text-[#8A9990] mb-1">
                  New User Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Davo"
                  value={newPunterName}
                  onChange={(e) => setNewPunterName(e.target.value)}
                  className="bg-[#0B110E] border border-[#1F2D26] rounded px-3 py-1.5 text-xs text-[#F3F4F0] focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-[#8A9990] mb-1">
                  Tag / Syndicate Role
                </label>
                <input
                  type="text"
                  placeholder="e.g. Form Analyst"
                  value={newPunterRole}
                  onChange={(e) => setNewPunterRole(e.target.value)}
                  className="bg-[#0B110E] border border-[#1F2D26] rounded px-3 py-1.5 text-xs text-[#F3F4F0] focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-1.5 rounded bg-[#10B981] text-[#0B110E] text-xs font-semibold hover:bg-[#059669] transition-colors cursor-pointer"
              >
                Save &amp; Select User
              </button>
            </form>

            {onRemovePunter && punters.length > 1 && (
              <div className="p-2.5 rounded-md bg-[#0B110E] border border-[#1F2D26] flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-mono text-[#8A9990]">
                  Manage / Remove Added Users:
                </span>
                <div className="flex flex-wrap items-center gap-2">
                  {punters.map((p) => {
                    const normName = (p.name || "").trim().toLowerCase();
                    const isCore =
                      p.id === "punter-steve-f" ||
                      p.id === "punter-mark-s" ||
                      normName === "steve f" ||
                      normName === "mark s";
                    if (isCore) {
                      return (
                        <span
                          key={p.id}
                          className="px-2.5 py-1 rounded bg-[#121A16] border border-[#1F2D26] text-[11px] font-mono text-[#8A9990]"
                        >
                          {p.name} (Core Syndicate Member — Protected)
                        </span>
                      );
                    }
                    return (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => onRemovePunter(p.id)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#291414] border border-[#EF4444]/40 text-[11px] font-mono text-[#EF4444] hover:bg-[#EF4444] hover:text-[#0B110E] transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Remove {p.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Active User Scope Summary & Progress Banner */}
        <div className="pt-3 border-t border-[#1F2D26] grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
          <div className="lg:col-span-7 space-y-2">
            <div className="flex flex-wrap items-center gap-2 text-xs text-[#8A9990]">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#0B110E] border border-[#1F2D26] text-[#F3F4F0] font-mono">
                1st = <strong className="text-[#D4AF37]">3 pts</strong> (or
                Win+Place $)
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#0B110E] border border-[#1F2D26] text-[#F3F4F0] font-mono">
                2nd = <strong className="text-[#F3F4F0]">2 pts</strong> (or
                Place $)
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#0B110E] border border-[#1F2D26] text-[#F3F4F0] font-mono">
                3rd = <strong className="text-[#10B981]">1 pt</strong> (or Place
                $)
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#192620] border border-[#D4AF37]/50 text-[#D4AF37] font-mono font-semibold">
                🃏 Joker Round = <strong>2× Points</strong> if 1st Pref Wins!
              </span>
              <span className="text-[11px]">
                Showing {displayedMeetings.length} checked race card
                {displayedMeetings.length > 1 ? "s" : ""} (
                {displayedMeetings.map((m) => m.venue).join(" + ")} ·{" "}
                {activeSummary.totalRacesInScope} scheduled races).
              </span>
            </div>

            {/* Per-Venue Completion Progress Pills */}
            <div className="flex flex-wrap items-center gap-2">
              {displayedMeetings.map((m) => {
                const vStat = activeSummary.byVenue[m.id] || {
                  points: 0,
                  dollars: 0,
                  completed: 0,
                  totalRaces: m.races.length,
                  resultedRaces: 0,
                };
                const isVenueDone =
                  vStat.completed === vStat.totalRaces && vStat.totalRaces > 0;

                return (
                  <div
                    key={m.id}
                    className={`px-3 py-1.5 rounded-md border text-xs font-mono flex items-center gap-2 ${
                      isVenueDone
                        ? "bg-[#152920] border-[#10B981]/50 text-[#10B981]"
                        : "bg-[#0B110E] border-[#1F2D26] text-[#F3F4F0]"
                    }`}
                  >
                    <CheckCircle2
                      className={`w-3.5 h-3.5 ${
                        isVenueDone ? "text-[#10B981]" : "text-[#D4AF37]"
                      }`}
                    />
                    <span className="font-semibold">
                      {m.state === "NSW"
                        ? `NSW (${m.venue})`
                        : m.state === "VIC"
                        ? `VIC (${m.venue})`
                        : `${m.state} (${m.venue})`}
                      :
                    </span>
                    <span>
                      {vStat.completed}/{vStat.totalRaces} Races Picked
                    </span>
                    <span className="text-[#8A9990]">·</span>
                    <span className="text-[#8A9990]">
                      {vStat.resultedRaces}/{vStat.totalRaces} Completed
                    </span>
                    {vStat.resultedRaces > 0 && (
                      <>
                        <span className="text-[#8A9990]">·</span>
                        <span className="text-[#D4AF37] font-bold">
                          {scoringMode === "dollars"
                            ? formatDollarReturn(vStat.dollars)
                            : `${vStat.points} pts`}
                        </span>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="lg:col-span-5 grid grid-cols-3 gap-2">
            <div className="p-2.5 rounded bg-[#0B110E] border border-[#1F2D26] font-mono">
              <div className="text-[10px] uppercase text-[#8A9990]">
                {activePunter.name} {scoringMode === "dollars" ? "$ Return" : "Points"}
              </div>
              <div
                className={`text-lg font-bold tabular-nums mt-0.5 ${
                  activeSummary.resultedRacesCount === 0
                    ? "text-[#8A9990]"
                    : scoringMode === "dollars"
                    ? "text-[#10B981]"
                    : "text-[#D4AF37]"
                }`}
              >
                {activeSummary.resultedRacesCount === 0
                  ? "Pending"
                  : scoringMode === "dollars"
                  ? formatDollarReturn(activeSummary.totalDollarReturn)
                  : `${activeSummary.totalPoints} pts`}
              </div>
            </div>
            <div className="p-2.5 rounded bg-[#0B110E] border border-[#1F2D26] font-mono">
              <div className="text-[10px] uppercase text-[#8A9990]">
                Races Picked
              </div>
              <div
                className={`text-lg font-bold tabular-nums mt-0.5 ${
                  activeSummary.completedRaces ===
                  activeSummary.totalRacesInScope
                    ? "text-[#10B981]"
                    : "text-[#F3F4F0]"
                }`}
              >
                {activeSummary.completedRaces}/{activeSummary.totalRacesInScope}
              </div>
            </div>
            <div className="p-2.5 rounded bg-[#0B110E] border border-[#1F2D26] font-mono">
              <div className="text-[10px] uppercase text-[#8A9990]">
                Resulted Races
              </div>
              <div className="text-lg font-bold text-[#10B981] tabular-nums mt-0.5">
                {activeSummary.resultedRacesCount}/
                {activeSummary.totalRacesInScope}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Selection Matrix for Each Displayed Venue Card (All Scheduled Races 1..N) */}
      {displayedMeetings.map((meetingCard) => {
        const cardSelections = getPunterSelectionsForMeeting(
          activePunter,
          meetingCard
        );
        const activeJokerRaceNo = getPunterJokerForMeeting(
          activePunter,
          meetingCard
        );
        const featureRaceObj = getFeatureRaceForMeeting(meetingCard);
        const featureRaceNo = getFeatureRaceNumberForMeeting(meetingCard);
        const venueStat = activeSummary.byVenue[meetingCard.id] || {
          points: 0,
          dollars: 0,
          completed: 0,
          totalRaces: meetingCard.races.length,
          resultedRaces: 0,
        };
        const firstRaceNum = meetingCard.races[0]?.raceNumber ?? 1;
        const lastRaceNum =
          meetingCard.races[meetingCard.races.length - 1]?.raceNumber ??
          meetingCard.races.length;

        return (
          <div
            key={meetingCard.id}
            className="bg-[#121A16] border border-[#1F2D26] rounded-lg overflow-hidden"
          >
            <div className="px-4 py-3 border-b border-[#1F2D26] space-y-2.5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="px-2 py-0.5 rounded bg-[#192620] border border-[#10B981]/40 text-[#10B981] font-mono text-xs font-bold">
                    {meetingCard.state} · {meetingCard.races.length} RACES (R
                    {firstRaceNum}–R{lastRaceNum})
                  </span>
                  <div>
                    <h2 className="text-sm font-semibold text-[#F3F4F0]">
                      {meetingCard.venue} ({meetingCard.date}) —{" "}
                      <span className="text-[#D4AF37]">
                        {activePunter.name}
                      </span>
                    </h2>
                    <p className="text-xs text-[#8A9990]">
                      Select 3 horses in order of preference (1st, 2nd, 3rd)
                      across all {meetingCard.races.length} scheduled races at{" "}
                      {meetingCard.venue} ({venueStat.resultedRaces} of{" "}
                      {meetingCard.races.length} races completed).
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xs text-[#D4AF37] font-semibold">
                    {venueStat.completed}/{venueStat.totalRaces} Picked ·{" "}
                    {venueStat.resultedRaces === 0
                      ? "Awaiting Race Completion"
                      : scoringMode === "dollars"
                      ? formatDollarReturn(venueStat.dollars)
                      : `${venueStat.points} pts`}
                  </span>
                  <button
                    type="button"
                    onClick={handleJumpToResults}
                    className="text-xs font-semibold text-[#10B981] hover:underline whitespace-nowrap cursor-pointer"
                  >
                    Live Selection Results →
                  </button>
                </div>
              </div>

              {/* JOKER ROUND SELECTOR BAR FOR THIS MEETING */}
              <div className="p-2.5 rounded-lg bg-[#0B110E] border border-[#D4AF37]/40 flex flex-col lg:flex-row lg:items-center justify-between gap-2.5">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="px-2 py-0.5 rounded bg-[#D4AF37] text-[#0B110E] font-mono text-[11px] font-bold uppercase whitespace-nowrap">
                    🃏 Joker Round (2× Points)
                  </span>
                  <span className="text-xs text-[#D5DDD8]">
                    Defaults to{" "}
                    <strong className="text-[#D4AF37]">
                      Feature Race R{featureRaceNo ?? "-"}
                      {featureRaceObj ? ` (${featureRaceObj.raceName})` : ""}
                    </strong>{" "}
                    for <strong className="text-[#D4AF37]">{activePunter.name}</strong>{" "}
                    — earn{" "}
                    <strong className="text-[#10B981]">
                      double points (2×)
                    </strong>{" "}
                    if your selected <strong>1st Preference</strong> horse wins!
                  </span>
                </div>

                <div className="flex items-center gap-1.5 flex-wrap">
                  {meetingCard.races.map((r) => {
                    const isJokerSelected = activeJokerRaceNo === r.raceNumber;
                    const isFeature = featureRaceNo === r.raceNumber;
                    return (
                      <button
                        key={r.raceNumber}
                        type="button"
                        onClick={() =>
                          onToggleJokerRace?.(
                            activePunter.id,
                            meetingCard.id,
                            isJokerSelected ? null : r.raceNumber
                          )
                        }
                        className={`px-2.5 py-1 rounded font-mono text-xs font-semibold transition-colors cursor-pointer border ${
                          isJokerSelected
                            ? "bg-[#D4AF37] text-[#0B110E] border-[#D4AF37] font-bold shadow-sm"
                            : isFeature
                            ? "bg-[#192620] text-[#D4AF37] border-[#D4AF37]/50 hover:border-[#D4AF37]"
                            : "bg-[#121A16] text-[#8A9990] border-[#1F2D26] hover:border-[#D4AF37] hover:text-[#F3F4F0]"
                        }`}
                        title={
                          isJokerSelected
                            ? `Race ${r.raceNumber}${isFeature ? " (Feature Race)" : ""} is ${activePunter.name}'s Joker Round (Click to clear)`
                            : `Set Race ${r.raceNumber}${isFeature ? " (Feature Race)" : ""} as ${activePunter.name}'s Joker Round (2x Points if 1st Pref wins)`
                        }
                      >
                        {isJokerSelected
                          ? `🃏 R${r.raceNumber}${isFeature ? " ★" : ""} (2×)`
                          : `R${r.raceNumber}${isFeature ? " ★" : ""}`}
                      </button>
                    );
                  })}
                  {featureRaceNo !== null &&
                    activeJokerRaceNo !== featureRaceNo && (
                      <button
                        type="button"
                        onClick={() =>
                          onToggleJokerRace?.(
                            activePunter.id,
                            meetingCard.id,
                            featureRaceNo
                          )
                        }
                        className="px-2 py-1 rounded text-[11px] font-mono text-[#D4AF37] hover:underline cursor-pointer"
                      >
                        Reset to Feature (R{featureRaceNo})
                      </button>
                    )}
                  {activeJokerRaceNo !== null && (
                    <button
                      type="button"
                      onClick={() =>
                        onToggleJokerRace?.(activePunter.id, meetingCard.id, null)
                      }
                      className="px-2 py-1 rounded text-[11px] font-mono text-[#8A9990] hover:text-[#EF4444] cursor-pointer"
                    >
                      Clear Joker
                    </button>
                  )}
                </div>
              </div>

              {/* All Races at This Location Status Bar (R1 to RN) */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {meetingCard.races.map((r) => {
                  const isJoker = activeJokerRaceNo === r.raceNumber;
                  const ev = evaluateRaceTrio(
                    r,
                    cardSelections[r.raceNumber],
                    meetingCard.date,
                    isJoker
                  );
                  return (
                    <a
                      key={r.raceNumber}
                      href={`#selection-${meetingCard.id}-race-${r.raceNumber}`}
                      className={`px-2.5 py-1 rounded border font-mono text-[11px] tabular-nums shrink-0 transition-colors ${
                        isJoker
                          ? "bg-[#262010] border-[#D4AF37] text-[#D4AF37] font-bold"
                          : ev.isComplete
                          ? "bg-[#152920] border-[#10B981]/40 text-[#10B981]"
                          : "bg-[#0B110E] border-[#1F2D26] text-[#D4AF37]"
                      }`}
                    >
                      {isJoker ? "🃏 " : ""}R{r.raceNumber}:{" "}
                      {ev.isComplete
                        ? `#${ev.picks[0].tabNumber}/#${ev.picks[1].tabNumber}/#${ev.picks[2].tabNumber}`
                        : "Pick 3"}
                      {ev.isRaceResulted ? " ✓" : ""}
                    </a>
                  );
                })}
              </div>
            </div>

            {/* Desktop & iPad Pro Table View */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-[#1F2D26] bg-[#0B110E] text-[12px] text-[#8A9990] font-medium">
                    <th className="py-2.5 px-3 whitespace-nowrap">
                      Race · Time
                    </th>
                    <th className="py-2.5 px-3 whitespace-nowrap">
                      Race Status / Official 1st–2nd–3rd
                    </th>
                    <th className="py-2.5 px-3 whitespace-nowrap">
                      1st Preference (Win + Place)
                    </th>
                    <th className="py-2.5 px-3 whitespace-nowrap">
                      2nd Preference (Place Only)
                    </th>
                    <th className="py-2.5 px-3 whitespace-nowrap">
                      3rd Preference (Place Only)
                    </th>
                    <th className="py-2.5 px-3 text-right whitespace-nowrap">
                      {scoringMode === "dollars"
                        ? "Completed Race $ Return"
                        : "Completed Race Points"}
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1F2D26] text-xs">
                  {meetingCard.races.map((race) => {
                    const trio = cardSelections[race.raceNumber];
                    const isJokerRace = activeJokerRaceNo === race.raceNumber;
                    const evaluated = evaluateRaceTrio(
                      race,
                      trio,
                      meetingCard.date,
                      isJokerRace
                    );

                    const firstPlace = evaluated.isRaceResulted
                      ? race.runners.find((r) => r.finishPosition === 1)
                      : undefined;
                    const secondPlace = evaluated.isRaceResulted
                      ? race.runners.find((r) => r.finishPosition === 2)
                      : undefined;
                    const thirdPlace = evaluated.isRaceResulted
                      ? race.runners.find((r) => r.finishPosition === 3)
                      : undefined;

                    return (
                      <tr
                        id={`selection-${meetingCard.id}-race-${race.raceNumber}`}
                        key={race.raceNumber}
                        className={`transition-colors align-top ${
                          isJokerRace
                            ? "bg-[#1E1A0F]/90 hover:bg-[#262113]"
                            : "hover:bg-[#16201B]"
                        }`}
                      >
                        {/* Race Info + Joker Toggle */}
                        <td className="py-3 px-3 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-semibold text-[#F3F4F0] text-sm">
                              R{race.raceNumber}
                            </span>
                            <span className="font-mono text-xs text-[#8A9990]">
                              {race.startTime} · {race.distance}m
                            </span>
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold ${
                                evaluated.isRaceResulted
                                  ? "bg-[#152920] text-[#10B981]"
                                  : "bg-[#192620] text-[#D4AF37]"
                              }`}
                            >
                              {evaluated.isRaceResulted ? "FINAL" : "UPCOMING"}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <div className="text-[#F3F4F0] font-medium mt-0.5 max-w-[190px] truncate">
                              {race.raceName}
                            </div>
                            {featureRaceNo === race.raceNumber && (
                              <span className="px-1.5 py-0.5 rounded bg-[#D4AF37]/20 border border-[#D4AF37]/50 text-[#D4AF37] text-[9px] font-mono font-bold uppercase shrink-0">
                                ★ FEATURE
                              </span>
                            )}
                          </div>
                          <div className="mt-1.5 flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() =>
                                onToggleJokerRace?.(
                                  activePunter.id,
                                  meetingCard.id,
                                  isJokerRace ? null : race.raceNumber
                                )
                              }
                              className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border transition-colors cursor-pointer ${
                                isJokerRace
                                  ? "bg-[#D4AF37] text-[#0B110E] border-[#D4AF37]"
                                  : "bg-[#0B110E] text-[#D4AF37] border-[#D4AF37]/40 hover:bg-[#D4AF37]/15"
                              }`}
                              title="Nominate this race as your Joker Round (Double points if your 1st Preference horse wins)"
                            >
                              {isJokerRace
                                ? `🃏 JOKER 2× ACTIVE${featureRaceNo === race.raceNumber ? " (FEATURE)" : ""}`
                                : "🃏 Play Joker (2×)"}
                            </button>
                            <span className="text-[11px] font-mono">
                              {evaluated.isComplete ? (
                                <span className="text-[#10B981]">3/3</span>
                              ) : evaluated.hasAnySelection ? (
                                <span className="text-[#D4AF37]">Partial</span>
                              ) : (
                                <span className="text-[#8A9990]">Pick 3</span>
                              )}
                            </span>
                          </div>
                        </td>

                        {/* Official TAB Placegetters — ONLY shown if race is completed */}
                        <td className="py-3 px-3 font-mono text-[11px] tabular-nums whitespace-nowrap">
                          {!evaluated.isRaceResulted ? (
                            <div className="space-y-1 py-0.5">
                              <div className="inline-flex items-center gap-1.5 text-[#D4AF37] font-semibold">
                                <Clock className="w-3.5 h-3.5" />
                                <span>Race Not Complete ({race.startTime})</span>
                              </div>
                              <div className="text-[#8A9990] text-[10px]">
                                {race.bettingForecast
                                  ? `Favs: ${race.bettingForecast}`
                                  : "Results appear upon official All-Clear"}
                              </div>
                            </div>
                          ) : (
                            <>
                              <div className="text-[#D4AF37] font-semibold">
                                1st:{" "}
                                {firstPlace
                                  ? `#${firstPlace.tabNumber} ${firstPlace.horseName} (W $${(
                                      Number(firstPlace.nswTabWin) || 0
                                    ).toFixed(2)} / P $${(
                                      Number(firstPlace.nswTabPlace) || 0
                                    ).toFixed(2)})`
                                  : "Official Pending"}
                              </div>
                              <div className="text-[#F3F4F0] mt-0.5">
                                2nd:{" "}
                                {secondPlace
                                  ? `#${secondPlace.tabNumber} ${secondPlace.horseName} (P $${(
                                      Number(secondPlace.nswTabPlace) || 0
                                    ).toFixed(2)})`
                                  : "Official Pending"}
                              </div>
                              <div className="text-[#10B981] mt-0.5">
                                3rd:{" "}
                                {thirdPlace
                                  ? `#${thirdPlace.tabNumber} ${thirdPlace.horseName} (P $${(
                                      Number(thirdPlace.nswTabPlace) || 0
                                    ).toFixed(2)})`
                                  : "Official Pending"}
                              </div>
                            </>
                          )}
                        </td>

                        {/* 1st, 2nd, 3rd Preference Selectors */}
                        {evaluated.picks.map((pick) => {
                          const rankLabel =
                            pick.preferenceRank === 1
                              ? "1st Pref"
                              : pick.preferenceRank === 2
                              ? "2nd Pref"
                              : "3rd Pref";

                          return (
                            <td
                              key={pick.preferenceRank}
                              className="py-3 px-3 min-w-[215px]"
                            >
                              <select
                                aria-label={`${meetingCard.venue} Race ${race.raceNumber} ${rankLabel}`}
                                value={pick.tabNumber ?? ""}
                                onChange={(e) => {
                                  const val = e.target.value
                                    ? Number(e.target.value)
                                    : null;
                                  onUpdateRaceSelection(
                                    activePunter.id,
                                    meetingCard.id,
                                    race.raceNumber,
                                    pick.preferenceRank,
                                    val
                                  );
                                }}
                                className="w-full bg-[#0B110E] border border-[#1F2D26] rounded px-2.5 py-2 text-xs text-[#F3F4F0] font-mono focus:outline-none focus:border-[#D4AF37]"
                              >
                                <option value="">
                                  -- Select {rankLabel} --
                                </option>
                                {race.runners.map((rn) => (
                                  <option
                                    key={rn.tabNumber}
                                    value={rn.tabNumber}
                                  >
                                    #{rn.tabNumber} {rn.horseName} (W $
                                    {(Number(rn.nswTabWin) || 0).toFixed(2)} / P
                                    ${(Number(rn.nswTabPlace) || 0).toFixed(2)})
                                  </option>
                                ))}
                              </select>

                              {/* Status of this Preference Pick: Pending if race not complete, Result if complete */}
                              {pick.runner && (
                                <div className="mt-1.5 flex items-center justify-between text-[11px] font-mono tabular-nums px-1">
                                  <span className="text-[#8A9990]">
                                    J: {pick.runner.jockey} (B{pick.runner.barrier})
                                  </span>
                                  {!evaluated.isRaceResulted ? (
                                    <span className="text-[#D4AF37]">
                                      Locked · W $
                                      {(Number(pick.runner.nswTabWin) || 0).toFixed(2)}
                                    </span>
                                  ) : scoringMode === "dollars" ? (
                                    pick.dollarReturn > 0 ? (
                                      <span className="font-semibold text-[#10B981]">
                                        {pick.preferenceRank === 1 &&
                                        pick.finishPosition === 1
                                          ? `1st (W+P) · ${formatDollarReturn(
                                              pick.dollarReturn
                                            )}`
                                          : `${
                                              pick.finishPosition === 1
                                                ? "1st"
                                                : pick.finishPosition === 2
                                                ? "2nd"
                                                : "3rd"
                                            } (Plc) · ${formatDollarReturn(
                                              pick.dollarReturn
                                            )}`}
                                      </span>
                                    ) : (
                                      <span className="text-[#8A9990]">
                                        Unp · $0
                                      </span>
                                    )
                                  ) : pick.finishPosition === 1 ? (
                                    <span className="font-semibold text-[#D4AF37]">
                                      Finished 1st · +{pick.points} pts
                                      {evaluated.jokerTriggered &&
                                      pick.preferenceRank === 1
                                        ? " (2× JOKER!)"
                                        : ""}
                                    </span>
                                  ) : pick.finishPosition === 2 ? (
                                    <span className="font-semibold text-[#F3F4F0]">
                                      Finished 2nd · +{pick.points} pts
                                    </span>
                                  ) : pick.finishPosition === 3 ? (
                                    <span className="font-semibold text-[#10B981]">
                                      Finished 3rd · +{pick.points} pt
                                      {pick.points > 1 ? "s" : ""}
                                    </span>
                                  ) : (
                                    <span className="text-[#8A9990]">
                                      Unplaced · 0 pts
                                    </span>
                                  )}
                                </div>
                              )}
                            </td>
                          );
                        })}

                        {/* Race Points or $ Return Tally (Only scored when race is complete!) */}
                        <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap">
                          {!evaluated.hasAnySelection ? (
                            <div className="text-xs text-[#8A9990]">
                              — No selection
                              {isJokerRace && (
                                <div className="text-[10px] text-[#D4AF37] font-bold mt-0.5">
                                  🃏 Joker Active (2×)
                                </div>
                              )}
                            </div>
                          ) : !evaluated.isRaceResulted ? (
                            <div>
                              <div className="text-xs font-semibold text-[#D4AF37]">
                                {isJokerRace
                                  ? "🃏 Joker 2× Pending"
                                  : "Awaiting Result"}
                              </div>
                              <div className="text-[11px] text-[#8A9990]">
                                Jumps {race.startTime}
                              </div>
                            </div>
                          ) : scoringMode === "dollars" ? (
                            <>
                              <div
                                className={`text-base font-bold ${
                                  evaluated.raceDollarReturn > 0
                                    ? "text-[#10B981]"
                                    : "text-[#8A9990]"
                                }`}
                              >
                                {formatDollarReturn(evaluated.raceDollarReturn)}
                              </div>
                              <div className="text-[11px] text-[#8A9990]">
                                {evaluated.picks
                                  .map((p) =>
                                    p.tabNumber !== null
                                      ? formatDollarReturn(p.dollarReturn)
                                      : "—"
                                  )
                                  .join(" + ")}
                              </div>
                            </>
                          ) : (
                            <>
                              <div
                                className={`text-base font-bold ${
                                  evaluated.jokerTriggered
                                    ? "text-[#D4AF37]"
                                    : evaluated.racePointsTally >= 4
                                    ? "text-[#D4AF37]"
                                    : evaluated.racePointsTally > 0
                                    ? "text-[#10B981]"
                                    : "text-[#8A9990]"
                                }`}
                              >
                                {evaluated.racePointsTally} pts
                                {evaluated.jokerTriggered && (
                                  <span className="ml-1 text-[10px] px-1.5 py-0.5 rounded bg-[#D4AF37] text-[#0B110E] font-bold">
                                    🃏 2× HIT
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-[#8A9990]">
                                {evaluated.picks
                                  .map((p) =>
                                    p.tabNumber !== null ? `${p.points}` : "—"
                                  )
                                  .join(" + ")}{" "}
                                pts
                                {isJokerRace && !evaluated.jokerTriggered && (
                                  <span className="block text-[10px] text-[#8A9990]">
                                    (Joker: 1st Pref unplaced 1st)
                                  </span>
                                )}
                              </div>
                            </>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile Touch View (< 768px) */}
            <div className="md:hidden divide-y divide-[#1F2D26]">
              {meetingCard.races.map((race) => {
                const trio = cardSelections[race.raceNumber];
                const isJokerRace = activeJokerRaceNo === race.raceNumber;
                const evaluated = evaluateRaceTrio(
                  race,
                  trio,
                  meetingCard.date,
                  isJokerRace
                );

                return (
                  <div
                    key={race.raceNumber}
                    className={`p-4 space-y-3 ${
                      isJokerRace ? "bg-[#1E1A0F]/80" : ""
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <span className="font-mono text-sm font-semibold text-[#F3F4F0]">
                          Race {race.raceNumber}: {race.raceName}
                        </span>
                        <div className="text-xs text-[#8A9990] font-mono">
                          {race.startTime} · {race.distance}m ·{" "}
                          {evaluated.isRaceResulted ? (
                            <span className="text-[#10B981]">FINAL</span>
                          ) : (
                            <span className="text-[#D4AF37]">UPCOMING</span>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            onToggleJokerRace?.(
                              activePunter.id,
                              meetingCard.id,
                              isJokerRace ? null : race.raceNumber
                            )
                          }
                          className={`mt-1.5 px-2.5 py-0.5 rounded text-[11px] font-mono font-bold border cursor-pointer ${
                            isJokerRace
                              ? "bg-[#D4AF37] text-[#0B110E] border-[#D4AF37]"
                              : "bg-[#0B110E] text-[#D4AF37] border-[#D4AF37]/40"
                          }`}
                        >
                          {isJokerRace
                            ? "🃏 JOKER 2× ACTIVE"
                            : "🃏 Play Joker (2×)"}
                        </button>
                      </div>
                      <div className="text-right font-mono tabular-nums">
                        {!evaluated.hasAnySelection ? (
                          <div className="text-xs text-[#8A9990]">
                            — No selection
                          </div>
                        ) : !evaluated.isRaceResulted ? (
                          <>
                            <div className="text-xs font-semibold text-[#D4AF37]">
                              {isJokerRace ? "🃏 2× Pending" : "Pending Result"}
                            </div>
                            <div className="text-[11px] text-[#8A9990]">
                              Jumps {race.startTime}
                            </div>
                          </>
                        ) : scoringMode === "dollars" ? (
                          <>
                            <div className="text-sm font-bold text-[#10B981]">
                              {formatDollarReturn(evaluated.raceDollarReturn)}
                            </div>
                            <div className="text-[11px] text-[#8A9990]">
                              Race $ Return
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="text-sm font-bold text-[#D4AF37]">
                              {evaluated.racePointsTally} pts
                              {evaluated.jokerTriggered ? " (2×!)" : ""}
                            </div>
                            <div className="text-[11px] text-[#8A9990]">
                              Race Tally
                            </div>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2.5">
                      {evaluated.picks.map((pick) => {
                        const rankTitle =
                          pick.preferenceRank === 1
                            ? "1st Preference (Win + Place)"
                            : pick.preferenceRank === 2
                            ? "2nd Preference (Place Only)"
                            : "3rd Preference (Place Only)";

                        return (
                          <div key={pick.preferenceRank} className="space-y-1">
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-[#8A9990] font-medium">
                                {rankTitle}
                              </span>
                              {pick.runner && (
                                <span
                                  className={`font-mono font-semibold ${
                                    !evaluated.isRaceResulted
                                      ? "text-[#D4AF37]"
                                      : scoringMode === "dollars"
                                      ? pick.dollarReturn > 0
                                        ? "text-[#10B981]"
                                        : "text-[#8A9990]"
                                      : pick.points > 0
                                      ? "text-[#D4AF37]"
                                      : "text-[#8A9990]"
                                  }`}
                                >
                                  {!evaluated.isRaceResulted
                                    ? `W $${(Number(pick.runner.nswTabWin) || 0).toFixed(2)}`
                                    : scoringMode === "dollars"
                                    ? formatDollarReturn(pick.dollarReturn)
                                    : `${pick.points} pts`}
                                </span>
                              )}
                            </div>
                            <select
                              value={pick.tabNumber ?? ""}
                              onChange={(e) => {
                                const val = e.target.value
                                  ? Number(e.target.value)
                                  : null;
                                onUpdateRaceSelection(
                                  activePunter.id,
                                  meetingCard.id,
                                  race.raceNumber,
                                  pick.preferenceRank,
                                  val
                                );
                              }}
                              className="min-h-[44px] w-full bg-[#0B110E] border border-[#1F2D26] rounded-md px-3 py-2 text-xs text-[#F3F4F0] font-mono"
                            >
                              <option value="">-- Choose Horse --</option>
                              {race.runners.map((rn) => (
                                <option key={rn.tabNumber} value={rn.tabNumber}>
                                  #{rn.tabNumber} {rn.horseName} (W $
                                  {(Number(rn.nswTabWin) || 0).toFixed(2)} / P $
                                  {(Number(rn.nswTabPlace) || 0).toFixed(2)})
                                </option>
                              ))}
                            </select>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
};
